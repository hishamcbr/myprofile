import Vue from "vue";
import VueRouter from "vue-router";
import LandingPage from "../components/LandingPage/LandingPage.vue";
import SubLayout from "../components/View//subLayout.vue";
import Department from "../components/View/Departments/Department.vue";
import Hospitals from "../components/View/Hospitals/Hospitals.vue";
import Users from "../components/View/Users/Users.vue";
import LoginRequest from "../components/View/Users/LoginRequest.vue";
import UserLayout from "../components/View//UserLayout.vue";

import HospitalLayout from "../components/View/Hospitals/HospitalDashboard/HospitalLayout.vue";

import NewRegistration from "../components/View/Hospitals/HospitalDashboard/View/NewRegistration/NewRegistration.vue";
import hospitalDashboard from "../components/View/Hospitals/HospitalDashboard/View/Dashboard/dashboard.vue";

// Patient List

import PatientPendingList from "../components/View/Hospitals/HospitalDashboard/View/PatientList/PendingList.vue";
import PatientRegisteredList from "../components/View/Hospitals/HospitalDashboard/View/PatientList/RegisteredList.vue";
import PatientCompletedList from "../components/View/Hospitals/HospitalDashboard/View/PatientList/CompletedList.vue";

// MasterPatientList

import MasterPatientList from "../components/View/Hospitals/HospitalDashboard/View/MasterPatientList/MasterPatientList.vue";
import AddMasterPatient from "../components/View/Hospitals/HospitalDashboard/View/MasterPatientList/AddMasterPatient.vue"



// Dialysis

import DialysisRegistration from "../components/View/Hospitals/HospitalDashboard/View/Dialysis/NewRegistration/NewRegistration.vue";
import DialysisCompletedList from "../components/View/Hospitals/HospitalDashboard/View/Dialysis/CompletedList.vue";
import DialysisMasterPatientList from "../components/View/Hospitals/HospitalDashboard/View/Dialysis/MasterPatientList/MasterPatientList.vue";


import CodingList from "../components/View/Hospitals/HospitalDashboard/View/PatientList/CodingList.vue";
import PreAuthListPending from "../components/View/Hospitals/HospitalDashboard/View/PatientList/PreAuthListPending.vue";
import PreAuthListApproved from "../components/View/Hospitals/HospitalDashboard/View/PatientList/PreAuthListApproved.vue";
import PreAuthListApprovalRequired from "../components/View/Hospitals/HospitalDashboard/View/PatientList/PreAuthListApprovalRequired.vue";
import PreAuthListRejected from "../components/View/Hospitals/HospitalDashboard/View/PatientList/PreAuthListRejected.vue";
import CasesForDischarge from "../components/View/Hospitals/HospitalDashboard/View/PatientList/CasesForDischarge.vue";

import DashboardLayout from "../components/Dashboard/Layout/DashboardLayout.vue";
// GeneralViews
import NotFound from "../components/GeneralViews/NotFoundPage.vue";
// Dashboard pages
const Overview = () =>
    import (
        /* webpackChunkName: "widgets" */
        "src/components/Dashboard/Views/Dashboard/Overview.vue"
    );
const Widgets = () =>
    import (
        /* webpackChunkName: "widgets" */
        "src/components/Dashboard/Views/Dashboard/Widgets.vue"
    );

import Login from "src/components/Dashboard/Views/Pages/Login.vue";
import Register from "src/components/Dashboard/Views/Pages/Register.vue";
import Lock from "src/components/Dashboard/Views/Pages/Lock.vue";

// Calendar
import Calendar from "src/components/Dashboard/Views/Calendar/CalendarRoute.vue";

// Notification
import Notification from 'src/components/View/Notifications/Notifications.vue'

let loginPage = {
    path: "/login",
    name: "Login",
    component: Login
};

let registerPage = {
    path: "/register",
    name: "Register",
    component: Register
};

let lockPage = {
    path: "/lock",
    name: "Lock",
    component: Lock
};

const routes = [{
        path: "/home",
        component: LandingPage
    },
    {
        path: "/Departments",
        component: SubLayout,
        children: [{
            path: "",
            name: "Department",
            component: Department,
            meta: {
                requiresAdmin: true
            }
        }]
    },
    {
        path: "/global-notification",
        component: SubLayout,
        children: [{
            path: "",
            name: "Notifications",
            component: Notification
        }]
    },
    {
        path: "/Hospitals",
        component: SubLayout,
        children: [{
            path: "",
            name: "Hospitals",
            component: Hospitals
        }]
    },
    {
        path: "/Users",
        component: UserLayout,
        children: [{
                path: "Users",
                name: "Users",
                component: Users,
                meta: {
                    requiresAdmin: true
                }
            },
            {
                path: "LoginRequest",
                name: "Login Requests",
                component: LoginRequest,
                meta: {
                    requiresAdmin: true
                }
            }
        ]
    },
    {
        path: "/HospitalLayout",
        component: HospitalLayout,
        redirect: "/HospitalLayout/hospitalDashboard",
        children: [{
                path: "hospitalDashboard",
                name: "Dashboard",
                component: hospitalDashboard
            },
            {
                path: "NewRegistration",
                name: "NewRegistration",
                component: NewRegistration
            },
            {
                path: "PatientPendingList",
                name: "Patient Pending List",
                component: PatientPendingList
            },
            {
                path: "CodingList",
                name: "Coding List",
                component: CodingList
            },
            {
                path: "PreAuthListPending",
                name: "Pending Pre Auth List",
                component: PreAuthListPending
            },
            {
                path: "PreAuthListApproved",
                name: "Approved Pre Auth List",
                component: PreAuthListApproved
            },
            {
                path: "PreAuthListApprovalRequired",
                name: "Pre Auth List(Approval required)",
                component: PreAuthListApprovalRequired
            },
            {
                path: "PreAuthListRejected",
                name: "Rejected Pre Auth List",
                component: PreAuthListRejected
            },
            {
                path: "CasesForDischarge",
                name: "Cases For Discharge",
                component: CasesForDischarge
            },
            {
                path: "ApplicationList",
                name: "Admission List",
                component: PatientPendingList
            },
            {
                path: "PatientRegisteredList",
                name: "Patient Registered List",
                component: PatientRegisteredList
            },
            {
                path: "PatientCompletedList",
                name: "Patient Completed List",
                component: PatientCompletedList
            },
            {
                path: "MasterPatientList",
                name: "Master Patient List",
                component: MasterPatientList
            },
            {
                path: "Notification",
                name: "Notifications",
                component: Notification
            },



        ]
    },

    {
        path: "/admin",
        component: DashboardLayout,
        redirect: "/admin/overview",
        children: [{
            path: "calendar",
            name: "Calendar",
            component: Calendar
        }]
    },
    loginPage,
    registerPage,
    lockPage,
    {
        path: "/admin",
        component: DashboardLayout,
        redirect: "/admin/overview",
        children: [{
                path: "overview",
                name: "Overview",
                component: Overview
            },
            {
                path: "widgets",
                name: "Widgets",
                component: Widgets
            }
        ]
    },
    { path: "*", component: NotFound }
];

Vue.use(VueRouter);
// configure router
const router = new VueRouter({
    // base: '/dashboard/',
    mode: 'history',
    routes, // short for routes: routes
    linkActiveClass: "active",

});

export default router;