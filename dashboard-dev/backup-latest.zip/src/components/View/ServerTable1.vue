<template>
    <div>
      <slot name="titleTable"></slot>
      <div class="card">
      <!-- <div class="card-header">
        <slot name="titleTable"></slot>
      </div> -->
      <div class="card-body row">
        <div class="col-sm-12 col-md-12">
          <slot name="extra"></slot>
        </div>
        <el-card class="filter-card" style="margin-bottom: 10px;margin-left:15px;margin-right:15px; width:100%">
          <div class="row">
            <div class="col-sm-2 pull-left" v-if="page.entries">
              <div class="form-group">
                <label class="filter-label mb0" for="">Show</label><br>
                <el-select style="width:100%" v-model="page.TotalPerPage" placeholder="Per Page">
                  <el-option
                    v-for="item in pagination.perPageOptions"
                    :key="item"
                    :label="item"
                    :value="item">
                  </el-option>
                </el-select>
              </div>
            </div>
            <div class="col-sm-2 pull-left" v-else>
            
            </div>
            <div class="col-md-4">
              <slot name="date"></slot>
            </div>
            <div class="col-md-2">              
              <slot name="export">                
              </slot>
            </div>
            <div class="col-md-3">              
              <slot name="search"></slot>
            </div>
            <div class="col-md-1">
              <div class="form-group">
                <label for="" class="mb0" style="visibility:hidden">Button</label>
                <button  @click.prevent="showFilterMenu=!showFilterMenu" :title="showFilterMenu ? 'Collapse': 'Expand'" style="width:100%;margin:0" class="btn btn-warning"><i class="fa" :class="showFilterMenu ? 'fa-arrow-up' : 'fa-arrow-down'"></i></button>
              </div>              
            </div>
            <!-- <div> -->
              <el-collapse-transition>
                <div v-show="showFilterMenu" style="width:100%;border-top:1px solid #add6f7">
                  <slot name="more-filters"></slot>              
                </div>
              </el-collapse-transition>
            <!-- </div>      -->
        </div>
        </el-card>
               
        <div class="col-sm-6 pagination-info">
          <p style="margin-bottom:0" class="category">Showing {{from + 1}} to {{to}} of {{total}} entries</p>
        </div>
        <div class="col-sm-12">
          
          <el-table class=""
                    :row-class-name="tableRowClassName"
                    ref="multipleTable"
                    :data="queriedData"
                    border
                    style="width: 100%"
                    @cell-click="handleClick"
                    @selection-change="handleSelectionChange">
                    <!-- <el-table-column type="expand">
                      <template slot-scope="props">
                        <p>Business ID: {{ props.row.BusinessId }}</p>
                      </template>
                    </el-table-column> -->
                    <slot name="index"></slot>
            <slot name="select"></slot>
            <el-table-column v-for="(column, i) in page.tableColumns"
                             :key="i"
                             :min-width="column.minWidth"
                             :prop="column.prop"
                             :label="column.label"
                             :sortable="column.sortable ? true : false"
                             >
            </el-table-column>

            <slot name="actions" v-if="page.total"></slot>
          </el-table>
        </div>
        <div class="col-sm-6 pagination-info">
          <p class="category">Showing {{from + 1}} to {{to}} of {{total}} entries</p>
        </div>
        <!-- <div class="col-sm-4 pull-left" v-if="page.entries">
          Show
          <el-select style="width:20%" v-model="page.TotalPerPage" placeholder="Per Page">
            <el-option
              v-for="item in pagination.perPageOptions"
              :key="item"
              :label="item"
              :value="item">
            </el-option>
          </el-select>
          entries
        </div>
        <div class="col-sm-4 pull-left" v-else>
        </div> -->
        <div class="col-sm-6">
          <p-pagination class="pull-right"
                        v-model="pagination.currentPage"
                        :per-page="page.TotalPerPage"
                        :total="pagination.total"
                        @changedEvent="changedEvent($event)">
          </p-pagination>
        </div>

      </div>
    </div>


    </div>
</template>

<script>
import Vue from 'vue'
  // import {Table, TableColumn, Select, Option} from 'element-ui'
  import PPagination from './ServerPagination.vue'
  // import lang from 'element-ui/lib/locale/lang/en'
  // import locale from 'element-ui/lib/locale'
  // locale.use(lang)
  // Vue.use(Table,{locale})
  // Vue.use(TableColumn)
  // Vue.use(Select)
  // Vue.use(Option)
export default {
    props: ['page','reload','reset'],
    components: {
      PPagination
    },
    methods: {
      tableRowClassName({row, rowIndex}) {
        if (row.downloaded === 1) {
          return 'pending-row';
        } 
        else if(row.downloaded === 2){
          return 'downloaded-row'
        }
        else if(row.downloaded === 3){
          return 'reuploaded-row'
        }
        return '';
      },
      handleSelectionChange(val){
        this.$emit('selected',val)
      },
      handleClick(row, column, cell, event) {
        if(column.label == 'Order ID'){
          this.$emit('getOrderProducts',row)
        }
        if(column.label == 'Payment Method'){
          this.$emit('getChequeCollection',row)
        }
        // console.log(column.label)
      },
      changedEvent (val) {
      	this.pagination.currentPage = val
        this.$emit('updateData',{
      	  CurrentPage: val,
      	  // TotalPerPage: this.pagination.perPage,
           // TotalPerPage: 2,
          // search: this.searchQuery
      	})
      }
    },
    computed: {
      pagedData () {
        return this.page.tableData.slice(0, this.page.TotalPerPage)
      },
      /***
       * Searches through table data and returns a paginated array.
       * Note that this should not be used for table with a lot of data as it might be slow!
       * Do the search and the pagination on the server and display the data retrieved from server instead.
       * @returns {computed.pagedData}
       */
      queriedData () {
        this.page.tableData = this.setIndexes
        this.page.tableColumns = this.setColumns
        // if (!this.searchQuery) {
          this.pagination.total = this.page.total
          return this.pagedData
        // }
        // console.log('hit search')
        // let result = this.page.tableData
        //   .filter((row) => {
        //     let isIncluded = false
        //     for (let key of this.page.propsToSearch) {
        //       let rowValue = row[key].toString().toLowerCase()
        //       let searchQuery = this.searchQuery.toLowerCase()
        //       if (rowValue.includes && rowValue.includes(searchQuery)) {
        //         isIncluded = true
        //       }
        //     }
        //     return isIncluded
        //   })
        // this.pagination.total = this.page.total
        // return result.slice(this.from, this.to)
      },
      to () {
        let highBound = this.from + this.page.TotalPerPage
        if (this.total < highBound) {
          highBound = this.total
        }
        return highBound
      },
      from () {
        return this.page.TotalPerPage * (this.pagination.currentPage - 1)
      },
      total () {
        this.pagination.total = this.page.total
        // console.log(this.page.total)
        return this.page.total
      },
      setIndexes () {
        for (let key in this.page.tableData) {
          if (!('index_no' in this.page.tableData[key])) {
            let NewInd = (((this.pagination.currentPage - 1) * this.page.TotalPerPage) + parseInt(key)) + 1
            this.page.tableData[key].index_no = NewInd
          }
        }
        return this.page.tableData
      },
      setColumns () {
        let inde = {
          prop: 'index_no',
          label: '#',
          minWidth: 70
        }
        let SeeIf = true
        for (let key in this.page.tableColumns) {
          if (JSON.stringify(this.page.tableColumns[key]) === JSON.stringify(inde)) {
            SeeIf = false
          }
        }
        if (SeeIf) {
          this.page.tableColumns.unshift(inde)
        }
        return this.page.tableColumns
      }
    },
    watch:{
      reload(data){
        this.changedEvent(this.pagination.currentPage)
      },
      reset: function(newVal, oldVal) { // watch it
          if(newVal == 'reset'){
            this.$refs.multipleTable.clearSelection();
            this.$emit('changeReset')
          }
      }
    },
    data () {
      return {
        showFilterMenu: true,
        pagination: {
          perPage: 2,
          currentPage: 1,
          perPageOptions: [5, 10, 25, 50, 100],
          total: 0
        },
        searchQuery: '',
      }
    },
    created () {
      // if(this.page.searchQuery){
      //   this.searchQuery = this.page.searchQuery
      // }
      this.pagination.perPage = this.page.TotalPerPage
      let pageNumber = this.pagination.currentPage ? this.pagination.currentPage : 1
      this.changedEvent(pageNumber)
    }

}
</script>

<style>
.el-table thead{
  background-color: #1576c2;
  color: #fff;
}
.el-table .pending-row {
    background: #f9e7c1;
}
.el-table .downloaded-row {
    background: #fbbca4;
}
.el-table .reuploaded-row {
    background: #9fcbee;
}
</style>
