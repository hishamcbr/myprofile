<template>
  <div>
    <div class="card mt-4" style="width:100% ;  float: left">
      <div class="card-header">
        <h4 class="card-title">Notifications</h4>
      </div>
      <div class="card-body">
       

        <div class="notify-list"   v-for="notification in notifications" :key="notification.id">
          <p>{{notification.label}}</p>
          <div class="noti-time">{{notification.time}} ({{notification.date ? notification.date : 'Date not available'}})</div>
          
       
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import moment from 'moment'
export default {
  data() {
    return {
      notifications: []
    };
  },
  methods: {
    getData() {
      let cook = this.$cookies.get("kasp-pmjay");
      this.$http
        .post("notification/notification/list_notification", {
          userId: cook.UserId,
          sortOrder: "DESC"
          // 'pagination': 'TRUE',
          // 'currentPage': 1,
          // 'totalPerPage': 10
        })
        .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
            for (let key in res.records) {
              let result = [];
              result["label"] = res.records[key].notification_detail
                ? res.records[key].notification_detail.notification
                : "";
                result["time"] = res.records[key].created_at
                ? moment(res.records[key].created_at).fromNow()
                : "";
              result["date"] = res.records[key].created_at ? moment(res.records[key].created_at).format('DD-MM-YYYY') : ''
              result["id"] = res.records[key].id;
              if (res.records[key].status == 1) {
                this.notificationCount = this.notificationCount + 1;
              }
              selectRes.push(result);
            }
            this.notifications = selectRes;
          }
        });
    }
  },
  created() {
    this.getData();
  }
};
</script>

<style>
</style>