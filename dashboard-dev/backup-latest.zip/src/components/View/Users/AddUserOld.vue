<template>
  <div>
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">{{ actionType == 'create' ? 'Add User' : 'Edit User' }} <a @click.prevent="$emit('changeComponent','listing')" href=""><i style="margin-top:-20px" class="fa fa-times pull-right"></i></a></h4>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for>User Name <span class="text-danger">*</span> :</label>
              <input type="text" class="form-control" v-model="userName" placeholder="Enter User Name" v-validate="'required'" name="User Name">
              <small class="text-danger">
                {{ errors.first('User Name') }}
              </small>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for>Mobile Number<span class="text-danger">*</span> :</label>
              <input :readonly="actionType == 'edit'" type="text" class="form-control" v-model="mobileNumber" placeholder="Enter Mobile Number" v-validate="'required'" name="Mobile Number">
              <small class="text-danger">
                {{ errors.first('Mobile Number') }}
              </small>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for>Email ID <span class="text-danger">*</span> :</label>
              <input type="text" class="form-control" v-model="emailId" placeholder="Enter Email ID" v-validate="'required'" name="Email">
              <small class="text-danger">
                {{ errors.first('Email') }}
              </small>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for>Password <span class="text-danger">*</span> :</label>
              <input type="password" class="form-control" v-model="password" placeholder="Enter Password" v-validate="actionType == 'create' ? 'required' : ''"  name="Password">
              <small class="text-danger">
                {{ errors.first('Password') }}
              </small>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
                <label for>User Type <span class="text-danger">*</span> :</label>
                <el-select @change="selectUserType()" class="rio-select" clearable filterable placeholder="Select User Type" v-model="userType">
                    <el-option
                    v-for="type in userTypes"
                    class="select-primary"
                    :value="type.value"
                    :label="type.label"
                    :key="type.label"
                    ></el-option>
                </el-select>
            </div>
          </div>
          <div class="col-md-6" v-if="userType == 3 || userType == 4">
            <div class="form-group">
                <label for>Select Hospital :</label>
                <el-select style="width:100%" class="rio-select" clearable filterable placeholder="Select Hospital" v-model="Hospital">
                    <el-option
                    v-for="option in hospitals"
                    class="select-primary"
                    :value="option.value"
                    :label="option.label"
                    :key="option.label"
                    ></el-option>
                </el-select>
            </div>
          </div>
          <div class="col-md-12" v-if="previlages.length > 0 && userType == 2">
              <div class="form-group">
                <label for>Set Permissions</label>
                <el-checkbox-group v-model="previlage">
                    <el-checkbox v-for="p in previlages" :label="p.value" :key="p.label">{{p.label}}</el-checkbox>
                </el-checkbox-group>
              </div>              
          </div>
          <div class="col-md-6" v-if="userType == 4">
            <div class="form-group">
                <label for>Select Departments :</label>
                <el-select @change="handleSelectAll()" style="width:100%" name="Departments" v-validate="'required'" data-vv-scope="departmentScope" class="rio-select" multiple clearable filterable placeholder="Select Departments" v-model="departmentsSelected">
                    <!-- <el-option class="select-primary"
                      value="all"
                      label="All"
                      key="all" > -->
                     <span style="padding: 0 20px"> Select All <el-checkbox v-model="selectAll" @change="selectAllDepartments"></el-checkbox></span>
                    <!-- </el-option> -->
                    <el-option
                    v-for="option in departments"
                    class="select-primary"
                    :value="option.value"
                    :label="option.label"
                    :key="option.label"
                    ></el-option>
                </el-select>
                <small class="text-danger">
                    {{errors.first('departmentScope.Departments')}}
                </small>
            </div>
          </div>
          <div class="col-md-6" v-if="userType == 4">
            <div class="form-group">
              <label style="visibility:hidden;margin-top:25px">test</label>
              <label for>Restriction Required ?  </label>&nbsp;
              <el-checkbox v-model="restriction"></el-checkbox>
            </div>
          </div>      
          <div class="col-md-12">
            <button class="btn btn-primary" type="submit" @click.prevent="validate">{{actionType == 'create' ? 'Save' : 'Update'}}</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import swal from 'sweetalert2'
export default {
  props: ['data'],
  data() {
    return {
      selectAll: false,
      actionType: 'create',
      id: '',
      userName: '',
      mobileNumber: '',
      emailId: '',
      userType: '',
      password: '',
      previlage: [],
      restriction: false,
      userTypes: [
        {label: 'Sub-admin', value: 2},
        {label: 'DEO', value: 3},
        {label: 'Hospital User', value: 4}
      ],
      previlages: [],
      hospitals: [],
      Hospital: [],
      departments: [],
      departmentsSelected: []
    };
  },
  methods: {
    selectAllDepartments(){
      if(this.selectAll){
        this.departmentsSelected = []
        for(let key in this.departments){
          this.departmentsSelected.push(this.departments[key].value)
        }
      }
      else{
        this.departmentsSelected = []
      }
      
    },
    validate(){
      // console.log(this.restriction)
      this.$validator.validateAll().then(isValid => {
        if(isValid){
            if(this.userType == 4){
                this.$validator.validateAll('departmentScope').then(isValid1 => {
                    if(isValid1){
                        this.addUser()
                    }
                })
            }
            else{
                this.addUser()
            }
        }
      })
    },
    addUser(){
      let formData = {}
      formData.name = this.userName
      formData.emailId = this.emailId
      formData.mobileNumber = this.mobileNumber
      formData.userType = this.userType
      formData.password = this.password
      formData.Privilege = this.previlage
      formData.Departments = this.departmentsSelected ? this.departmentsSelected : []
      formData.Hospital = this.Hospital
      // formData.hospitalId = this.Hospital
      formData.isRestricted = this.restriction ? 2 : 1
      let url = 'users/usermanagement/add_users'
      if(this.actionType == 'update'){
        formData.id = this.id
        url = 'users/usermanagement/edit_users'
      }
      this.$http.post(url, formData)
      .then(response => {
        let res = response.body
        if(res.status) {
          this.$validator.reset()
          this.$emit('changeComponent','listing')
          swal({
            type: 'success',
            title: res.message
          })
        }
        else{
          swal({
            type: 'error',
            title: res.message
          })
        }
      })

    },
    selectUserType(){
        this.previlage = []
        this.Hospital = ''
    },
    getPrevilages() {
      this.$http.post('privilege/privilege/list_privilege',{})
      .then(response => {
        let res = response.body
        let selectRes = []
        if(res.status && res.hasrecords) {
          for (let key in res.records) {
            let result = []
            result['label'] = res.records[key].name
            result['value'] = res.records[key].id
            selectRes.push(result)
          }
          this.previlages = selectRes
        }
      })
    },
    getHospitals() {
      this.$http.post('hospital/hospital/list_hospital',{})
      .then(response => {
        let res = response.body

        let selectRes = []
        if(res.status && res.hasrecords) {
          for (let key in res.records) {
            let result = []
            result['label'] = res.records[key].name
            result['value'] = res.records[key].id
            selectRes.push(result)
          }
          this.hospitals = selectRes
        }
      })
    },
    getDepartments() {
      this.$http.post('department/department/list_department',{})
      .then(response => {
        let res = response.body
        let selectRes = []
        if(res.status && res.hasrecords) {
          for (let key in res.records) {
            let result = []
            result['label'] = res.records[key].name
            result['value'] = res.records[key].id
            selectRes.push(result)
          }
          this.departments = selectRes
          this.handleSelectAll()
        }
      })
    },
    getUserTypes(){
      let cook = this.$cookies.get('kasp-pmjay')
      if(cook.userType == 2){
        this.userTypes = [
          {label: 'DEO', value: 3},
          {label: 'Hospital User', value: 4}
        ]
      }
      else{
        this.userTypes = this.userTypes
      }
    },
    handleSelectAll(){
      if(this.departments.length == this.departmentsSelected.length){
        this.selectAll = true
      }
      else{
        this.selectAll = false
      }
    }
  },
  created() {
    this.getUserTypes()
    if(JSON.stringify(this.data) != '{}'){
      this.actionType = 'update'
      this.id = this.data.id
      this.userName = this.data.name ? this.data.name : ''
      this.mobileNumber = this.data.mobileNumber ? this.data.mobileNumber : ''
      this.emailId = this.data.emailId ? this.data.emailId : '',
      this.userType = this.data.userType ? this.data.userType : ''
      let hospitals = this.data.hospital_relation ? this.data.hospital_relation : []
      if(hospitals.length > 0){
        this.Hospital = hospitals[0].hospitalId
        // for(let key in hospitals){
        //   this.Hospital.push(hospitals[key].hospitalId)
        // }
      }
      let departments = this.data.department_relation ? this.data.department_relation : []
      if(departments.length > 0){
        for(let key in departments){
          this.departmentsSelected.push(departments[key].departmentId)
        }
        // console.log(this.departmentsSelected.length)
        
      }
      let previlages = this.data.privilege_relation ? this.data.privilege_relation : []
      if(previlages.length > 0){
        for(let key in previlages){
          this.previlage.push(previlages[key].moduleId)
        }
      }
      if(this.data.isRestricted == 2){
        this.restriction = true
      }
    }    
    this.getPrevilages()
    this.getHospitals()
    this.getDepartments()
  }
};
</script>
<style>
.el-checkbox__input{
    vertical-align: middle;
}
.form-group .el-input__inner[readonly]{
  background-color: #fff !important;
}
</style>

<style scoped>
.card.form-card{
  overflow: hidden;
  transition: all .5s ease;
  /* max-height: 0px; */
  width:50%;
}
.form-card.slide{
  transition: all .5s ease;
  /* max-height:100vh; */

}
.rio-select input{
  background-color: rgb(255, 255, 255) !important;
  color: black !important;
}
.rio-select:hover input{
  color: black !important ;
}
</style>
