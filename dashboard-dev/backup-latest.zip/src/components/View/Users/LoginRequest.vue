<template>
  <div>
    <div v-if="sections.listing">
      <ttable :page="page" @updateData="getData($event)" id="out-table" :noDataText="'hii'">
        <el-table-column
          slot="actions"
          :min-width="100"
          fixed="right"
          label="Actions"
          id="action-column">
            <template slot-scope="props">
              <button class="btn btn-success btn-icon btn-sm" @click.prevent="handleApprove(props.$index, props.row)" title="Approve"><i class="fa fa-check"></i></button>
              <button class="btn btn-danger btn-icon btn-sm" @click.prevent="handleReject(props.$index, props.row)"  title="Reject"><i class="fa fa-2x fa-times"></i></button>
              </template>
          </el-table-column>
      </ttable>
    </div>
    <el-dialog title="Approve Login Request" width="35%" :visible.sync="approveModal" style="">
      <div class="row">
        <div class="col-md-12">
            <!-- <div class="form-group"> -->
              <label for="">Set expiration time</label><br>
              <el-time-picker style="width:100%"
                v-model="expiry"
                placeholder="Expiry"
                prefix-icon=""
                name="Expiry" data-vv-scope="approveScope" v-validate="'required'">
              </el-time-picker>
              <small class="text-danger">
                {{errors.first('approveScope.Expiry')}}  
              </small> 
            <!-- </div> -->
        </div>
        <input type="hidden" v-model="hiddenId">
        <div class="col-md-12">
            <span slot="footer" class="dialog-footer">
                <button class="btn btn-sm btn-fill btn-success" @click.prevent="validate()">Approve</button>
                <button class="btn btn-sm btn-fill btn-primary" @click.prevent="approveModal=false">Cancel</button>
            </span>
        </div>
      </div>
    </el-dialog>
  </div>

    
</template>

<script>
import moment from 'moment'
import swal from 'sweetalert2'
import addUser from './AddUser.vue'
import ttable from '../ServerTable.vue'
export default {
  components:{
    ttable,
    addUser
  },
  data(){
    return{
      expiry: '',
      hiddenId: '',
      approveModal: false,
      sections: {
        add: false,
        listing: true,
        edit: false
      },
      page: {
         TotalPerPage: 10,
         total: 0,
         tableColumns: [],
         tableData: [],
         propsToSearch: [],
         selection: false,
         entries: false
       },
       columns: [
        {
          prop: 'user_relation.name',
          label: 'User Name',
          minWidth: 190,
          sortable: true
        },
        {
          prop: 'mobileNumber',
          label: 'Mobile Number',
          minWidth: 200,
          sortable: true
        },
        {
          prop: 'hospitals_relation.name',
          label: 'Hospital Name',
          minWidth: 220
        },
      ],
    }
  },
  methods: {
    validate(){
      this.$validator.validateAll('approveScope').then(isValid => {
        if(isValid){
          this.approveRequest()
        }
      })
    },
    approveRequest(){
      let formData = {}
      formData.id = this.hiddenId
      formData.status = 2
      formData.expireTime = this.expiry ? moment(this.expiry).format('HH:mm:ss') : ''
      let url = 'users/usermanagement/login_request_action'
      this.$http.post(url, formData)
      .then(response => {
        let res = response.body
        if(res.status) {
          this.$validator.reset()
          this.getData()
          this.approveModal = false
          swal({
            type: 'success',
            title: res.message
          })
        }
        else{
          swal({
            type: 'error',
            title: res.message
          })
        }
      })
    },
    changeComponent(value){
      this.showComponent(value)
    },
    showComponent(value) {
      this.sections = {
        add: false,
        listing: false,
        edit: false
      };
      for (var p in this.sections) {
        if (p == value) {
          this.sections[p] = true;
        }
      }
    },
    handleApprove(index, row){
      this.hiddenId = row.id
      this.approveModal = true
    },
    handleReject(index, row){
        swal({
        type: 'question',
        title: '',
        text: 'Are you sure to reject login request from - '+row.user_relation.name+ '?',
        showCancelButton: true,
        confirmButtonText: 'Reject',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
      })
      .then(result => {
        if (result) {
          this.$http.post('users/usermanagement/login_request_action',{
            'id': row.id,
            'status': 3,
            'expireTime': ''
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getData()
            }
          })
        }
      })
    },
    getData(event){
      this.$http.post('users/usermanagement/list_login_request',
      {
        'pagination': 'TRUE',
        'currentPage': event ? event.CurrentPage : 1,
        'totalPerPage': this.page.TotalPerPage
      })
      .then(response => {
        let res = response.body
        this.page.tableColumns = this.columns
        if(res.status && res.hasrecords) {
          for(let key in res.records.data){
            
          }
          // upon response success set columns and table data
          this.page.total = res.records.total
          this.page.tableData = res.records.data
        }
      })
    }
  }



}
</script>
<style>
.el-table .td-actions button.btn {
    margin-right: 5px !important;
}
</style>


<style scoped>
.add{
  max-height: 0;
  overflow: hidden;
}
.btn-export{
  background: #fff;
  color:#9A9A9A;
}
.add.slide{
  transition: all .5s ease;
  max-height: 100%;
}
</style>
