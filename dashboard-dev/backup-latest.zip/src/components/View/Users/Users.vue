<template>
  <div>
    <div v-if="sections.listing">
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-12">
              <button @click.prevent="userType = 'all',getData()" class="btn btn-outline-warning btn-warning btn-export" :class="userType == 'all' ? 'active' : ''">All ({{counts.all}})</button>
              <button @click.prevent="userType = 'sub-admin',getData()" class="btn btn-outline-primary btn-primary  btn-export" :class="userType == 'sub-admin' ? 'active' : ''">Sub-Admin ({{counts.subAdmin}})</button>
              <button @click.prevent="userType = 'deo',getData()" class="btn btn-outline-danger btn-danger  btn-export" :class="userType == 'deo' ? 'active' : ''">DEO ({{counts.deo}})</button>
              <button @click.prevent="userType = 'hospital-user',getData()" class="btn btn-outline-default btn-default  btn-export" :class="userType == 'hospital-user' ? 'active' : ''">Hospital Users ({{counts.hospitalUsers}})</button>
              <button @click="addSection()" class="btn btn-primary pull-right">Add Users</button>
              <div class="add"  :class="{slide : showAdd }">
                  <!-- <addDepartment  v-if="showAdd" @getData="getData()" :data="departmentData"></addDepartment>   -->
              </div>          
          </div>            
        </div>      
      </div>    
      <ttable :page="page" @updateData="getData($event)" id="out-table" :noDataText="'hii'">
        <div class="col-md-6" slot="extra"></div>
        <div class="col-md-4" slot="extra">
          <div class="form-group pull-right" style="width:100%">
            <label class="filter-label">Search</label><br>           
            <input @keyup.prevent="getData()" v-model="searchKey"  type="text" class="search-box form-control" placeholder="Search Here">
            <i class="search-icon fa fa-search text-primary"></i>
          </div>
        </div>
        <el-table-column
          slot="actions"
          :min-width="200"
          fixed="right"
          label="Actions"
          id="action-column">
            <template slot-scope="props">
              <button class="btn btn-primary btn-icon btn-sm" @click.prevent="handleEdit(props.$index, props.row)" title="Edit Details"><i class="fa fa-edit"></i></button>
              <button class="btn btn-info btn-icon btn-sm" @click.prevent="handleMobileNumberReset(props.$index, props.row)"  title="Reset Mobile Number"><i class="fa fa-2x fa-phone"></i></button>
              <button class="btn btn-warning btn-icon btn-sm" @click.prevent="handleDeviceReset(props.$index, props.row)" title="Reset Device"><i class="fa fa-mobile"></i></button>
              <button class="btn btn-default btn-icon btn-sm" @click.prevent="handleResetPassword(props.$index, props.row)" title="Reset Password"><i class="fa fa-lock"></i></button>
            </template>
          </el-table-column>
      </ttable>
    </div>
    <add-user v-else-if="sections.add" @changeComponent="changeComponent" :data="userData"></add-user>
  
    <el-dialog @close="close" title="Reset Mobile Number" width="35%" :visible.sync="deleteModal" style="">
      <div class="row">
        <div class="col-md-12">
            <div class="form-group">
              <label for="">Reset Mobile Number</label><br>
              <input v-model="mobileNumber" placeholder="Mobile Number" type="number" class="form-control" v-validate="'required'" data-vv-scope="resetScope" name="Mobile Number">
              <small class="text-danger">
                {{errors.first('resetScope.Mobile Number')}}  
              </small> 
            </div>
        </div>
        <input type="hidden" v-model="hiddenUserId">
        <div class="col-md-12">
            <span slot="footer" class="dialog-footer">
                <button class="btn btn-sm btn-fill btn-success" @click.prevent="validateMobileNumber()">Reset</button>
                <button class="btn btn-sm btn-fill btn-primary" @click.prevent="deleteModal=false">Cancel</button>
            </span>
        </div>
      </div>
    </el-dialog>

    <el-dialog title="Reset Password" width="35%" :visible.sync="passwordModal" style="">
      <div class="row">
        <div class="col-md-12">
            <div class="form-group">
              <label for="">Reset Password</label><br>
              <input v-model="password" placeholder="Password" type="password" class="form-control" v-validate="'required'" data-vv-scope="resetPasswordScope" name="Password">
              <small class="text-danger">
                {{errors.first('resetPasswordScope.Password')}}  
              </small> 
            </div>
        </div>
        <div class="col-md-12">
            <span slot="footer" class="dialog-footer">
                <button class="btn btn-sm btn-fill btn-success" @click.prevent="validatePassword()">Reset</button>
                <button class="btn btn-sm btn-fill btn-primary" @click.prevent="passwordModal=false">Cancel</button>
            </span>
        </div>
      </div>
    </el-dialog>
  </div>

    
</template>

<script>
import swal from 'sweetalert2'
import addUser from './AddUser.vue'
import ttable from '../ServerTable.vue'
export default {
  components:{
    ttable,
    addUser
  },
  data(){
    return{
      searchKey: '',
      passwordModal: false,
      mobileNumber: '',
      password: '',
      hiddenUserId: '',
      deleteModal: false,
      userData: {},
      sections: {
        add: false,
        listing: true,
        edit: false
      },
      counts: {
        all: 0,
        subAdmin: 0,
        deo: 0,
        hospitalUsers: 0
      },
      userType: 'all',
      showAdd: false,
      departmentData: {},
      page: {
         TotalPerPage: 10,
         total: 0,
         tableColumns: [],
         tableData: [],
         propsToSearch: [],
         selection: false,
         entries: true
       },
       columns: [
        {
          prop: 'name',
          label: 'Name',
          minWidth: 190,
          sortable: true
        },
        {
          prop: 'type',
          label: 'User type',
          minWidth: 150,
          sortable: true
        },
        {
          prop: 'mobileNumber',
          label: 'Mob No',
          minWidth: 130
        },
        {
          prop: 'emailId',
          label: 'Email ID',
          minWidth: 220
        },
        {
          prop: 'hospitalName',
          label: 'Hospitals',
          minWidth: 220
        }
      ],
    }
  },
  methods: {
    addSection(){
      this.userData = {}
      this.showComponent('add')
    },
    close(){
      this.deleteModal = false
      // console.log(this.deleteModal)
    },
    handleMobileNumberReset (index, row) {
      this.mobileNumber = row.mobileNumber
      this.hiddenUserId = row.id
      this.deleteModal = true

      // swal({
      //   title: '',
      //   input: 'number',
      //   text: "Enter New Mobile Number",
      //   inputAttributes: {
      //     autocapitalize: 'off',
      //     required: true
      //   },
      //   showCancelButton: true,
      //   confirmButtonClass: 'btn btn-sm btn-success btn-fill',
      //   cancelButtonClass: 'btn btn-sm btn-danger btn-fill',
      //   buttonsStyling: false,
      //   confirmButtonText: 'Approve',
      //   showLoaderOnConfirm: true,
      //   preConfirm: (gdsNumber) => {
      //     if(!gdsNumber){
      //       swal({
      //         title: 'GDS/Chitty Number Required',
      //         text: 'Please enter GDS/Chitty Number',
      //         type: 'error',
      //       })
      //     }
      //     else {
      //     return this.$http.post('applicants/applicantslist/requestaction', {
      //       // id : cook.user.id,
      //       // token: cook.idToken,
      //       requestId: row.requestId,
      //       operation: 'approve',
      //       chittyNumber: gdsNumber,
      //       pskUserId: row.customer_detail.pskUserId
      //     }).then(response => {
      //       if (!response.ok) {
      //         throw new Error(response.statusText)
      //       }
      //       return response.json()
      //     })
      //     .catch(error => {
      //       swal.showValidationError(
      //         `Request failed: ${error}`
      //       )
      //     })
      //     }
      //   }
      // }).then((result) => {
      //   if (result.dismiss !== 'cancel') {
      //     this.getData()
      //     swal({
      //       title: result.message,
      //       text: row.name,
      //       type: result.status ? 'success' : 'error',
      //       showConfirmButton: false,
      //       timer: 1500
      //     })
      //   }
      // })

    },
    handleResetPassword(index, row){
      this.hiddenUserId = row.id
      this.passwordModal = true
    },
    validatePassword(){
      this.$validator.validateAll('resetPasswordScope').then(isValid => {
        if(isValid){
          this.resetPassword()
        }
      })
    },
    resetPassword(){
      let formData = {}
      formData.id = this.hiddenUserId
      formData.newPassword = this.password
      let url = 'users/usermanagement/reset_password'
      this.$http.post(url, formData)
      .then(response => {
        let res = response.body
        if(res.status) {
          this.password =  ''
          this.hiddenUserId = ''
          this.$validator.reset()          
          this.passwordModal = false
          this.getData()
          swal({
            type: 'success',
            title: res.message
          })
        }
        else{
          swal({
            type: 'error',
            title: res.message
          })
        }
      })
    },
    validateMobileNumber(){
      this.$validator.validateAll('resetScope').then(isValid => {
        if(isValid){
          this.resetMobileNumber()
        }
      })
    },
    resetMobileNumber(){
      let formData = {}
      formData.userId = this.hiddenUserId
      formData.mobileNumber = this.mobileNumber
      let url = 'users/usermanagement/reset_mobile'
      this.$http.post(url, formData)
      .then(response => {
        let res = response.body
        if(res.status) {
          this.mobileNumber =  ''
          this.hiddenUserId = ''
          this.$validator.reset()          
          this.deleteModal = false
          this.getData()
          swal({
            type: 'success',
            title: res.message
          })
        }
        else{
          swal({
            type: 'error',
            title: res.message
          })
        }
      })
    },
    changeComponent(value){
      this.showComponent(value)
    },
    showComponent(value) {
      this.sections = {
        add: false,
        listing: false,
        edit: false
      };
      for (var p in this.sections) {
        if (p == value) {
          this.sections[p] = true;
        }
      }
    },
    handleEdit(index, row){
      this.userData = row
      this.showComponent('add')
    },
    handleDeviceReset(index, row){
        swal({
        type: 'question',
        title: '',
        text: 'Are you sure to reset device for - '+row.name+ '?',
        showCancelButton: true,
        confirmButtonText: 'Reset',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
      })
      .then(result => {
        if (result) {
          this.$http.post('users/usermanagement/reset_device',{
            'id': row.id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getData()
            }
          })
        }
      })
    },
    getUserTypeId(){
      let userType = ''
      if(this.userType == 'all'){
        userType = ''
      }
      else if(this.userType == 'sub-admin'){
        userType = 2
      }
      else if(this.userType == 'deo'){
        userType = 3
      }
      else if(this.userType == 'hospital-user'){
        userType = 4
      }
      return userType
    },
    getUserType(value){
      let userType = ''
      if(value == 2){
        userType = 'Sub Admin'
      }
      else if(value == 3){
        userType = 'DEO'
      }
      else if(value == 4){
        userType = 'Hospital User'
      }
      else if(value == 5){
        userType = 'PRO'
      }
      else if(value == 6){
        userType = 'CODER'
      }
      return userType
    },
    getData(event){
      let userType = this.getUserTypeId()
      this.$http.post('users/usermanagement/list_user',
      {
        'moreDetails': 'TRUE',
        'pagination': 'TRUE',
        'currentPage': event ? event.CurrentPage : 1,
        'totalPerPage': this.page.TotalPerPage,
        'sortOrder': 'DESC',
        'searchKey': this.searchKey,
        'userType': userType,
      })
      .then(response => {
        let res = response.body
        this.page.tableColumns = this.columns
        if(res.status && res.hasrecords) {
          for(let key in res.records.data.data){
            res.records.data.data[key].type = this.getUserType(res.records.data.data[key].userType)
            if(res.records.data.data[key].userType == 3 || res.records.data.data[key].userType == 4){
              res.records.data.data[key].hospitalName = res.records.data.data[key].hospital_relation.length > 0 ? (res.records.data.data[key].hospital_relation[0].hospital_details ? res.records.data.data[key].hospital_relation[0].hospital_details.name : '') : ''
            }
            
          }
          this.counts = {
            all: res.records.AllCount,
            subAdmin: res.records.SubAdminCount,
            deo: res.records.DeoCount,
            hospitalUsers: res.records.HospitalUserCount
          }
          // upon response success set columns and table data
          this.page.total = res.records.data.total
          this.page.tableData = res.records.data.data
        }
      })
    }
  }



}
</script>
<style>
.el-table .td-actions button.btn {
    margin-right: 5px !important;
}
</style>


<style scoped>
.add{
  max-height: 0;
  overflow: hidden;
}
.btn-export{
  background: #fff;
  color:#9A9A9A;
}
.add.slide{
  transition: all .5s ease;
  max-height: 100%;
}
</style>
