<template>
  <div>
    <div class="form-card">
      <!-- <div class="card-header">
        <h4 class="card-title">{{ actionType == 'create' ? 'Add Department' : 'Edit Department' }}</h4>
      </div> -->
      <!-- <div class="card-body"> -->
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label for>Department Name*:</label>
              <input type="text" class="form-control" v-model="DepartmentName" placeholder="Department Name" v-validate="'required'" name="Department Name">
              <small class="text-danger">
                {{ errors.first('Department Name') }}
              </small>
            </div>
          </div>
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-10">
                <div class="form-group">
                  <label for>Icon<span style="color:#867c7c"> (Upload 250px * 250px icons)</span></label>
                  <input type="file" class="form-control" @change="selectAttachment" v-validate="'image'" name="Department Icon">
                  <small class="text-danger">
                    {{ errors.first('Department Icon') }}
                  </small>
                </div>
              </div>
              <div class="col-md-2" v-if="actionType == 'update'">
                <img :src="image ? image : 'No image'" @error="'http://pmjay.sevensigma.in/api/v1/uploads/icons/no-image-available.png'" width="100%">
              </div>
            </div>
            
          </div>
          <div class="col-md-12">
            <div v-for="(input, index) in documents" :key="index">
              <div class="row">                
                <div class="col-md-6">
                  <div class="form-group">
                    <label for>Enter Document type:</label>                   
                    <input type="text" class="form-control" placeholder="Document Type" v-model="documents[index].label"
                    v-validate="'required'" data-vv-as="Document Type" :name="'Document Type'+index" data-vv-scope="documentScope"/>
                    <small class="text-danger">
                      {{ errors.first('documentScope.Document Type'+index) }}
                    </small>
                  </div>
                  <input type="hidden" v-model="documents[index].id">
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for>Section:</label>  
                    <el-select  class="rio-select" name="Section" clearable filterable placeholder="Select Section" v-model="documents[index].sectionId">
                      <el-option
                      v-for="option in sections"
                      class="select-primary"
                      :value="option.value"
                      :label="option.label"
                      :key="option.label"
                      ></el-option>
                    </el-select>
                  </div>
                </div>
                <!-- <div class="col-md-5">
                  <div class="form-group">
                    <label for>Select File type    :</label>
                    <el-select class="rio-select"  multiple  placeholder="Select File Formats" v-model="documents[index].fileType">
                      <el-option
                        v-for="type in FileTypes"
                        class="select-primary"
                        :value="type.value"
                        :label="type.label"
                        :key="type.label"
                      ></el-option>
                    </el-select>
                  </div>
                </div> -->
                <div class="col-md-2">
                  
                  
                  <!-- <button v-if="index == 0" class="btn btn-primary mt-4" @click.prevent="validateDocument()">Add</button> -->
                  <div class="form-group">                    
                    <label for="" style="visibility:hidden">test</label><br>
                    <button v-if="index == 0" @click.prevent="validateDocument()" style="margin:0" class="btn btn-primary btn-icon" title="Add"><i class="fa fa-plus"></i></button>     
                      <button style="margin:0" v-if="!documents[index].server && index != 0" class="btn btn-danger btn-icon" @click.prevent="removeDocument(index)"><i class="fa fa-times"></i></button>
                      <button style="margin:0" v-if="documents[index].server && index!=0 && index!=documents.length " class="btn btn-danger btn-icon" @click.prevent="deleteDocument(documents[index].id)"><i class="fa fa-trash"></i></button>
                  </div>                  
                </div>
              </div>
            </div>            
          </div>
          <div class="col-md-12">
            <button class="btn btn-primary" type="submit" @click.prevent="validate">Save</button>
            <button class="btn btn-danger" @click.prevent="$emit('close')">Cancel</button>
          </div>
        </div>
      <!-- </div> -->
    </div>
  </div>
</template>
<script>
import swal from 'sweetalert2'
export default {
  props: ['data'],
  data() {
    return {
      actionType: 'create',
      id: '',
      showAdd:true,
      FileTypes: [
        { label: "PNG", value: "PNG" },
        { label: "JPG", value: "JPG" },
        { label: "JPEG", value: "JPEG" },
        { label: "PDF", value: "PDF" }
      ],
      DepartmentName: '',
      icon: '',
      image: '',
      documents: [{
        id: '',
        label: '',
        server: false,
        sectionId: ''
        // fileType: []
      }],
      sections: []
      
    };
  },
  methods: {
    // forceUpper (e, obj, prop) {
    //   const start = e.target.selectionStart
    //   e.target.value = e.target.value.toUpperCase()
    //   this.$set(obj, prop, e.target.value)
    //   e.target.setSelectionRange(start, start)
    // },
    selectAttachment:function($event){
        this.icon =$event.target.files[0]
        // const fr = new FileReader ()
        // fr.readAsDataURL($event.target.files[0])
				// fr.addEventListener('load', () => {
        //   this.imageSelected = true
        //   this.imageUrl = fr.result             
        // })
        // this.extension = this.attachment.name.split('.').pop()      
    },
    validate(){
      this.$validator.validateAll().then(isValid => {
        if(isValid){
          this.addDepartment()
        }
      })
    },
    addDepartment(){
      let formData = new FormData()
      formData.append('name',this.DepartmentName.toUpperCase())
      formData.append('id',this.id)
      formData.append('icon', this.icon)
      // formData.name = this.DepartmentName
      // formData.id = this.id
      let documents = this.documents
      var doc = new Array();
      let j=0
      documents.forEach(element => {
        doc[j]={};
        if(element.label || element.fileType){
          doc[j]['id']=element.id ? element.id : ''
          doc[j]['label']=element.label ? element.label.toUpperCase() : ''
          doc[j]['sectionId']=element.sectionId ? element.sectionId : ''
          // doc[j]['fileType']=element.fileType ? element.fileType : ''
        }
        j++
      });
      // formData.Docs = JSON.stringify(doc)
      formData.append('Docs',JSON.stringify(doc))
      let url = 'department/department/add_department'
      if(this.actionType == 'update'){
        url = 'department/department/edit_department'
      }
      this.$http.post(url, formData, {
        headers: {
						'Content-Type': 'multipart/form-data'
					}
      })
      .then(response => {
        let res = response.body
        if(res.status) {
          this.DepartmentName = '',
          this.documents = [{id: '',label: '', server: false}]
          this.$validator.reset()
          this.$emit('getData')
          swal({
            type: 'success',
            title: res.message
          })
        }
        else{
          swal({
            type: 'error',
            title: res.message
          })
        }
      })

    },
    validateDocument() {
      this.$validator.validateAll('documentScope').then(isValid => {
        if(isValid){
          this.addDocument()
        }
      })
    },
    addDocument(){
      if(this.actionType == 'create'){
        this.documents.push({id: '',label: '', server: false, section: ''})
      }      
      else{
        this.documents.splice(this.documents.length,0,{id: '',label: '', server: false})
      }
    },
    removeDocument(index){
      this.documents.splice(index,1)
    },
    getDocuments(){
      this.$http.post('department/department/list_department',
      {
        'id': this.data.id
      })
      .then(response => {
        let res = response.body
        if(res.status && res.hasrecords) {
          if(res.records[0].document_relation.length > 0){
            let documents = res.records[0].document_relation
            var doc = new Array();
            let i=0
            documents.forEach(element => {
              doc[i]={};
            if(element.id || element.label){
              doc[i]['id']=element.id ? element.id : ''
              doc[i]['label']=element.label ? element.label : ''
              doc[i]['sectionId']=element.sectionId ? element.sectionId : ''
              doc[i]['server']= true
            }
            i++
            });
            this.documents = doc
          }
        }
      })
    },
    deleteDocument(id){
        swal({
        type: 'question',
        title: '',
        text: 'Are you sure to delete document type?',
        showCancelButton: true,
        confirmButtonText: 'Reset',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
      })
      .then(result => {
        if (result) {
          this.$http.post('department/department/delete_label',{
            'id': id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getDocuments()
            }
          })
        }
      })
    },
    getSections(){
      this.$http.post('department/department/list_document_section',
      {
      })
      .then(response => {
        let res = response.body;
        let selectRes = [];
        if (res.status && res.hasrecords) {
          for (let key in res.records) {
            let result = [];
            result["value"] = res.records[key].id;
            result["label"] = res.records[key].name;
            selectRes.push(result);
          }
          this.sections = selectRes;
        }
      })
    }
  },
  created() {
    this.getSections()
    if(JSON.stringify(this.data) != '{}'){
      this.actionType = 'update'
      this.DepartmentName = this.data.name
      this.image = this.data.imageUrl ? this.data.imageUrl : ''
      this.id = this.data.id
      this.getDocuments()      
    }
  }
};
</script>

<style scoped>

.form-group input[type="file"]{
  opacity: 1;
  position: unset !important;
}
.card.form-card{
  overflow: hidden;
  transition: all .5s ease;
  /* max-height: 0px; */
  width:100%;
}
.form-card.slide{
  transition: all .5s ease;
  /* max-height:100vh; */

}
.rio-select input{
  background-color: rgb(255, 255, 255) !important;
  color: black !important;
}
.rio-select:hover input{
  color: black !important ;
}
</style>
