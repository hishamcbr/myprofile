<template>
  <div>
    <div class="row">
      <div class="col-md-12">
        <div class="col-md-12">
          <button @click="addComponent= true,showAdd = !showAdd " class="btn btn-primary">Add Department</button>
          <!-- <div class="add"  :class="{slide : showAdd }">
            <addDepartment  @getData="getData()" :data="departmentData"></addDepartment>  
          </div>           -->
        </div>            
      </div>      
    </div>    
    <ttable :page="page" @updateData="getData($event)" id="out-table" :noDataText="'hii'">
      <div class="col-md-6" slot="extra"></div>
      <div class="col-md-4" slot="extra">
        <div class="form-group pull-right" style="width:100%">
          <label class="filter-label">Search</label><br>           
          <input @keyup.prevent="getData()" v-model="searchKey"  type="text" class="search-box form-control" placeholder="Search Here">
          <i class="search-icon fa fa-search text-primary"></i>
        </div>
      </div>
      <el-table-column
        slot="actions"
        :min-width="55"
        fixed="right"
        label="Actions"
        id="action-column">
          <template slot-scope="props">
            <button class="btn btn-primary btn-icon btn-sm" @click.prevent="handleEdit(props.$index, props.row)" title="Edit"><i class="fa fa-edit"></i></button>
            <!-- <a class="btn btn-primary" @click.prevent="handleEdit(props.$index, props.row)" href="">Edit</a> -->
            <button class="btn btn-danger btn-icon btn-sm" @click.prevent="handleDelete(props.$index, props.row)" :disabled="props.row.delete_relation_count > 0" :title="props.row.delete_relation_count > 0 ? 'Cannot delete as Dept is assigned to hospitals ' : 'Delete'"><i class="fa fa-trash"></i></button>
            <!-- <a class="btn btn-danger" @click.prevent="handleDelete(props.$index, props.row)" :disabled="props.row.delete_relation_count > 0" :title="props.row.delete_relation_count > 0 ? 'Cannot delete as Dept is assigned to hospitals ' : 'Delete'" href="">Delete</a> -->
          </template>
        </el-table-column>
    </ttable>
    <el-dialog :show-close="false" :before-close="preventClose"  @close="closeModal" :title="actionType == 'create' ? 'Add Department' : 'Edit Department'" custom-class="addModal"  width="50%%" :visible.sync="showAdd" style="width:100%">
      <addDepartment v-if="addComponent" @getData="getData()" @close="closeModal" :data="departmentData"></addDepartment> 
    </el-dialog>
  </div>
</template>

<script>
import swal from 'sweetalert2'
import addDepartment from './AddDepartment'
import ttable from '../ServerTable.vue'
export default {
  components:{
    ttable,
    addDepartment
  },
  data(){
    return{
      searchKey: '',
      showAdd: false,
      addComponent: false,
      departmentData: {},
      actionType: 'create',
      page: {
         TotalPerPage: 10,
         total: 0,
         tableColumns: [],
         tableData: [],
         propsToSearch: [],
         selection: false,
         entries: true
       },
       columns: [
        {
          prop: 'name',
          label: 'Department Name',
          minWidth: 200,
          sortable: true
        },
        {
          prop: 'document_relation_count',
          label: 'No. of Documents',
          minWidth: 200,
          sortable: true
        }
      ],
    }
  },
  methods: {    
    preventClose() {
       
    },
    closeModal(){
      this.actionType = 'create'
      this.departmentData = {}
      this.showAdd = false
      this.addComponent = false
    },
    handleEdit(index, row){
      this.actionType = 'update'
      this.departmentData = row
      this.addComponent = true
      this.showAdd = true
    },
    handleDelete(index, row){
        swal({
        type: 'question',
        title: '',
        text: 'Are you sure to delete Department - '+row.name+ '?',
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
      })
      .then(result => {
        if (result) {
          this.$http.post('department/department/delete_department',{
            'id': row.id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getData()
            }
          })
        }
      })
    },
    getData(event){
      this.showAdd = false
      this.$http.post('department/department/list_department',
      {
        'pagination': 'TRUE',
        'currentPage': event ? event.CurrentPage : 1,
        'totalPerPage': this.page.TotalPerPage,
        'sortOrder': 'ASC',
        'searchKey': this.searchKey
      })
      .then(response => {
        let res = response.body
        this.page.tableColumns = this.columns
        if(res.status && res.hasrecords) {
          // upon response success set columns and table data
          this.page.total = res.records.total
          this.page.tableData = res.records.data
        }
      }) 
      
    }
  }



}
</script>
<style>
.addModal .el-dialog__body{
  padding-top: 0 !important;
}
.addModal .el-dialog__headerbtn{
  top: 10px;
  right:10px;
}
.addModal .el-dialog__title{
  font-weight: 600;
  color: #3d3f42;
}
/* .addModal .el-dialog__header{
  padding: 0;
} */
</style>


<style scoped>
.add{
  max-height: 0;
  overflow: hidden;
}
.add.slide{
  /* transition: all .5s ease; */
  max-height: 100%;
}
</style>
