<template>
  <div class="card p-3">
    <div class="card-header">
      <h4 class="card-title">Patient Details <a class="close-btn" @click.prevent="$emit('changeComponent','listing')" href=""><i style="margin-top:-20px" class="fa fa-times pull-right"></i></a></h4>
      <button @click.prevent="handleDischarge" style="margin: 0" v-if="data.status == 3" :disabled="data.uploadflag == 'NotCompleted'"  class="btn btn-sm btn-success">Request for Discharge</button>
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <patient-profile :data="profileData"></patient-profile>
        </div>
        <div class="col-md-6">
          <el-card class="v-up-dc" style="width:100%">
            <div slot="header" class="clearfix">
              <span>
                <h6 style="margin-bottom: 10px">
                  Uploaded Documents
                </h6>
                <div class="row">
                  <div class="col-md-12">
                    <button class="btn btn-sm btn-info" @click.prevent="showAll" style="margin:0 5px 0 0; padding:5px">Show All</button>
                    <button v-if="downloadButton" :disabled="!docExist || loading" style="margin:0 5px 0 0; padding:5px" class="btn btn-sm btn-success" @click.prevent="handleDownload">
                      {{ loading ? 'Downloading' : 'Download'}} <i v-if="loading" class="el-icon-loading"></i>
                    </button>
                    <button v-if="uploadButton" style="margin:0; padding:5px" class="btn btn-sm btn-warning" @click.prevent="$emit('uploadFromView',data)">
                      Upload
                    </button>
                  </div>
                </div>
              </span>
            </div>
            <div class="col-md-12">
              <div  v-for="(option, index) in labels" :key="index">
                <el-card>
                  <!-- <div slot="header" class="clearfix">
                    <span><h6 style="margin-bottom: 0">{{option.label}}</h6></span>
                  </div> -->
                  <label>{{option.label}}</label><br>


                  <!-- <span v-viewer>
                    <span  v-for="image in option.images" :key="image.image">
                      <span v-if="image.extension == 'png' || image.extension == 'jpg' || image.extension == 'jpeg'">
                        <span v-if="image.image" style="position:relative; margin-right: 10px">
                            <img style="width:15%;display: inline-block;cursor:pointer;position:relative"   :src="image.image">
                            <el-badge value="new" style="z-index:9999;position:absolute;left:50%;"></el-badge>
                            <a v-if="imageClose" @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" style="position: absolute;top: -15px;right:-5px"><i class="fa fa-times"></i></span></a>
                        </span>
                      </span>
                    </span>
                  </span> -->

                  <div v-viewer>
                    <div class="rio-img-thumb"  v-for="image in option.images" :key="image.image">
                      <span v-if="image.extension == 'png' || image.extension == 'jpg' || image.extension == 'jpeg'">
                        <div v-if="image.image" class="in-thumb" >
                            <img :src="image.image">
                          <div class="new-tag" v-show="image.downloaded == 1 || image.downloaded == 3">New</div>
                            <a v-if="imageClose" @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" ><i class="fa fa-times"></i></span></a>
                        </div>
                      </span>
                    </div>
                  </div>


                  <span v-for="image in option.images" :key="image.image">
                    <span v-if="image.extension == 'pdf'">
                      <span v-if="image.image" style="position:relative; margin-right: 10px">
                        <a @click.prevent="openDocument(image.image)" href><img style="display: inline-block;" @click.prevent="" width="15%" src=/static/img/pdf-icon.png></a>
                        <a v-if="imageClose" @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" style="position: absolute;top: -15px;right:-5px"><i class="fa fa-times"></i></span></a>
                      </span>
                    </span>
                  </span>
                </el-card>
              </div>
            </div>
          </el-card>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <!-- <button type="button" @click="show">Show</button> -->
          <div class="all-doc" v-viewer="{movable: false}">
            <img style="display:none" v-for="src in images" :src="src" :key="src">
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import 'viewerjs/dist/viewer.css'
import Viewer from 'v-viewer'
import Vue from 'vue'
Vue.use(Viewer)
import PatientProfile from './PatientProfile.vue'
import swal from 'sweetalert2'
import moment from 'moment'
export default {
  props: ['data','imageClose','uploadButton','downloadButton'],
  components: {
    PatientProfile
  },
  data(){
    return{
      docExist: false,
      profileData: {},
      labels: [],
      loading: false,
      images: []
    }
  },
  methods: {
    showAll () {
      const viewer = this.$el.querySelector('.all-doc').$viewer
      viewer.show()
    },
    handleDownload(){
      if(this.data.id){
        this.loading = true
        this.$http.post("patient/patient/zipping_patient", {
            id: this.data.id
          })
          .then(response => {
            let res = response.body;
            this.loading = false
            if(res.status){
              window.location.href = res.records
              this.getData()
            }
            else{
              swal({
                type: "error",
                title: res.message
              });
            }
          });
      }
      else{
        swal({
              type: "error",
              title: 'Unable to download documents'
            });
      }
    },
    openDocument(document){
      window.open(document, "_blank");
      // console.log(document)
    },
    showDoc(){
      console.log('hii')
    },
    handleDischarge() {
      swal({
        type: "question",
        title: "",
        text: "Are you sure to request for discharge?",
        showCancelButton: true,
        confirmButtonText: "Request",
        confirmButtonColor: "#1576c2",
        cancelButtonColor: "#fbc658"
      }).then(result => {
        if (result) {
          this.$http
            .post("patient/patient/request_for_discharge", {
              id: this.data.id
            })
            .then(response => {
              let res = response.body;
              swal({
                type: res.status ? "success" : "error",
                title: res.message
              });
              if (res.status) {
                this.$emit('changeComponent','listing');
              }
            });
        }
      });
    },
    deleteDocument(id){
      swal({
        type: "question",
        title: "",
        text: "Are you sure to delete document ?",
        showCancelButton: true,
        confirmButtonText: "Delete",
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6"
      }).then(result => {
        if (result) {
          this.$http.post("patient/patient/delete_uploaded_document", {
              id: id
            })
            .then(response => {
              let res = response.body;
              swal({
                type: res.status ? "success" : "error",
                title: res.message
              });
              if (res.status) {
                this.getLabels();
              }
            });
        }
      });
    },
    getLabels(){
      if(this.data.departmentId){
        this.$http.post('patient/patient/list_document_patient',
        {
          id: this.data.id
        })
        .then(response => {
          let res = response.body
          let selectRes = []
          if(res.status && res.hasrecords && res.records[0].document_relation.length > 0) {
            for (let key in res.records[0].document_relation) {
              let result = []
              result['label'] = res.records[0].document_relation[key].label
              result['labelId'] = res.records[0].document_relation[key].id
              result['cardId'] = res.records[0].cardId
              result['patientId'] = res.records[0].id
              result['departmentId'] = res.records[0].departmentId
              result['loading'] = false
              let images = []
              if(res.records[0].document_relation[key].upload_relation.length > 0){
                for(let key1 in res.records[0].document_relation[key].upload_relation){
                  this.docExist = true
                  let imageData = []
                  imageData['image'] = res.records[0].document_relation[key].upload_relation[key1].documentName
                  imageData['extension'] = res.records[0].document_relation[key].upload_relation[key1].ext
                  imageData['downloaded'] = res.records[0].document_relation[key].upload_relation[key1].downloaded
                  //store image for show all
                  if(imageData['extension'] == 'jpg' || imageData['extension'] == 'jpeg' || imageData['extension'] == 'png'){
                    this.images.push(imageData['image'])
                  }
                  imageData['imageId'] = res.records[0].document_relation[key].upload_relation[key1].id
                  images.push(imageData)
                }
              }
              result['images'] = images
              selectRes.push(result)
            }
            this.labels = selectRes
          }
          else{
            this.labels = []
          }
        })
      }
    }
  },
  created(){
    if(JSON.stringify(this.data) != '{}'){
      this.profileData = this.data
    }
    this.getLabels()
  }
};
</script>

<style scoped>
.form-group input[type="file"]{
  opacity: 1;
  position: unset !important;
}
label{
  color: #6c6666 !important;
}
</style>
