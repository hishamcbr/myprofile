<template>
  <div>
    <div v-show="sections.listing">
      <ttable @changeReset="changeReset" :reset="tableReset" @selected="selectedRows" v-loading="loading" :page="page" @updateData="getData($event)" id="out-table" :noDataText="'hii'">
        <template :slot="'titleTable'">
          <h5 class="card-title">{{this.$route.name}}</h5>
        </template>
        <el-table-column
          slot="select"
          type="selection"
          width="55">
        </el-table-column>
        <div slot="export" class="form-group">
          <label class="filter-label mb0">Export</label><br>
            <el-dropdown style="width:100%" placement="top-end" trigger="click" @command="exportToExcel">
                <el-button class="excel-button" type="primary" style="width:100%">
                    Excel<i class="el-icon-arrow-down el-icon--right"></i>
                </el-button>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item icon="el-icon-document-copy" :disabled="page.total <= 0" command="all">All</el-dropdown-item>
                    <el-dropdown-item icon="el-icon-document" :disabled="selected.length <= 0" command="selected">Selected</el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
        <div slot="date">
          <label class="filter-label mb0">Admission Date Filter</label>
          <el-date-picker style="width:100%"
                  v-model="dateFilter"
                  type="daterange"
                  range-separator="To"
                  start-placeholder="From"
                  end-placeholder="To" @change="dateChanged">
          </el-date-picker>
        </div>          
        <div slot="search" class="form-group search-container"> 
          <label class="filter-label mb0">Search</label><br>           
            <input @keyup.prevent="getData()" v-model="searchKey"  type="text" class="search-box form-control" placeholder="Search Here">
            <i class="search-icon fa fa-search text-primary"></i>
        </div>
        <div slot="more-filters">
          <div class="row" style="margin:0">
            <div class="col-md-4">
              <div class="form-group">
                <label class="filter-label mb0" for>Select Department</label>
                <el-select @change="getData()" style="width:100%" name="Departments" class="department-filter" clearable filterable placeholder="Select Department" v-model="departmentId">
                  <el-option
                  v-for="option in departments"
                  :value="option.value"
                  :label="option.label"
                  :key="option.label"
                  ></el-option>
                </el-select>
              </div>
            </div>
            <div class="col-md-8">
              <label class="filter-label mb0" for>Downloaded Filter</label><br>
              <button @click.prevent="downloaded = '',getData()" class="mt0 btn-input btn btn-outline-default btn-default " :class="downloaded == '' ? 'active' : ''">All</button>
              <button @click.prevent="downloaded = 1,getData()" class="mt0 btn-input btn btn-outline-warning btn-warning " :class="downloaded == 1 ? 'active' : ''">Not Downloaded</button>
              <button @click.prevent="downloaded = 2,getData()" class="mt0 btn-input btn btn-outline-danger btn-danger " :class="downloaded == 2 ? 'active' : ''">Downloaded</button>
              <button @click.prevent="downloaded = 3,getData()" class="mt0 btn-input btn btn-outline-info btn-info " :class="downloaded == 3 ? 'active' : ''">Re-Uploaded</button>
            </div>
          </div>          
        </div>
        <el-table-column
          slot="actions"
          :min-width="155"
          fixed="right"
          label="Actions"
          id="action-column" >
          <template slot-scope="props">
            <!-- <button class="btn btn-primary btn-icon btn-sm" @click.prevent="handleRegisterNumber(props.$index, props.row)" title="Fill Register No">  <i class="fa fa-file-text" aria-hidden="true"></i></button> -->
            <button class="btn btn-danger btn-icon btn-sm" @click.prevent="handleDownload(props.$index, props.row)" title="Download Documents">  <i class="fa fa-download" aria-hidden="true"></i></button>
            <button class="btn btn-success btn-icon btn-sm" @click.prevent="handleView(props.$index, props.row)" title="View">  <i class="fa fa-eye" aria-hidden="true"></i></button>
            <button v-if="isAdmin" class="btn btn-danger btn-icon btn-sm" @click.prevent="handleDelete(props.$index, props.row)" title="Delete Patient">  <i class="fa fa-trash" aria-hidden="true"></i></button>
            <!-- <button class="btn btn-warning btn-icon btn-sm" @click.prevent="handleUpload(props.$index, props.row)" title="Upload Documents">  <i class="fa fa-upload" aria-hidden="true"></i></button> -->
          </template>
        </el-table-column>
      </ttable>
    </div>
    <upload-document v-if="sections.upload" @changeComponent= "changeComponent" :data="uploadData"></upload-document>
    <view-patient v-if="sections.view" :downloadButton="true" @changeComponent= "changeComponent" :imageClose="false" :data="uploadData"></view-patient>
    <el-dialog title="Fill Register Number" width="35%" :visible.sync="registerNumberModal" style="">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label for="">Register Number</label>
            <input v-model="registerNumber" class="form-control" type="text" name="Register Number" data-vv-scope="registerNumberScope" placeholder="Enter Register Number" v-validate="'required'">
            <small class="text-danger">
              {{ errors.first('registerNumberScope.Register Number') }}  
            </small> 
          </div>
        </div>
        <input type="hidden" v-model="hiddenId">
        <div class="col-md-12">
            <span slot="footer" class="dialog-footer">
                <button class="btn btn-sm btn-fill btn-success" @click.prevent="validateRegisterNumber()">Update</button>
                <button class="btn btn-sm btn-fill btn-primary" @click.prevent="registerNumberModal=false">Cancel</button>
            </span>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import FileSaver from 'file-saver'
import XLSX from 'xlsx'
import UploadDocument from './UploadDocument.vue'
import ViewPatient from './ViewPatient.vue'
import ttable from "../../../../ServerTable1.vue";
import moment from 'moment'
import swal from 'sweetalert2'
export default {
  components: {
    ttable,
    UploadDocument,
    ViewPatient
  },
  data() {
    return {
      departmentId: '',
      departments: [],
      downloaded: '',
      tableReset: 'no',
      selected: [],
      isAdmin: false,
      searchKey: '',
      fromDate: '',
      toDate: '',
      dateFilter: '',
      hiddenId: '',
      registerNumber: '',
      registerNumberModal: false,
      loading: true,
      showAdd: false,
      departmentData: {},
      uploadData: {},
      page: {
        TotalPerPage: 10,
        total: 0,
        tableColumns: [],
        tableData: [],
        propsToSearch: [],
        selection: false,
        entries: true
      },
      columns: [        
        {
          prop: "name",
          label: "Patient Name",
          minWidth: 200,
          sortable: true
        },
        {
          prop: "registerNumber",
          label: "Reg No.",
          minWidth: 140,
          sortable: true
        },
        {
          prop: "opNumber",
          label: "OP No.",
          minWidth: 120,
          sortable: true
        },
        {
          prop: "ipNumber",
          label: "IP No",
          minWidth: 120,
          sortable: true
        },
        {
          prop: "cardId",
          label: "Card ID",
          minWidth: 150,
          sortable: true
        },
        {
          prop: "date",
          label: "DOA",
          minWidth: 120,
          sortable: true
        },
      ],
      sections: {
        listing: true,
        upload: false,
        view: false
      },
    };
  },
  methods: {
    getDepartments() {
      this.$http.post('department/department/list_department',{})
      .then(response => {
        let res = response.body
        let selectRes = []
        if(res.status && res.hasrecords) {
          for (let key in res.records) {
            let result = []
            result['label'] = res.records[key].name
            result['value'] = res.records[key].id
            selectRes.push(result)
          }
          this.departments = selectRes
        }
      })
    },
    changeReset(){
      this.tableReset = 'no'
    },
    selectedRows(rows){
      this.selected = rows
    },
    exportToExcel(value){       
        let cook= this.$cookies.get('kasp-pmjay')
        this.loading = true
        let id=[]
        if(value == 'all'){
          id = []
        }
        else{
          id = []
          for(let key in this.selected){
            id.push(this.selected[key].id)
          }
        }
        this.$http.post("patient/patient/export_reg_patient_excel", {
            userId: cook.UserId,
            hospitalId: cook.hospitalId,
            id: id,
            status: 3,
            fromDate: this.fromDate,
            toDate: this.toDate,
            searchKey: this.searchKey
          })
          .then(response => {
            let res = response.body;
            this.loading = false
            if(res.status){
              this.tableReset = 'reset'
              window.location.href = res.records
            }
            else{
              swal({
                type: "error",
                title: res.message
              });
            }
            
          });
    },
    handleDelete(index,row){
      let id = []
      id.push(row.id)
      swal({
        type: 'question',
        title: '',
        text: 'Are you sure to delete patient?',
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
        })
      .then(result => {
        if (result) {
          this.$http.post('patient/patient/delete_patient',{
            'id': id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getData()
            }
          })
        }
      })
    },
    handleDownload(index, row){
      this.loading = true
      this.$http.post("patient/patient/zipping_patient", {
          id: row.id
        })
        .then(response => {
          let res = response.body;
          this.loading = false
          if(res.status){
            window.location.href = res.records
            this.getData()
          }
          else{
            swal({
              type: "error",
              title: res.message
            });
          }
          // swal({
          //   type: res.status ? "success" : "error",
          //   title: res.message
          // });
          
        });
      // this.loading = true
    },
    handleExport() {
      let table = document.querySelector("#out-table").cloneNode(true)
      let selectheader = table.querySelector(".el-table-column--selection")
      selectheader.parentNode.removeChild(selectheader)
      let tbody = table.querySelector(".el-table__body")
      let select = tbody.querySelectorAll('.el-table-column--selection')

      let action = table.querySelector(".is-hidden")
      action.parentNode.removeChild(action)
      for (let i = 0; i < select.length; i++){
        select[i].parentNode.removeChild(select[i])
      }
      let fixed = table.querySelector(".el-table__fixed-right")
      fixed.parentNode.removeChild(fixed);
      var wb = XLSX.utils.table_to_book(table);
      var wbout = XLSX.write(wb, {
          bookType: "xlsx",
          bookSST: true,
          type: "array"
      });
      try {
          FileSaver.saveAs(
          new Blob([wbout], { type: "application/octet-stream" }),
          "completed-patient-list-"+moment().format('DD-MM-YYYY')+".xlsx"
          );
      } catch (e) {
          if (typeof console !== "undefined") console.log(e, wbout);
      }
      return wbout;
    },
    dateChanged(){
      this.fromDate = this.dateFilter ? moment(this.dateFilter[0]).format('YYYY-MM-DD') : ''
      this.toDate = this.dateFilter ? moment(this.dateFilter[1]).format('YYYY-MM-DD') : ''
      this.getData()
    },
    handleUpload(index, row){
      this.uploadData = row
      this.showComponent('upload')
    },
    handleView(index, row){
      this.uploadData = row
      this.showComponent('view')
    },
    validateRegisterNumber(){
      this.$validator.validateAll('registerNumberScope').then(isValid => {
        if(isValid){
          this.submitRegisterNumber()
        }
      })
    },
    submitRegisterNumber(){
      let formData = {}
      formData.id = this.hiddenId
      formData.registerNumber = this.registerNumber
      let url = 'patient/patient/update_reg_no_manualy'
      this.$http.post(url, formData)
      .then(response => {
        let res = response.body
        if(res.status) {
          this.hiddenId = ''
          this.registerNumber = ''
          this.$validator.reset()
          this.getData()
          this.registerNumberModal = false
          swal({
            type: 'success',
            title: res.message
          })
        }
        else{
          swal({
            type: 'error',
            title: res.message
          })
        }
      })
    },
    handleRegisterNumber(index, row){
      this.hiddenId = row.id
      this.registerNumber = ''
      this.registerNumberModal = true
    },
    handleUpload(index, row){
      this.uploadData = row
      this.showComponent('upload')
    },
    changeComponent(value){
      this.showComponent(value)
    },
    showComponent(value) {
      this.sections = {
        listing: false,
        upload: false,
        view: false
      };
      for (var p in this.sections) {
        if (p == value) {
          this.sections[p] = true;
        }
      }
    },
    getData(event) {
      this.loading = true
      this.showAdd = false;
      let cook = this.$cookies.get('kasp-pmjay')
      this.$http.post("patient/patient/list_reg_patient", {
        downloaded: this.downloaded,
        departmentId: this.departmentId,
        status: 4,
        hospitalId: cook.hospitalId,
        FromDate: this.fromDate,
        ToDate: this.fromDate,
        searchKey: this.searchKey,
        pagination: "TRUE",
        currentPage: event ? event.CurrentPage : 1,
        totalPerPage: this.page.TotalPerPage,
        sortOrder: "DESC",
        MoreDetails: 'TRUE'
      })
      .then(response => {
        let res = response.body;
        this.page.tableColumns = this.columns;
        if (res.status && res.hasrecords) {
          for(let key in res.records.data){
            res.records.data[key].date = moment(res.records.data[key].doa).format('DD-MM-YYYY')
          }
          this.page.total = res.records.total;
          this.page.tableData = res.records.data;
        }
        this.loading = false
      });
    },
    
  },
  created(){
      this.getDepartments()
      let cook = this.$cookies.get('kasp-pmjay')
      if(cook.userType == 1){
        this.isAdmin = true
      }
    }
};
</script>

<style>
</style>
