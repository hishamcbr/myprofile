<template>
  <div>
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">{{ actionType == 'create' ? 'Add Patient' : 'Edit Patient' }} <a @click.prevent="$emit('changeComponent','listing')" href=""><i style="margin-top:-20px" class="fa fa-times pull-right"></i></a></h4>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-12">
            <a href="http://pmjay.sevensigma.in/api/v1/sample/Sample_Patient Import format.xlsx" class="btn btn-sm btn-primary" download>Download Sample</a>
            <button @click.prevent="uploadExcel(1)" class="btn btn-sm btn-success">Import Dialysis Patients</button>
            <button @click.prevent="uploadExcel(2)" class="btn btn-sm btn-default">Import other Patients</button>
          </div>
        </div>
        <br>
        <div class="row">          
          <div class="col-md-4">
            <div class="form-group">
              <label for>Patient Name <span class="text-danger">*</span> :</label>
              <input type="text" class="form-control" v-model="patientData.name" placeholder="Enter Patient Name" v-validate="'required'" name="Patient Name">
              <small class="text-danger">
                {{ errors.first('Patient Name') }}
              </small>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for>OP/MR No.<span class="text-danger">*</span> :</label>
              <input  type="text" class="form-control" v-model="patientData.opNumber" placeholder="OP/MR No." v-validate="'required'" name="OP/MR Number">
              <small class="text-danger">
                {{ errors.first('OP/MR Number') }}
              </small>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for>Card ID<span class="text-danger">*</span> :</label>
              <input type="text" class="form-control" v-model="patientData.cardId" placeholder="Enter ID Number" v-validate="'required'" name="ID Number">
              <small class="text-danger">
                {{ errors.first('ID Number') }}
              </small>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for>Mobile Number <span class="text-danger">*</span> :</label>
              <input type="text" class="form-control" v-model="patientData.mobileNumber" placeholder="Mobile Number" v-validate="'required'"  name="Mobile Number">
              <small class="text-danger">
                {{ errors.first('Mobile Number') }}
              </small>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
                <label for>Patient Type <span class="text-danger">*</span> :</label>
                <el-select v-validate="'required'" name="Patient Type" class="rio-select" clearable filterable placeholder="Select Patient Type" v-model="patientData.patientType">
                    <el-option
                    v-for="type in patientTypes"
                    class="select-primary"
                    :value="type.value"
                    :label="type.label"
                    :key="type.label"
                    ></el-option>
                </el-select>
                <small class="text-danger">
                  {{errors.first('Patient Type')}}
                </small>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for>Gender:</label><br>
              <el-radio-group v-validate="'required'" name="Gender"  style="width:100%" v-model="patientData.gender">
                <el-radio label="Male">Male</el-radio>
                <el-radio label="Female">Female</el-radio>
              </el-radio-group>
              <small class="text-danger">
                {{errors.first('Gender')}}
              </small>
              </div>
          </div>
          <div class="col-md-12">
            <button class="btn btn-primary" type="submit" @click.prevent="validate">{{actionType == 'create' ? 'Save' : 'Update'}}</button>
          </div>
        </div>
      </div>
    </div>
    <el-dialog :show-close="false" :before-close="preventClose" title="Upload Excel" width="35%" :visible.sync="uploadModal" style="">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label for="">Select File</label>
            <input ref="document" @change="selectAttachment" name="File" type="file" class="form-control" data-vv-scope="uploadScope"  v-validate="'required'">
            <small class="text-danger">
              {{ errors.first('uploadScope.File') }}  
            </small> 
          </div>
        </div>
        <div class="col-md-12">
            <span slot="footer" class="dialog-footer">
                <button v-if="!loadingButton" class="btn btn-sm btn-fill btn-success" @click.prevent="validateUpload()">Upload</button>
                <el-button class="btn-sm" v-if="loadingButton" type="primary" :loading="true">Uploading...</el-button>
                <button :disabled="loadingButton" class="btn btn-sm btn-fill btn-primary" @click.prevent="uploadModal=false">Cancel</button>
            </span>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import swal from 'sweetalert2'
export default {
  props: ['data'],
  data() {
    return {
      uploadModal: false,
      attachment: '',
      uploadType: '',
      actionType: 'create',
      loadingButton: false,
      patientData: {
        PatientMasterId: '',
        name: '',
        opNumber: '',
        cardId: '',
        mobileNumber: '',
        gender: '',
        patientType: ''
      },
      patientTypes: [
        { label: 'Dialysis Patient', value: 1},
        { label: 'Other', value: 2}
      ]
    };
  },
  methods: {
    preventClose() {
       
    },
    validateUpload(){
      this.$validator.validateAll('uploadScope').then(isValid => {
        if(isValid){
          this.loadingButton = true
          this.uploadDocument()
        }
      })
    },
    uploadDocument(){
      let cook = this.$cookies.get('kasp-pmjay')
      let form_data = new FormData()
      // formData.patientType = this.uploadType
      // formData.patientcsv = this.attachment
      form_data.append('hospitalId',cook.hospitalId)
      form_data.append('patientType',this.uploadType)
      form_data.append('patientcsv',this.attachment)
      // form_data.append('file',this.imageUrl)
      // form_data.append('labelId',this.uploadData.labelId)
      // form_data.append('registrationId',this.uploadData.registrationId)
      this.$http.post('patient/patient/import_patient', form_data, {
        headers: {
						'Content-Type': 'multipart/form-data'
					}
        }).then(response => {
        let res = response.body;
        if (res.status) {
          this.$refs.document.value = ''
          // document.getElementById('upload').value='';
          this.loadingButton = false
          swal({
            type: "success",
            title: res.message.message
          });
          this.$emit('changeComponent','listing')
          // this.$router.push('/HospitalLayout/PatientPendingList')
        } else {
          // this.$refs.document.value = ''
          // document.getElementById('upload').value='';
          this.loadingButton = false
          swal({
            type: "error",
            title: res.message.message
          });
        }
      });
    },
    uploadExcel(val){
      this.loadingButton = false
      this.uploadType = val
      this.uploadModal = true 
      if(this.$refs.document){
        this.$refs.document.value = ''
      }
                
    },
    selectAttachment:function($event){
        this.attachment =$event.target.files[0]
        // const fr = new FileReader ()
        // fr.readAsDataURL($event.target.files[0])
				// fr.addEventListener('load', () => {
        //   this.imageSelected = true
        //   this.imageUrl = fr.result             
        // })
        // this.extension = this.attachment.name.split('.').pop()      
    },
    validate(){
      this.$validator.validateAll().then(isValid => {
        if(isValid){
          this.addPatient()
        }
      })
    },
    addPatient(){
      let cook = this.$cookies.get('kasp-pmjay')
      let formData = this.patientData
      formData.hospitalId = cook.hospitalId

      let url = 'patient/patient/add_patient_master'
      if(this.actionType == 'update'){
        url = 'patient/patient/edit_patient_master'
      }
      this.$http.post(url, formData)
      .then(response => {
        let res = response.body
        if(res.status) {
          this.$validator.reset()
          this.$emit('changeComponent','listing')
          swal({
            type: 'success',
            title: res.message
          })
        }
        else{
          swal({
            type: 'error',
            title: res.message
          })
        }
      })

    },
  },
  created() {
    if(JSON.stringify(this.data) != '{}'){
      this.actionType = 'update'
      this.patientData.PatientMasterId = this.data.id
      this.patientData.name = this.data.name ? this.data.name : ''
      this.patientData.mobileNumber = this.data.mobileNumber ? this.data.mobileNumber : ''
      this.patientData.opNumber = this.data.opNumber ? this.data.opNumber : '',
      this.patientData.cardId = this.data.cardId ? this.data.cardId : ''
      this.patientData.patientType = this.data.patientType ? this.data.patientType : ''    
      this.patientData.gender = this.data.gender ? this.data.gender : ''  
    }
  }
};
</script>
<style scoped>

.form-group input[type="file"]{
  opacity: 1;
  position: unset !important;
}
.card.form-card{
  overflow: hidden;
  transition: all .5s ease;
  /* max-height: 0px; */
  width:50%;
}
.form-card.slide{
  transition: all .5s ease;
  /* max-height:100vh; */

}
.rio-select input{
  background-color: rgb(255, 255, 255) !important;
  color: black !important;
}
.rio-select:hover input{
  color: black !important ;
}
</style>
