<template>
    <div>
        <div class="row" style="margin:0">
            <el-card style="width:100%">
                <div slot="header" class="clearfix">
                <span><h6 style="margin-bottom: 0">Patient Profile</h6> <el-tag v-if="data.status == 2" class="pull-right" type="warning">Waiting for Register Number</el-tag></span>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <label for>Name</label>
                        <p>{{ data.name }}</p>
                        <label for>OP/MR No.</label>
                        <p>{{ data.opNumber }}</p> 
                        <label for>Date of Admission</label>
                        <p>{{ data.doa }}</p>
                    </div>
                    <div class="col-md-4">
                        <label for>Mobile Number</label>
                        <p>{{ data.mobileNumber }}</p>
                        <label for>Card ID</label>
                        <p>{{ data.cardId }}</p>
                        <label for>Department</label>
                        <p>{{ data.department_relation ? data.department_relation.name : '' }}</p>
                    </div>
                    <div class="col-md-4">
                        <label for>Gender</label>
                        <p>{{ data.gender }}</p>
                        <label for>IP No.</label>
                        <p>{{ data.ipNumber }}</p>
                        <span v-if="data.patientType != 1">
                            <label for>Doctor</label>
                            <p>{{ data.doctor_relation ? data.doctor_relation.name : '' }}</p>
                        </span>
                        <span v-if="data.patientType == 1">
                            <label for>Next Dialysis</label>
                            <p>{{ nextDialysis ? nextDialysis : '' }}</p>
                        </span>
                    </div>
                    <div class="col-md-12" v-if="data.patientType != 1">
                        <label for>Diagnosis</label>
                        <p>{{ data.diagnosis }}</p>
                    </div>
                </div>
            </el-card>
        </div>
    </div>
</template>
<script>
import moment from 'moment'
export default {
    props: ['data'],
    data (){
        return {
            nextDialysis: ''
        }
    },
    created(){
       if(this.data.nextDialysis){
           this.nextDialysis = moment(this.data.nextDialysis).format('DD-MM-YYYY')
       }
    }
    
}
</script>
<style scoped>
label{
  color: #6c6666 !important;
}
</style>



