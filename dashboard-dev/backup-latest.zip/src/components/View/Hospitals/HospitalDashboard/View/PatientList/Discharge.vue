<template>
  <div class="card p-3">
    <div class="card-header">
      <h4 class="card-title">Upload Documents<a @click.prevent="$emit('changeComponent','listing')" href=""><i style="margin-top:-20px" class="fa fa-times pull-right"></i></a></h4>
    </div>
    <div class="card-body">
      <vue-tabs class="card-content" v-model="tabName">
        <v-tab title="Patient Profile">
          <patient-profile :data="profileData"></patient-profile>
        </v-tab>
        <v-tab title="Upload Documents" style="width:100%">
          <div class="row" style="margin:0">
            <el-card style="width:50%">
              <div slot="header" class="clearfix">
                <span><h6 style="margin-bottom: 0">Upload Documents</h6></span>
              </div>
              <!-- <div class="col-md-12"> -->
              <div v-for="(option, index) in labels" :key="index">
                <div class="row">
                  <div class="col-md-10" style="padding:0">
                    <div class="form-group">
                      <label>{{option.label}}</label><br>
                      <input ref="document" type="file" v-validate="'required'" :data-vv-scope="'uploadScope'+option.labelId" :name="option.label+' Document'"  class="form-control"  @change="selectAttachment($event,index)">
                      <small class="text-danger">
                        {{ errors.first('uploadScope'+option.labelId+'.'+option.label+' Document') }}
                      </small>
                    </div>                      
                  </div>
                  <div class="col-md-2">
                    <label style="visibility:hidden">Hidden</label>
                    <button v-if="!option.loading && uploadButtons" style="" class="btn btn-icon btn-warning"  @click.prevent="validate(option,index)"><i class="fa fa-upload"></i></button>
                    <el-button v-if="option.loading" type="primary" :loading="true"></el-button>
                  </div>
                </div>
              </div>
            </el-card>
            <el-card style="width:50%">
              <div slot="header" class="clearfix">
                <span><h6 style="margin-bottom: 0">Uploaded Documents</h6></span>
              </div>
              <div class="col-md-12">
                <div  v-for="(option, index) in labels" :key="index">
                  <el-card>
                    <!-- <div slot="header" class="clearfix">
                      <span><h6 style="margin-bottom: 0">{{option.label}}</h6></span>
                    </div> -->
                    <label>{{option.label}}</label><br>
                      <!-- <span v-viewer>
                        <span  v-for="image in option.images" :key="image.image">
                          <span v-if="image.extension == 'png' || image.extension == 'jpg' || image.extension == 'jpeg'">
                            <span v-if="image.image" style="position:relative; margin-right: 10px">                            
                              <img style="display: inline-block;cursor:pointer"  width="15%" :src="image.image">
                              <a @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" style="position: absolute;top: -15px;right:-5px"><i class="fa fa-times"></i></span></a>
                            </span>
                          </span>
                        </span>
                      </span> -->
                      <div v-viewer>
                        <div class="rio-img-thumb"  v-for="image in option.images" :key="image.image">
                          <span v-if="image.extension == 'png' || image.extension == 'jpg' || image.extension == 'jpeg'">
                            <div v-if="image.image" class="in-thumb" >                            
                                <img :src="image.image">
                              <div class="new-tag" v-show="image.downloaded == 1 || image.downloaded == 3">New</div>
                                <a v-if="imageClose" @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" ><i class="fa fa-times"></i></span></a>
                            </div>                        
                          </span>
                        </div>
                      </div>
                      
                    <!-- </viewer> -->
                    <!-- <div class="clearfix"></div> -->
                    <span v-for="image in option.images" :key="image.image">
                      <span v-if="image.extension == 'pdf'">
                        <span v-if="image.image" style="position:relative; margin-right: 10px">                            
                          <a @click.prevent="openDocument(image.image)" href><img style="display: inline-block;" @click.prevent="" width="15%" src=/static/img/pdf-icon.png></a>
                          <a @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" style="position: absolute;top: -15px;right:-5px"><i class="fa fa-times"></i></span></a>
                        </span>
                      </span>
                    </span>

                    <!-- <img @click.prevent="" width="15%" v-else src=/static/img/pdf-icon.png> -->
                  </el-card>                  
                </div>
              </div>
            </el-card>
          </div>
        </v-tab>
      </vue-tabs>
    </div>
  </div>
</template>

<script>
import 'viewerjs/dist/viewer.css'
import Viewer from 'v-viewer'
import Vue from 'vue'
Vue.use(Viewer)
import PatientProfile from './PatientProfile.vue'
import swal from 'sweetalert2'
import moment from 'moment'
export default {
  props: ['data'],
  components: {
    PatientProfile
  },
  data(){
    return{
      tabName: 'Upload Documents',
      profileData: {},
      labels: [],
      attachment: '',
      file: '',
      extension: '',
      uploadButtons: true  
    }
  },
  methods: {
    openDocument(document){
      window.open(document, "_blank");
      // console.log(document)
    },
    deleteDocument(id){
      swal({
        type: "question",
        title: "",
        text: "Are you sure to delete document ?",
        showCancelButton: true,
        confirmButtonText: "Delete",
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6"
      }).then(result => {
        if (result) {
          this.$http.post("patient/patient/delete_uploaded_document", {
              id: id
            })
            .then(response => {
              let res = response.body;
              swal({
                type: res.status ? "success" : "error",
                title: res.message
              });
              if (res.status) {
                this.getLabels();
              }
            });
        }
      });
    },
    validate(option,index){
      // console.log(this.labels[index].loading)
      this.$validator.validateAll('uploadScope'+option.labelId).then(isValid => {
        if(isValid){
          this.uploadButtons = false
          this.labels[index].loading = true
          this.uploadDocument(option)
        }
      })
    },
    uploadDocument(option){
      let formData = {}
      formData.labelId = option.labelId
      formData.status = option.status
      formData.registrationId = option.patientId
      formData.cardId = option.cardId
      formData.departmentId = option.departmentId
      formData.file = this.file
      formData.ext = this.extension
      this.$http.post('patient/patient/cloud_upload', formData).then(response => {
        let res = response.body;
        if(res.status) {
          if(this.$refs.document){
            for(let key in this.$refs.document){
              this.$refs.document[key].value = ''
            }
          }
          this.uploadButtons = true
          this.file=''
          this.extension=''
          this.getLabels()
          swal({
            type: "success",
            title: res.message
          });
          // this.$router.push('/HospitalLayout/PatientPendingList')
        } else {
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    selectAttachment:function($event, val){
      this.$validator.reset()
      this.attachment =$event.target.files[0]
      const fr = new FileReader ()
      fr.readAsDataURL($event.target.files[0])
      fr.addEventListener('load', () => {
        this.file = fr.result          
      })
      this.extension = this.attachment.name.split('.').pop() 
      for(let key in this.$refs.document){
        if(key != val){
          this.$refs.document[key].value = ''
        }
      }
    },
    getLabels(){
      if(this.data.departmentId){
        this.$http.post('patient/patient/list_document_patient',
        {
          id: this.data.id,
          notIn: [1],
          requested: 'TRUE'
        })
        .then(response => {
          let res = response.body
          let selectRes = []
          if(res.status && res.hasrecords && res.records[0].document_relation.length > 0) {
            for (let key in res.records[0].document_relation) {
              let result = []
              result['label'] = res.records[0].document_relation[key].label
              result['status'] = res.records[0].document_relation[key].status
              result['labelId'] = res.records[0].document_relation[key].id
              result['cardId'] = res.records[0].cardId
              result['patientId'] = res.records[0].id
              result['departmentId'] = res.records[0].departmentId
              result['loading'] = false
              let images = []
              if(res.records[0].document_relation[key].upload_relation.length > 0){
                for(let key1 in res.records[0].document_relation[key].upload_relation){
                  let imageData = []
                  imageData['image'] = res.records[0].document_relation[key].upload_relation[key1].documentName
                  imageData['extension'] = res.records[0].document_relation[key].upload_relation[key1].ext  
                  imageData['imageId'] = res.records[0].document_relation[key].upload_relation[key1].id  
                  images.push(imageData)
                }                
              }
              result['images'] = images
              selectRes.push(result)
            }
            this.labels = selectRes
          }
          else{
            this.labels = []
          }
        })
      }
    }  
  },
  created(){
    // if(JSON.stringify(this.data)!='{}'){
      this.profileData = this.data
    // }
    this.getLabels()
  }
};
</script>

<style scoped>
.form-group input[type="file"]{
  opacity: 1;
  position: unset !important;
}
label{
  color: #6c6666 !important;
}
</style>
