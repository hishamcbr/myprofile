<template>
  <div>
    <div v-if="sections.listing">
      
      <ttable @selected="selectedRows" :page="page" @updateData="getData($event)" id="out-table">
        <div slot="extra">
          <h4 style="margin:0">Patient Profile<a @click.prevent="$emit('changeComponent','listing')" href=""><i style="margin-top:-20px" class="fa fa-times pull-right"></i></a></h4>
          <el-card style="margin-bottom:20px; width:100%">
          <div slot="header" class="clearfix">
            <span><b>Patient Details</b></span>
          </div>
          <div class="row">
            <div class="col-md-2">
              Name: 
              {{patientDetails.name}}
            </div>
            <div class="col-md-2">
              OP Number: {{patientDetails.opNumber}}
            </div>
            <div class="col-md-2">
              Card ID: {{patientDetails.cardId}}
            </div>
            <div class="col-md-4">
              Mobile Number: {{patientDetails.mobileNumber}}
            </div>
            <div class="col-md-2">
              Gender: {{patientDetails.gender}}
            </div>
          </div>          
          </el-card>
        </div>
        <!-- <el-table-column
          slot="select"
          type="selection"
          width="55">
        </el-table-column> -->
        <el-table-column
          slot="actions"
          :min-width="60"
          fixed="right"
          label="Actions"
          id="action-column">
            <template slot-scope="props">
                <!-- <button class="btn btn-primary btn-icon btn-sm" @click.prevent="handleEdit(props.$index, props.row)" title="Edit"><i class="fa fa-edit"></i></button> -->
                <button class="btn btn-default btn-icon btn-sm" @click.prevent="handleDownload(props.$index, props.row)" title="Download Documents">  <i class="fa fa-download" aria-hidden="true"></i></button>
                <button class="btn btn-success btn-icon btn-sm" @click.prevent="handleView(props.$index, props.row)" title="View"><i class="fa fa-eye"></i></button>
            </template>
          </el-table-column>
      </ttable>
    </div>
    <view-patient v-if="sections.view" :downloadButton="true" @changeComponent= "changeComponent" :imageClose="false" :data="uploadData"></view-patient>
    

  </div>    
</template>

<script>

import moment from 'moment'
import swal from 'sweetalert2'
import ViewPatient from 'src/components/View/Hospitals/HospitalDashboard/View/PatientList/ViewPatient.vue'
import addPatient from './AddMasterPatient.vue'
import QrList from './QRList.vue'
import ttable from 'src/components/View/ServerTable_view.vue'
export default {
  props: ['data'],
  components:{
    ttable,
    addPatient,
    QrList,
    ViewPatient
  },
  data(){
    return{
      patientId: '',
      patientDetails: {
        name: '',
        opNumber: '',
        cardId: '',
        mobileNumber: '',
        gender: ''
      },
      uploadData: {},

      qrCodeData: [],
      passwordModal: false,
      mobileNumber: '',
      password: '',
      hiddenUserId: '',
      deleteModal: false,
      patientData: {},
      sections: {
        add: false,
        listing: true,
        edit: false,
        qrlist: false,
        view: false
      },
      counts: {
        all: 0,
        dialysis: 0,
        other: 0
      },
      userType: 'all',
      showAdd: false,
      departmentData: {},
      page: {
         TotalPerPage: 10,
         total: 0,
         tableColumns: [],
         tableData: [],
         propsToSearch: [],
         selection: false,
         entries: false
       },
       columns: [
        {
          prop: 'regDate',
          label: 'Registration Date',
          minWidth: 190,
          sortable: true
        },
        {
          prop: 'registerNumber',
          label: 'Register Number',
          minWidth: 150,
          sortable: true
        }
      ],
    }
  },
  methods: {
    handleDownload(index, row){
      this.loading = true
      this.$http.post("patient/patient/zipping_patient", {
          id: row.id
        })
        .then(response => {
          let res = response.body;
          this.loading = false
          if(res.status){
            // window.open(res.records, '_blank')
            window.location.href = res.records
          }
          else{
            swal({
              type: "error",
              title: res.message
            });
          }
          // swal({
          //   type: res.status ? "success" : "error",
          //   title: res.message
          // });
          
        });
      // this.loading = true
    },
    handleView(index, row){
      this.uploadData = row
      this.showComponent('view')
    },
    showQrList(){
      this.showComponent('qrlist')
      // console.log(this.qrCodeData)
    },
    selectedRows(rows){
      this.qrCodeData = rows
    },
    changeComponent(value){
      this.qrCodeData = []
      this.showComponent(value)
    },
    showComponent(value) {
      this.sections = {
        add: false,
        listing: false,
        edit: false,
        qrlist:false,
        view:false
      };
      for (var p in this.sections) {
        if (p == value) {
          this.sections[p] = true;
        }
      }
    },
    handleEdit(index, row){
      this.patientData = row
      this.showComponent('add')
    },
    handleDeviceReset(index, row){
        swal({
        type: 'question',
        title: '',
        text: 'Are you sure to reset device for - '+row.name+ '?',
        showCancelButton: true,
        confirmButtonText: 'Reset',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
      })
      .then(result => {
        if (result) {
          this.$http.post('users/usermanagement/reset_device',{
            'id': row.id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getData()
            }
          })
        }
      })
    },
    getUserTypeId(){
      let patientType = ''
      if(this.userType == 'all'){
        patientType = ''
      }
      else if(this.userType == 'dialysis'){
        patientType = 1
      }
      else if(this.userType == 'other'){
        patientType = 2
      }
      return patientType
    },
    getUserType(value){
      let userType = ''
      if(value == 1){
        userType = 'Dialysis'
      }
      else if(value == 2){
        userType = 'Other'
      }
      return userType
    },
    getData(event){
      this.$http.post('patient/patient/list_permanent_patient',
      {
        'moreDetails': 'TRUE',
        // 'pagination': 'TRUE',
        // 'currentPage': event ? event.CurrentPage : 1,
        // 'totalPerPage': this.page.TotalPerPage,
        'sortOrder': 'DESC',
        'searchKey': '',
        'id': this.patientId,
        'PatientDetails': 'TRUE'
      })
      .then(response => {
        let res = response.body
        this.page.tableColumns = this.columns
        if(res.status && res.hasrecords){
          this.patientDetails.name = res.records[0].name ? res.records[0].name : ''
          this.patientDetails.opNumber = res.records[0].opNumber ? res.records[0].opNumber : ''
          this.patientDetails.cardId = res.records[0].cardId ? res.records[0].cardId : ''
          this.patientDetails.mobileNumber = res.records[0].mobileNumber ? res.records[0].mobileNumber : ''
          this.patientDetails.gender = res.records[0].gender ? res.records[0].gender : ''
        }
        if(res.status && res.hasrecords && res.records[0].patient_reg_relation.length > 0) {
          for(let key in res.records[0].patient_reg_relation){
            res.records[0].patient_reg_relation[key].regDate = res.records[0].patient_reg_relation[key].doa ?  moment(res.records[0].patient_reg_relation[key].doa).format('DD-MM-YYYY') : ''  
          }
          
          this.page.total = res.records[0].patient_reg_relation.length
          this.page.tableData = res.records[0].patient_reg_relation
        }
      })
    }
  },
  created(){
    if(JSON.stringify(this.data) != '{}'){
      this.patientId = this.data.id
    }
  }

}
</script>
<style>
.el-table .td-actions button.btn {
    margin-right: 5px !important;
}
</style>


<style scoped>
.add{
  max-height: 0;
  overflow: hidden;
}
.btn-export{
  background: #fff;
  color:#9A9A9A;
}
.add.slide{
  transition: all .5s ease;
  max-height: 100%;
}
</style>
