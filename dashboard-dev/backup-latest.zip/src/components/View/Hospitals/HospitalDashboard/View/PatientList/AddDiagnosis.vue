<template>
    <div>
        <div class="treatment-section treatment-section1" v-if="treatments.length > 0">
            <el-card v-for="(treatment,index) in treatments" :key="index" style="margin-bottom:10px">
                <div class="adpopup">
                    <button  @click.prevent="removeTreatment(index)" class="btn btn-sm btn-danger pull-right">Remove</button>
                    <button style="margin-right:5px" v-if="index == 0" href="" @click.prevent="validateTreatment" class="btn btn-sm btn-info pull-right">Add</button>

                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Enter Provisional diagnosis </label>
                            <input v-model="treatments[index].diagnosis" v-validate="'required'" data-vv-as="Diagnosis" :name="'diagno'+index" data-vv-scope="treatmentScope" type="text" class="form-control" placeholder="Enter Provisional diagnosis ">
                            <small class="text-danger">
                                {{errors.first('treatmentScope.diagno'+index)}}
                            </small>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for>Plan of Treatment</label><br>
                            <el-radio-group style="width:100%" v-model="treatments[index].plan">
                                <el-radio label="1">Conservative</el-radio>
                                <el-radio label="2">Procedure</el-radio>
                            </el-radio-group>
                        </div>
                    </div>
                </div>
                <div v-if="treatments[index].plan == 2">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label style="width:100%">Enter procedure
                                    <button style="margin:0" @click.prevent="validateProcedure(index)" class="btn pull-right btn-info btn-sm">
                                        Add Procedure<!-- <i class="fa fa-plus"></i> -->
                                    </button>
                                </label>
                                <div class="procedure-icon-container" v-for="(proc,index1) in treatments[index].procedureArray" :key="index1">
                                    <input style="margin-bottom: 5px" data-vv-as="Procedure" v-validate="'required'" :name="'Procedure'+index1" data-vv-scope="procedureScope" v-model="treatments[index].procedureArray[index1].procedure" type="text" class="form-control" placeholder="Enter procedure ">
                                    <a href="" @click.prevent="removeProcedure(index,index1)"><i class="procedure-icon fa fa-1x fa-times text-danger"></i></a>
                                    <small class="text-danger">
                                        {{ errors.first('procedureScope.Procedure'+index1) }}
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </el-card>
        </div>
        <div v-else>
            <el-card>
                    <div slot="header" class="clearfix">
                    <a href="" @click.prevent="validateTreatment" class="text-primary pull-right"><i class="fa fa-plus fa-2x"></i></a>
                </div>
            </el-card>
        </div>
        <div class="row">
            <div class="col-md-12">
            <button @click.prevent="submitTreatment" class="btn btn-fill btn-success pull-right">Submit</button>
            <button @click.prevent="closeModal" class="btn btn-fill btn-info pull-right">Cancel</button>
            </div>
        </div>
    </div>
</template>

<script>
import swal from 'sweetalert2'
export default {
    props: ['data'],
    data() {
        return {
            treatments: [
                {
                    diagnosis: '',
                    plan: '',
                    procedureArray: [
                        {
                            procedure: ''
                        }
                    ]
                }
            ],
            treatmentData: {
                flag: 1
            },
        }
    },
    methods: {
        submitTreatment(){
            let cook= this.$cookies.get('kasp-pmjay')
            let formData = this.treatmentData
            formData.registrationId = this.data.patientId
            formData.createdBy = cook.UserId
            formData.treatments = JSON.stringify(this.treatments)
            this.$http.post('treatment/treatment/add_treatment', formData)
            .then(response => {
                let res = response.body;
                if (res.status) {
                    this.treatmentData.flag=2
                    swal({
                        type: "success",
                        title: res.message
                    });
                this.closeModal()
                } else {
                    swal({
                        type: "error",
                        title: res.message
                    });
                }
            })
        },
        closeModal(){
            this.treatments = [
                {
                    diagnosis: '',
                    plan: '',
                    procedureArray: [
                        {
                            procedure: ''
                        }
                    ]
                }
            ],
            this.$emit('close')
        },
        removeProcedure(index, index1){
            this.treatments[index].procedureArray.splice(index1,1)
        },
        validateProcedure(index){
            this.$validator.validateAll('procedureScope').then(isValid => {
                if(isValid){
                    this.addProcedure(index)
                }
            })
        },
        addProcedure(index){
            let procedure = {
                procedure: ''
            }
            this.treatments[index].procedureArray.push(procedure)
        },
        removeTreatment(index){
            this.treatments.splice(index,1)
        },
        validateTreatment(){
            this.$validator.validateAll('treatmentScope').then(isValid => {
                if(isValid){
                    this.addTreatment()
                }
            })
        },
        addTreatment(){
            let treatment = {
                diagnosis: '',
                plan: '',
                procedureArray: [
                    {
                        procedure: ''
                    }
                ]
            }
            this.treatments.push(treatment)
        },
    },
    created(){
        this.$validator.reset()
    }

}
</script>

<style scoped>
.procedure-icon{
    font-size: 20px;
    position:absolute;
    right:10px;
    top:10px
}
.procedure-icon-container{
    position: relative;
}
</style>
