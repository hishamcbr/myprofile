<template>
  <div>
    <div v-if="sections.listing">
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-12">
              <button @click.prevent="userType = 'all',getData()" class="btn btn-outline-warning btn-warning btn-export" :class="userType == 'all' ? 'active' : ''">All ({{counts.all}})</button>
              <button @click.prevent="userType = 'dialysis',getData()" class="btn btn-outline-primary btn-primary  btn-export" :class="userType == 'dialysis' ? 'active' : ''">Dialysis ({{counts.dialysis}})</button>
              <button @click.prevent="userType = 'other',getData()" class="btn btn-outline-danger btn-danger  btn-export" :class="userType == 'other' ? 'active' : ''">Other ({{counts.other}})</button>
              <!-- <button @click.prevent="userType = 'hospital-user',getData()" class="btn btn-outline-default btn-default  btn-export" :class="userType == 'hospital-user' ? 'active' : ''">Hospital Users ({{counts.hospitalUsers}})</button> -->
              
              <button @click.prevent="addSection()" class="btn btn-primary pull-right">Add Patient</button>
              <button :disabled="qrCodeData.length == 0" @click="showQrList()" class="btn btn-warning pull-right">QR List</button>
              <button v-if="isAdmin" :disabled="qrCodeData.length == 0" @click="deletePatients()" class="btn btn-danger pull-right">Delete</button>          
          </div>            
        </div>      
      </div>    
      <ttable @changeReset="changeReset" :reset="tableReset" @selected="selectedRows" :page="page" @updateData="getData($event)" id="out-table">
        <el-table-column
          slot="select"
          type="selection"
          width="55">
        </el-table-column>        
        <div class="col-md-2" slot="extra">
          <label class="filter-label">Export</label><br>
          <el-dropdown style="width:100%" placement="top-end" trigger="click" @command="exportToExcel">
              <el-button class="excel-button" type="primary" style="width:100%">
                  Excel<i class="el-icon-arrow-down el-icon--right"></i>
              </el-button>
              <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item icon="el-icon-document-copy" :disabled="page.total <= 0" command="all">All</el-dropdown-item>
                  <el-dropdown-item icon="el-icon-document" :disabled="qrCodeData.length <= 0" command="selected">Selected</el-dropdown-item>
              </el-dropdown-menu>
          </el-dropdown>
        </div>
        <div class="col-md-4" slot="extra"></div>
        <div class="col-md-4" slot="extra">
          <div class="form-group pull-right" style="width:100%">
            <label class="filter-label">Search</label><br>           
            <input @keyup.prevent="getData()" v-model="searchKey"  type="text" class="search-box form-control" placeholder="Search Here">
            <i class="search-icon fa fa-search text-primary"></i>
          </div>
        </div>
        <el-table-column
          slot="actions"
          :min-width="160"
          fixed="right"
          label="Actions"
          id="action-column">
            <template slot-scope="props">
                <button class="btn btn-primary btn-icon btn-sm" @click.prevent="handleEdit(props.$index, props.row)" title="Edit"><i class="fa fa-edit"></i></button>
                <button class="btn btn-success btn-icon btn-sm" @click.prevent="handleView(props.$index, props.row)" title="View"><i class="fa fa-eye"></i></button>
                <button v-if="isAdmin" class="btn btn-danger btn-icon btn-sm" @click.prevent="handleDelete(props.$index, props.row)" title="Delete"><i class="fa fa-trash"></i></button>
            </template>
          </el-table-column>
      </ttable>
    </div>
    <add-patient v-else-if="sections.add" @changeComponent="changeComponent" :data="patientData"></add-patient>
    <qr-list v-else-if="sections.qrlist" @changeComponent="changeComponent" :data="qrCodeData"></qr-list>
    <view-patient v-else-if="sections.view" @changeComponent="changeComponent" :data="patientData"></view-patient>
  </div>    
</template>

<script>
import swal from 'sweetalert2'
import addPatient from './AddMasterPatient.vue'
import ViewPatient from './ViewPatient.vue'
import QrList from './QRList.vue'
import ttable from 'src/components/View/ServerTable.vue'
export default {
  components:{
    ttable,
    addPatient,
    QrList,
    ViewPatient
  },
  data(){
    return{
      tableReset: 'no',
      searchKey: '',
      isAdmin: false,
      qrCodeData: [],
      passwordModal: false,
      mobileNumber: '',
      password: '',
      hiddenUserId: '',
      deleteModal: false,
      patientData: {},
      sections: {
        add: false,
        listing: true,
        edit: false,
        qrlist: false,
        view: false
      },
      counts: {
        all: 0,
        dialysis: 0,
        other: 0
      },
      userType: 'all',
      showAdd: false,
      departmentData: {},
      page: {
         TotalPerPage: 10,
         total: 0,
         tableColumns: [],
         tableData: [],
         propsToSearch: [],
         selection: false,
         entries: true
       },
       columns: [
        {
          prop: 'name',
          label: 'Patient Name',
          minWidth: 190,
          sortable: true
        },
        {
          prop: 'opNumber',
          label: 'OP No.',
          minWidth: 120,
          sortable: true
        },
        {
          prop: 'cardId',
          label: 'Card ID',
          minWidth: 140
        },
        {
          prop: 'mobileNumber',
          label: 'Mob No',
          minWidth: 130
        },
        {
          prop: 'gender',
          label: 'Gender',
          minWidth: 100
        },
      ],
    }
  },
  methods: {
    // selectedRows(rows){
    //   this.selected = rows
    // },
    changeReset(){
      this.tableReset = 'no'
    },
    exportToExcel(value){       
        let cook= this.$cookies.get('kasp-pmjay')
        this.loading = true
        let id=[]
        if(value == 'all'){
          id = []
        }
        else{
          id = []
          for(let key in this.qrCodeData){
            id.push(this.qrCodeData[key].id)
          }
        }
        this.$http.post("patient/patient/export_permanent_patient_excel", {
            userId: cook.UserId,
            hospitalId: cook.hospitalId,
            id: id,
            status: 3,
            // fromDate: this.fromDate,
            // toDate: this.toDate,
            searchKey: this.searchKey
          })
          .then(response => {
            let res = response.body;
            this.loading = false
            
            if(res.status){
              this.tableReset = 'reset'
              window.location.href = res.records
            }
            else{
              swal({
                type: "error",
                title: res.message
              });
            }
            
          });
    },
    deletePatients(){
      if(this.qrCodeData.length > 0){
        let id = []
        for(let key in this.qrCodeData){
          id.push(this.qrCodeData[key].id)
        }
        swal({
        type: 'question',
        title: '',
        text: 'Are you sure to delete - '+this.qrCodeData.length+ ' users?',
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
        })
        .then(result => {
          if (result) {
            this.$http.post('patient/patient/delete_master_patient',{
              'id': id
            })
            .then(response => {
              let res = response.body
              swal({
                type: res.status ? 'success' : 'error',
                title: res.message
              })
              if (res.status) {
                this.getData()
              }
            })
          }
        })        
      }
    },
    handleDelete(index,row){
      let id = []
      id.push(row.id)
      swal({
        type: 'question',
        title: '',
        text: 'Are you sure to delete patient?',
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
        })
      .then(result => {
        if (result) {
          this.$http.post('patient/patient/delete_master_patient',{
            'id': id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getData()
            }
          })
        }
      })
    },
    addSection(){
      this.patientData = {}
      this.showComponent('add')
    },
    showQrList(){
      this.showComponent('qrlist')
      // console.log(this.qrCodeData)
    },
    selectedRows(rows){
      this.qrCodeData = rows
    },
    changeComponent(value){
      this.qrCodeData = []
      this.showComponent(value)
    },
    showComponent(value) {
      this.sections = {
        add: false,
        listing: false,
        edit: false,
        qrlist:false,
        view:false
      };
      for (var p in this.sections) {
        if (p == value) {
          this.sections[p] = true;
        }
      }
    },
    handleView(index, row){
      this.patientData = row
      this.showComponent('view')
    },
    handleEdit(index, row){
      this.patientData = row
      this.showComponent('add')
    },
    handleDeviceReset(index, row){
        swal({
        type: 'question',
        title: '',
        text: 'Are you sure to reset device for - '+row.name+ '?',
        showCancelButton: true,
        confirmButtonText: 'Reset',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
      })
      .then(result => {
        if (result) {
          this.$http.post('users/usermanagement/reset_device',{
            'id': row.id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getData()
            }
          })
        }
      })
    },
    getUserTypeId(){
      let patientType = ''
      if(this.userType == 'all'){
        patientType = ''
      }
      else if(this.userType == 'dialysis'){
        patientType = 1
      }
      else if(this.userType == 'other'){
        patientType = 2
      }
      return patientType
    },
    getUserType(value){
      let userType = ''
      if(value == 1){
        userType = 'Dialysis'
      }
      else if(value == 2){
        userType = 'Other'
      }
      return userType
    },
    getData(event){
      let cook = this.$cookies.get('kasp-pmjay')
      let userType = this.getUserTypeId()
      this.$http.post('patient/patient/list_permanent_patient',
      {
        'hospitalId': cook.hospitalId,
        'moreDetails': 'TRUE',
        'pagination': 'TRUE',
        'currentPage': event ? event.CurrentPage : 1,
        'totalPerPage': this.page.TotalPerPage,
        'sortOrder': 'DESC',
        'searchKey': this.searchKey,
        'patientType': userType,
        'PatientDetails': 'TRUE'
      })
      .then(response => {
        let res = response.body
        this.page.tableColumns = this.columns
        if(res.status && res.hasrecords) {
          // let dialysisCount = 0
          // let otherCount = 0
          // for(let key in res.records.data){
          //   if(res.records.data[key].patientType == 2){
          //     otherCount = otherCount + 1
          //   }
          //   else if(res.records.data[key].patientType == 1){
          //     dialysisCount = dialysisCount + 1
          //   }
          // }
          this.counts.dialysis = this.counts.dialysis ? this.counts.dialysis : (res.message.dialysis ? res.message.dialysis : 0)
          this.counts.other = this.counts.other ? this.counts.other : (res.message.other ? res.message.other : 0)
          this.page.total = res.records.total
          this.counts.all = this.counts.all ? this.counts.all : res.records.total
          this.page.tableData = res.records.data
        }
      })
    }
  },
  created(){
    let cook = this.$cookies.get('kasp-pmjay')
    if(cook.userType == 1){
      this.isAdmin = true
    }
  }



}
</script>
<style>
.el-table .td-actions button.btn {
    margin-right: 5px !important;
}
</style>


<style scoped>
.add{
  max-height: 0;
  overflow: hidden;
}
.btn-export{
  background: #fff;
  color:#9A9A9A;
}
.add.slide{
  transition: all .5s ease;
  max-height: 100%;
}
</style>
