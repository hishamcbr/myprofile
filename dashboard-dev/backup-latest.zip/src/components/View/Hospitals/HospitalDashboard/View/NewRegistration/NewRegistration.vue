<template>
    <div class="card p-3">
        <form-wizard title="Patient Registration" subtitle="" color="#1576c2" shape="tab" ref="wizard" @on-validate="handleValidation">
            <!-- :hide-buttons="true" -->
            <!-- <tab-content icon="fa fa-user" v-if="tabs.first" title="Basic Details" :before-change="()=>validateTab('1')"> -->
                <tab-content icon="fa fa-user" v-if="tabs.first" title="Basic Details" :before-change="()=>validateTab('1')">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Scheme ID <span class="mandatory">*</span></label>
                            <input @focusout.prevent="getDetailsFromCard()" @input="forceUpper($event, basic, 'cardId')" placeholder="Enter Scheme ID" type="text" v-model="basic.cardId" name="scheme_id" v-validate="'required'" data-vv-as="Scheme ID" data-vv-scope="scope1" class="form-control">
                            <small class="text-danger">
                                {{errors.first('scope1.scheme_id')}}
                            </small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Select Department <span class="mandatory">*</span></label>
                            <el-select  class="rio-select"  v-validate="'required'" data-vv-scope="scope1" name="Department" data-vv-as="Department" clearable filterable placeholder="Select Department" v-model="basic.departmentId">
                                <el-option
                                v-for="type in departments"
                                class="select-primary"
                                :value="type.value"
                                :label="type.label"
                                :key="type.label"
                                ></el-option>
                            </el-select>
                            <small class="text-danger">
                                {{errors.first('scope1.Department')}}
                            </small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">IP Number <span class="mandatory">*</span></label>
                            <input @input="forceUpper($event, basic, 'ipNumber')" placeholder="Enter IP Number" type="text" v-model="basic.ipNumber" name="ip_number" v-validate="'required'" data-vv-as="IP Number" data-vv-scope="scope1" class="form-control">
                            <small class="text-danger">
                                {{errors.first('scope1.ip_number')}}
                            </small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">OP Number </label>
                            <input @input="forceUpper($event, basic, 'opNumber')" placeholder="Enter OP Number" type="text" v-model="basic.opNumber" name="op_number"  data-vv-as="OP Number" data-vv-scope="scope1" class="form-control">
                            <!-- <small class="text-danger">
                                {{errors.first('scope1.op_number')}}
                            </small> -->
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Patient Name <span class="mandatory">*</span></label>
                            <input @input="forceUpper($event, basic, 'name')" placeholder="Enter Patient Name" type="text" v-model="basic.name" name="patient_name" v-validate="'required'" data-vv-as="Patient Name" data-vv-scope="scope1" class="form-control">
                            <small class="text-danger">
                                {{errors.first('scope1.patient_name')}}
                            </small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Mobile Number <span class="mandatory">*</span></label>
                            <!-- <input placeholder="Enter Mobile Number" type="text" v-model="basic.mobileNumber" name="mobile_number" v-validate="{ required: true,regex: /^[6-9]\d{9}$/ }" data-vv-as="Mobile Number" data-vv-scope="scope1" class="form-control"> -->
                            <input placeholder="Enter Mobile Number" type="text" v-model="basic.mobileNumber" name="mobile_number" v-validate="{ required: true }" data-vv-as="Mobile Number" data-vv-scope="scope1" class="form-control">
                            <small class="text-danger">
                                {{errors.first('scope1.mobile_number')}}
                            </small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for>Date of Admission <span class="mandatory">*</span></label>
                            <el-date-picker
                                style="width:100%"
                                v-model="basic.doa"
                                type="date"
                                :picker-options="pickerOptions"
                                placeholder="Pick a day"
                                format="dd-MM-yyyy"
                                value-format="yyyy-MM-dd"
                                name="Date of admission" v-validate="'required'" data-vv-scope="scope1">
                            </el-date-picker>
                            <small class="text-danger">
                                {{ errors.first('scope1.Date of admission') }}
                            </small>
                        </div>
                    </div>
                </div>
                <div class="row" v-if="basic.id">
                    <div class="col-md-6">
                        <el-card style="width:100%">
                            <div slot="header" class="clearfix">
                                <span><h6 style="margin-bottom: 0">Upload Documents</h6></span>
                            </div>
                            <!-- <div class="col-md-12"> -->
                            <div class="col-sm-12 up-doc" v-for="(option, index) in regDocs" :key="index">
                                <div class="row">
                                <div class="col-md-10" style="padding:0">
                                    <div class="form-group">
                                    <label>{{option.label}}</label><br>
                                    <input ref="regDocument" type="file" v-validate="'required'" :data-vv-scope="'regUploadScope'+option.labelId" :name="option.label+' Document'"  class="form-control"  @change="selectAttachment($event,index)">
                                    <small class="text-danger">
                                        {{ errors.first('regUploadScope'+option.labelId+'.'+option.label+' Document') }}
                                    </small>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <label style="visibility:hidden">Hidden</label>
                                    <button v-if="!option.loading && uploadButtons" style="" class="btn btn-icon btn-warning"  @click.prevent="validateRegUpload(option,index)"><i class="fa fa-upload"></i></button>
                                    <el-button v-if="option.loading" type="primary" :loading="true"></el-button>
                                </div>
                                </div>
                            </div>
                        </el-card>
                    </div>
                    <div class="col-md-6 up-dcmnts-cv">
                        <el-card style="width:100%">
                            <div slot="header" class="clearfix">
                                <span><h6 style="margin-bottom: 0">Uploaded Documents</h6></span>
                            </div>
                            <div class="up-dcmnts">
                                <div  v-for="(option, index) in regDocs" :key="index">
                                <el-card>
                                    <!-- <div slot="header" class="clearfix">
                                    <span><h6 style="margin-bottom: 0">{{option.label}}</h6></span>
                                    </div> -->
                                    <label>{{option.label}}</label><br>
                                    <!-- <viewer class="clearfix" style="float:left" :images="option.images"> -->
                                    <div class="upImg" v-viewer>
                                        <div class="rio-img-thumb"  v-for="image in option.images" :key="image.image">
                                        <span v-if="image.extension == 'png' || image.extension == 'jpg' || image.extension == 'jpeg'">
                                            <div v-if="image.image" class="in-thumb" >
                                                <img :src="image.image">
                                            <div class="new-tag" v-show="image.downloaded == 1 || image.downloaded == 3">New</div>
                                                <a  @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" ><i class="fa fa-times"></i></span></a>
                                            </div>
                                        </span>
                                        </div>
                                    </div>

                                    <!-- </viewer> -->
                                    <!-- <div class="clearfix"></div> -->
                                    <span v-for="image in option.images" :key="image.image">
                                        <span v-if="image.extension == 'pdf'">
                                            <span v-if="image.image" style="position:relative; margin-right: 10px">
                                            <a @click.prevent="openDocument(image.image)" href><img style="display: inline-block;" @click.prevent="" width="15%" src=/static/img/pdf-icon.png></a>
                                            <a @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" style="position: absolute;top: -15px;right:-5px"><i class="fa fa-times"></i></span></a>
                                            </span>
                                        </span>
                                    </span>

                                    <!-- <img @click.prevent="" width="15%" v-else src=/static/img/pdf-icon.png> -->
                                </el-card>
                                </div>
                            </div>
                        </el-card>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <button v-if="basicActionType == 'update'" @click.prevent="validateUpdate" class="btn btn-fill btn-success pull-right">Save</button>
                        <button v-if="basicActionType == 'create'" @click.prevent="validateTab('1')" class="btn btn-fill btn-success pull-right">Register</button>
                    </div>
                </div>
            </tab-content>
            <!-- <tab-content v-if="tabs.second" title="Upload Registration Documents" :before-change="()=>validateTab('2')">
                <div v-for="(option,index) in registerDocuments" :key="index">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for>Upload {{option.label}} <span class="mandatory">*</span></label>
                                <input type="file" v-validate="'required'" data-vv-as="document" data-vv-scope="scope2" :name="option.label+' Document'"  class="form-control" @change="selectAttachment($event, option, index)">
                                <small class="text-danger">
                                {{ errors.first('scope2.'+option.label+' Document') }}
                                </small>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="" style="visibility:hidden">Image</label><br>
                            <img style="display: inline-block;cursor:pointer"  width="15%" :src="option.image">
                        </div>
                    </div>
                </div>
            </tab-content> -->
            <tab-content v-if="tabs.second" icon="fa fa-adn" title="Admission Details" :before-change="()=>validateTab('2')">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for>Gender:</label><br>
                            <el-radio-group style="width:100%" v-model="admission.gender">
                                <el-radio :label="Male">Male</el-radio>
                                <el-radio :label="Female">Female</el-radio>
                            </el-radio-group>
                        </div>
                        <div class="form-group">
                            <label for="">Age <span class="mandatory">*</span></label>
                            <input @input="forceUpper($event, admission, 'age')" placeholder="Enter Age" type="text" v-model="admission.age" name="age" v-validate="{required: true, regex: /^([0-9]{1,3}M{0,1})$/}" data-vv-as="Age" data-vv-scope="scope3" class="form-control">
                            <small class="text-danger">
                                {{errors.first('scope3.age')}}
                            </small>
                        </div>
                        <div class="form-group">
                            <label style="width:100%" for="">Select Doctor <span class="mandatory">*</span>
                                <a href="" class="pull-right text-primary ad-doc" title="Add Doctor" @click.prevent="addDoctorSection=true"><i class="fa fa-plus"></i></a>
                            </label>
                            <el-select class="rio-select"  v-validate="'required'" data-vv-scope="scope3" name="Doctor" data-vv-as="Doctor" clearable filterable placeholder="Select Doctor" v-model="admission.doctorId">
                                <el-option
                                v-for="type in doctors"
                                class="select-primary"
                                :value="type.value"
                                :label="type.label"
                                :key="type.label"
                                ></el-option>
                            </el-select>
                            <small class="text-danger">
                                {{errors.first('scope3.Doctor')}}
                            </small>
                        </div>
                        
                        <div class="form-group">
                          <label style="width:100%" for="">Select Admission type</label>
                          <el-select class="rio-select" data-vv-scope="scope3" name="AdmissionType" data-vv-as="Admission Type" clearable filterable placeholder="Select Admission Type" v-model="admission.admissionType">
                              <el-option
                              v-for="type in admissionTypes"
                              class="select-primary"
                              :value="type.value"
                              :label="type.label"
                              :key="type.label"
                              ></el-option>
                          </el-select>
                        </div>

                        <div class="form-group">
                            <label for="">Room Number / Bed Number</label>
                            <input @input="forceUpper($event, admission, 'roomBedNo')" placeholder="Enter Room No/ Bed Number" type="text" v-model="admission.roomBedNo" name="room_number" class="form-control">
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                          <label for>Admitted At</label><br>
                          <el-radio-group style="width:100%" @change="selectAdmitted" v-model="admission.admittedAt">
                              <el-radio label="1">Ward</el-radio>
                              <el-radio label="2">ICU</el-radio>
                          </el-radio-group>
                        </div>
                        <el-card v-if="admission.admittedAt == '2'" style="width:100%; margin-bottom:10px">
                          <div class="row">
                              <div class="col-md-12" >
                                  <div class="form-group dis-flx">
                                      <label for>On Ventilator?</label><br>
                                      <el-radio-group @change="ventilatorSelected" style="width:100%" v-model="admission.ventilator">
                                          <el-radio :label="1">Yes</el-radio>
                                          <el-radio :label="2">No</el-radio>
                                      </el-radio-group>
                                  </div>
                              </div>
                              <!-- <div class="col-md-6"></div> -->
                              <div class="col-md-12 m-top20" style="" v-if="admission.ventilator == '1'">
                                  <label for>Ventilator Connected At</label>
                                  <el-date-picker
                                      style="width:100%"
                                      v-model="admission.ventilatorOn"
                                      type="datetime"
                                      placeholder="Pick date and time"
                                      format="dd-MM-yyyy hh:mm:ss"
                                      value-format="yyyy-MM-dd HH:mm:ss"
                                      name="Ventilator Connected" data-vv-scope="scope3">
                                  </el-date-picker>
                              </div>
                              <div class="col-md-12"  v-if="admission.ventilator == '1'">
                                  <label for>Ventilator Disonnected At</label>
                                  <el-date-picker
                                      style="width:100%"
                                      v-model="admission.ventilatorOff"
                                      type="datetime"
                                      placeholder="Pick date and time"
                                      format="dd-MM-yyyy hh:mm:ss"
                                      value-format="yyyy-MM-dd HH:mm:ss"
                                      name="Ventilator Disconnected" data-vv-scope="scope3">
                                  </el-date-picker>
                              </div>
                          </div>
                      </el-card>
                        <div class="form-group">
                            <label style="width:100%" for="">Select Ward/ICU</label>
                            <el-select class="rio-select" data-vv-scope="scope3" name="Ward" data-vv-as="Ward" clearable filterable placeholder="Select Ward/ICU" v-model="admission.wardId">
                                <el-option
                                v-for="type in wards"
                                class="select-primary"
                                :value="type.id"
                                :label="type.name"
                                :key="type.id"
                                ></el-option>
                            </el-select>
                        </div>
                      <div class="form-group">
                        <label style="width:100%" for="">Select Shifted To</label>
                        <el-select class="rio-select" @change="selectedShift" data-vv-scope="scope3" name="ShiftetTo" data-vv-as="Shifted To" clearable filterable placeholder="Select Shifted To" v-model="admission.shiftedTo">
                            <el-option
                            v-for="type in shiftedTo"
                            class="select-primary"
                            :value="type.value"
                            :label="type.label"
                            :key="type.label"
                            ></el-option>
                        </el-select>
                      </div>
                      <div class="form-group" v-if="admission.shiftedTo == 2 || admission.shiftedTo == 3">
                        <label for>Shifted Date and Time</label>
                        <el-date-picker
                            style="width:100%"
                            v-model="admission.shiftedDate"
                            type="datetime"
                            placeholder="Pick date and time"
                            format="dd-MM-yyyy hh:mm:ss"
                            value-format="yyyy-MM-dd HH:mm:ss"
                            name="Ventilator Connected" data-vv-scope="scope3">
                        </el-date-picker>
                      </div>
                    </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <button @click.prevent="validateTab('2')" class="btn btn-fill btn-success pull-right">Next</button>
                    <button @click.prevent="$refs.wizard.prevTab" class="btn btn-fill btn-info pull-right">Back</button>
                  </div>
                </div>
            </tab-content>
            <tab-content v-if="tabs.third" icon="fa fa-medkit" title="Treatment Details" :before-change="()=>validateTab('3')">
                <div class="treatment-section" v-if="treatments.length > 0">
                    <el-card v-for="(treatment,index) in treatments" :key="index" style="margin-bottom:10px">
                        <div class="row">
                        <div slot="header" class="clearfix col-sm-12 adbtns">
                        <div  class="">
                        <button  @click.prevent="removeTreatment(index)" class="btn btn-sm btn-danger pull-right">Remove</button>
                        <button style="margin-right:5px" v-if="index == 0" href="" @click.prevent="validateTreatment" class="btn btn-sm btn-info pull-right">Add</button>

                        </div>
                        </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Enter Provisional diagnosis </label>
                                    <input v-model="treatments[index].diagnosis" v-validate="'required'" data-vv-as="Diagnosis" :name="'diagno'+index" data-vv-scope="treatmentScope" type="text" class="form-control" placeholder="Enter Provisional diagnosis ">
                                    <small class="text-danger">
                                        {{errors.first('treatmentScope.diagno'+index)}}
                                    </small>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for>Plan of Treatment</label><br>
                                    <el-radio-group style="width:100%" v-model="treatments[index].plan">
                                        <el-radio label="1">Conservative</el-radio>
                                        <el-radio label="2">Procedure</el-radio>
                                    </el-radio-group>
                                </div>
                            </div>
                        </div>
                        <div v-if="treatments[index].plan == 2">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label style="width:100%">Enter procedure
                                            <button style="margin:0" @click.prevent="validateProcedure(index)" class="btn pull-right btn-info btn-sm">
                                                Add Procedure<!-- <i class="fa fa-plus"></i> -->
                                            </button>
                                        </label>
                                        <div class="procedure-icon-container" v-for="(proc,index1) in treatments[index].procedureArray" :key="index1">
                                            <input style="margin-bottom: 5px" v-model="treatments[index].procedureArray[index1].procedure" type="text" class="form-control" placeholder="Enter procedure ">
                                            <a href="" @click.prevent="removeProcedure(index,index1)"><i class="procedure-icon fa fa-1x fa-times text-danger"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </el-card>
                </div>
                <div v-else>
                    <el-card>
                         <div slot="header" class="clearfix">
                            <a href="" @click.prevent="validateTreatment" class="text-primary pull-right"><i class="fa fa-plus fa-2x"></i></a>
                        </div>
                    </el-card>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <button @click.prevent="validateTab('3')" class="btn btn-fill btn-success pull-right">Next</button>
                    <button @click.prevent="$refs.wizard.prevTab" class="btn btn-fill btn-info pull-right">Back</button>
                  </div>
                </div>
            </tab-content>
            <tab-content v-if="tabs.fourth" icon="fa fa-upload" title="Upload Documents" :before-change="()=>validateTab('5')">
                <div class="row" style="margin:0">
                    <el-card class="uploded" style="width:50%">
                    <div slot="header" class="clearfix">
                        <span><h6 style="margin-bottom: 0">Upload Documents</h6></span>
                    </div>
                    <!-- <div class="col-md-12"> -->
                    <div class="col-sm-12 up-doc" v-for="(option, index) in labels" :key="index">
                        <div class="row">
                        <div class="col-md-10" style="padding:0">
                            <div class="form-group">
                            <label>{{option.label}}</label><br>
                            <input ref="document" type="file" v-validate="'required'" :data-vv-scope="'uploadScope'+option.labelId" :name="option.label+' Document'"  class="form-control"  @change="selectAttachment($event,index)">
                            <small class="text-danger">
                                {{ errors.first('uploadScope'+option.labelId+'.'+option.label+' Document') }}
                            </small>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <label style="visibility:hidden">Hidden</label>
                            <button v-if="!option.loading && uploadButtons" style="" class="btn btn-icon btn-warning"  @click.prevent="validate(option,index)"><i class="fa fa-upload"></i></button>
                            <el-button v-if="option.loading" type="primary" :loading="true"></el-button>
                        </div>
                        </div>
                    </div>
                    </el-card>
                    <el-card style="width:50%">
                    <div slot="header" class="clearfix">
                        <span><h6 style="margin-bottom: 0">Uploaded Documents</h6></span>
                    </div>
                    <div class="up-dcmnts">
                        <div  v-for="(option, index) in labels" :key="index">
                        <el-card>
                            <!-- <div slot="header" class="clearfix">
                            <span><h6 style="margin-bottom: 0">{{option.label}}</h6></span>
                            </div> -->
                            <label>{{option.label}}</label><br>
                            <!-- <viewer class="clearfix" style="float:left" :images="option.images"> -->
                            <div v-viewer>
                                <div class="rio-img-thumb"  v-for="image in option.images" :key="image.image">
                                <span v-if="image.extension == 'png' || image.extension == 'jpg' || image.extension == 'jpeg'">
                                    <div v-if="image.image" class="in-thumb" >
                                        <img :src="image.image">
                                    <div class="new-tag" v-show="image.downloaded == 1 || image.downloaded == 3">New</div>
                                        <a  @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" ><i class="fa fa-times"></i></span></a>
                                    </div>
                                </span>
                                </div>
                            </div>

                            <!-- </viewer> -->
                            <!-- <div class="clearfix"></div> -->
                            <span v-for="image in option.images" :key="image.image">
                            <span v-if="image.extension == 'pdf'">
                                <span v-if="image.image" style="position:relative; margin-right: 10px">
                                <a @click.prevent="openDocument(image.image)" href><img style="display: inline-block;" @click.prevent="" width="15%" src=/static/img/pdf-icon.png></a>
                                <a @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" style="position: absolute;top: -15px;right:-5px"><i class="fa fa-times"></i></span></a>
                                </span>
                            </span>
                            </span>

                            <!-- <img @click.prevent="" width="15%" v-else src=/static/img/pdf-icon.png> -->
                        </el-card>
                        </div>
                    </div>
                </el-card>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <button @click.prevent="markCompleted()" class="btn btn-fill btn-success pull-right">Mark Completed</button>
                    <!-- <button @click.prevent="$refs.wizard.prevTab" class="btn btn-fill btn-info pull-right">Back</button> -->
                  </div>
                </div>
            </tab-content>

            <template slot="footer" slot-scope="props" style="display:none">
                <div  class="wizard-footer-left" style="display:none">
                    <wizard-button v-if="props.activeTabIndex > 0 && !props.isLastStep" @click.native="props.prevTab()" :style="props.fillButtonStyle">Previous</wizard-button>
                </div>
                <div class="wizard-footer-right" style="display:none">
                    <wizard-button v-if="!props.isLastStep" @click.native="props.nextTab()" class="wizard-footer-right" :style="props.fillButtonStyle">Next1</wizard-button>

                    <wizard-button v-else @click.native="alert('Done')" class="wizard-footer-right finish-button" :style="props.fillButtonStyle">{{props.isLastStep ? 'Done' : 'Next'}}</wizard-button>
                </div>
            </template>
            <!-- <el-button type="primary" slot="prev"></el-button> -->
        </form-wizard>
        <vue-slideout-panel :classes="['add-section']" :styles="styles" :widths="['40%']"
        :showExtra=false v-model="addDoctorSection"  @close="closeDoctorSection"
        closeHtml="<button class='btn btn-info btn-sm' style='display:none'>Close</button>">
            <add-doctor @close="closeDoctorSection"></add-doctor>
        </vue-slideout-panel>
    </div>

</template>

<script>
import VueSlideoutPanel from 'vue-slideout-panel';
import AddDoctor from './AddDoctor.vue'
// Vue.use(VueSlideoutPanel)
import swal from 'sweetalert2'
import moment from 'moment'
export default {
    components: {
        VueSlideoutPanel,
        AddDoctor
    },
    data(){
        return {
            pickerOptions: {
                disabledDate(time) {
                    return time.getTime() > Date.now();
                }
            },
            regDocs: [],
            regUploadNext: false,
            Male: 'Male',
            Female: 'Female',
            patientExist: false,
            labels: [],
            attachment: '',
            file: '',
            extension: '',
            uploadButtons: true,
            basicActionType: 'create',
            styles: [
                {},
                {
                    backgroundColor: '#fff',
                    paddingTop: '2rem',
                    paddingBottom: '1rem'
                },
                {},
                {
                    color: '#555',
                    textDecoration: 'none',
                    top: '0',
                    right: '1rem'
                }
            ],
            addDoctorSection: false,
            name: '',
            name1: '',
            perms: [],
            tabs: {
                first: true,
                second:false,
                third: false,
                fourth: false,
                fifth: false
            },
            basic: {
                // RegistrationId: '',
                // cardId: '',
                // departmentId: '',
                // name: '',
                // mobileNumber: '',
                // ipNumber: '',
                // opNumber: '',
                doa: moment().format('YYYY-MM-DD'),
                RegistrationId: '',
                cardId: '',
                departmentId: '',
                name: '',
                mobileNumber: '',
                ipNumber: '',
                opNumber: '',
            },
            basicUpload: {
                PatientMasterId: '',
                labelId: '',
                RegistrationId: ''
            },
            registration_docs: [],
            admission: {
                gender: '',
                age: '',
                flag: 1,                
                admissionType: '',
                admittedAt: '',
                ventilator: '',
                ventilatorOn: '',
                ventilatorOff: '',
                shiftedTo: 3,
                shiftedDate: '',
                wardId: '',
                doctorId: '',
                roomBedNo: ''
            },
            treatments: [
                {
                    diagnosis: '',
                    plan: '',
                    procedureArray: [
                        {
                            procedure: ''
                        }
                    ]
                }
            ],
            treatmentData: {
                flag: 1
            },
            departments: [],
            registerDocuments: [],
            doctors: [],
            admissionTypes: [
                {
                    label: 'Planned',
                    value: 1
                },
                {
                    label: 'Emergency',
                    value: 2
                }
            ],
            shiftedTo: [
                {
                    label: 'No Shift',
                    value: 3
                }
            ],
            wards: []
        }
    },
    methods: {
        validateUpdate(){
            this.$validator.validateAll('scope1').then(isValid => {
                if(isValid){
                    let count = 0
                    let show_response = false
                    for (var p in this.tabs) {
                        if(this.tabs[p]){
                            count++
                        }
                    }
                    if(count == 1){
                        show_response = true
                    }
                    this.submitBasic(show_response)
                }
            })
        },
        goNext(){
            if(this.regUploadNext){
                this.$refs.wizard.changeTab(0,1)
            }
            else{

            }
        },
        markCompleted(){
            swal({
            type: "question",
            title: "",
            text: "Are you sure to proceed ?",
            showCancelButton: true,
            confirmButtonText: "Yes",
            confirmButtonColor: "#1d7936",
            cancelButtonColor: "#3085d6"
            }).then(result => {
                if (result) {
                this.$http.post("patient/patient/mark_complete", {
                    id: this.basic.id
                    })
                    .then(response => {
                    let res = response.body;
                    swal({
                        type: res.status ? "success" : "error",
                        title: res.message
                    });
                    if (res.status) {
                        this.$router.push('/HospitalLayout/ApplicationList')
                    }
                    });
                }
            });
        },
        openDocument(document){
        window.open(document, "_blank");
        // console.log(document)
        },
        deleteDocument(id){
        swal({
            type: "question",
            title: "",
            text: "Are you sure to delete document ?",
            showCancelButton: true,
            confirmButtonText: "Delete",
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6"
        }).then(result => {
            if (result) {
            this.$http.post("patient/patient/delete_uploaded_document", {
                id: id
                })
                .then(response => {
                let res = response.body;
                swal({
                    type: res.status ? "success" : "error",
                    title: res.message
                });
                if (res.status) {
                    this.getLabels();
                    this.getregLabels();
                }
                });
            }
        });
        },
        validate(option,index){
        // console.log(this.labels[index].loading)
        this.$validator.validateAll('uploadScope'+option.labelId).then(isValid => {
            if(isValid){
            this.uploadButtons = false
            this.labels[index].loading = true
            this.uploadDocument(option,index)
            }
        })
        },        
        validateRegUpload(option,index){
        // console.log(this.labels[index].loading)
        this.$validator.validateAll('regUploadScope'+option.labelId).then(isValid => {
            if(isValid){
            this.uploadButtons = false
            this.regDocs[index].loading = true
            this.uploadDocument(option,index)
            }
        })
        },
        uploadDocument(option,index){
        let formData = {}
        formData.webflag = 1
        formData.labelId = option.labelId
        formData.status = option.status
        formData.registrationId = option.patientId
        formData.cardId = option.cardId
        formData.departmentId = option.departmentId
        formData.file = this.file
        formData.ext = this.extension
        this.$http.post('patient/patient/cloud_upload', formData).then(response => {
            this.uploadButtons = true
            // this.regDocs[index].loading = false
            let res = response.body;
            if(res.status) {
            if(this.$refs.document){
                for(let key in this.$refs.document){
                this.$refs.document[key].value = ''
                }
            }
            if(this.$refs.regDocument){
                for(let key in this.$refs.regDocument){
                this.$refs.regDocument[key].value = ''
                }
            }
            this.uploadButtons = true
            this.file=''
            this.extension=''
            this.getLabels()
            this.getRegLabels()
            swal({
                type: "success",
                title: res.message
            });
            // this.$router.push('/HospitalLayout/PatientPendingList')
            } else {
            swal({
                type: "error",
                title: res.message
            });
            }
        });
        },
        selectAttachment:function($event, val){
        this.$validator.reset()
        this.attachment =$event.target.files[0]
        const fr = new FileReader ()
        fr.readAsDataURL($event.target.files[0])
        fr.addEventListener('load', () => {
            this.file = fr.result
        })
        this.extension = this.attachment.name.split('.').pop()
        for(let key in this.$refs.regDocument){
            if(key != val){
            this.$refs.regDocument[key].value = ''
            }
        }
        for(let key in this.$refs.document){
            if(key != val){
            this.$refs.document[key].value = ''
            }
        }
        },
        closeDoctorSection(){
            this.getDoctors()
            this.addDoctorSection=false
        },
        removeProcedure(index, index1){
            this.treatments[index].procedureArray.splice(index1,1)
        },
        validateProcedure(index){
            this.addProcedure(index)
        },
        addProcedure(index){
            let procedure = {
                procedure: ''
            }
            this.treatments[index].procedureArray.push(procedure)
        },
        removeTreatment(index){
            this.treatments.splice(index,1)
        },
        validateTreatment(){
            this.$validator.validateAll('treatmentScope').then(isValid => {
                if(isValid){
                    this.addTreatment()
                }
            })
        },
        addTreatment(){
            let treatment = {
                diagnosis: '',
                plan: '',
                procedureArray: [
                    {
                        procedure: ''
                    }
                ]
            }
            this.treatments.push(treatment)
        },
        selectedShift(){
            this.admission.shiftedDate = ''
        },
        ventilatorSelected(){
            if(this.admission.ventilator == 2){
                this.admission.ventilatorOn = ''
                this.admission.ventilatorOff = ''
            }
        },
        selectAdmitted(){
            if(this.admission.admittedAt == '1'){
                this.admission.ventilator = ''
                this.admission.ventilatorOn = ''
                this.admission.ventilatorOff = ''
                this.admission.shiftedTo = 3
                this.shiftedTo = [
                    {
                        label: 'No Shift',
                        value: 3
                    },
                    {
                        label: 'ICU',
                        value: 2
                    }
                ]
            }
            else if(this.admission.admittedAt == '2'){
                this.admission.shiftedTo = 3
                this.shiftedTo = [
                    {
                        label: 'No Shift',
                        value: 3
                    },
                    {
                        label: 'Ward',
                        value: 1
                    }
                ]
            }
        },
        forceUpper (e, obj, prop) {
            const start = e.target.selectionStart
            e.target.value = e.target.value.toUpperCase()
            this.$set(obj, prop, e.target.value)
            e.target.setSelectionRange(start, start)
        },
        submitBasic(show_response){
            let formData = this.basic
            let cook = this.$cookies.get('kasp-pmjay')
            formData.hospitalId = cook.hospitalId
            let url = "patient/patient/add_patient";
            if(this.basicActionType == "create"){
                formData.createdBy = cook.UserId
            }
            else {
              formData.PatientMasterId = this.basicUpload.PatientMasterId
              formData.updatedBy = cook.UserId
              url = "patient/patient/edit_patient";
            }
            this.$http.post(url, formData).then(response => {
                let res = response.body;
                if (res.status) {
                this.basic.id = res.records.RegistrationId
                this.getLabels()
                this.basicUpload.labelId = res.records.labelId
                this.basicUpload.registrationId = res.records.RegistrationId
                this.basicUpload.PatientMasterId = res.records.PatientMasterId
                
                if(show_response){
                    if(this.regUploadNext){
                        this.$refs.wizard.changeTab(0,1)
                    }else{
                        if(this.basicActionType == 'create'){
                            swal({
                                type: "success",
                                title: res.message
                            });
                        }
                        else{
                            swal({
                                type: "success",
                                title: res.message
                            });
                            setTimeout(function(){
                                window.location.reload(true)
                            }, 2000);
                            this.regUploadNext = false
                        }
                        
                    }                  
                    
                }
                else{
                    if(this.regUploadNext){
                        this.$refs.wizard.changeTab(0,1)
                    }
                    this.regUploadNext = true
                }
                this.basicActionType = 'update'                
                this.getRegLabels()
                    // if(show_response){
                    //     swal({
                    //         type: "success",
                    //         title: res.message
                    //     });
                    //     setTimeout(function(){
                    //          window.location.reload(true)
                    //     }, 2000);

                    // }
                    // else{
                    //     this.$refs.wizard.changeTab(0,1)
                    // }
                } else {
                    swal({
                        type: "error",
                        title: res.message
                    });
                }
            });
            // if(show_response){
            //     this.$refs.wizard.nextTab()
            // }
            // else{
            //     this.$refs.wizard.changeTab(0,0)
            // }
        },
        submitAdmissionDetails(show_response){
            let formData = this.admission
            let cook = this.$cookies.get('kasp-pmjay')
            formData.updatedBy = cook.UserId
            formData.registrationId = this.basic.id
            let url = "admission/admission/add_admission";
            this.$http.post(url, formData).then(response => {
                let res = response.body;
                if (res.status) {
                    this.admission.flag=2
                    if(show_response){
                        swal({
                            type: "success",
                            title: res.message
                        });
                        window.location.reload(true)
                    }
                    else{
                        this.$refs.wizard.changeTab(1,2)
                    }
                // this.tabName = 'Upload Documents'
                } else {
                    swal({
                        type: "error",
                        title: res.message
                    });
                }
            });
            // if(show_response){
            //     this.$refs.wizard.nextTab()
            // }
            // else{
            //     this.$refs.wizard.changeTab(0,0)
            // }
        },
        submitTreatment(show_response){
            let cook= this.$cookies.get('kasp-pmjay')
            let formData = this.treatmentData
            formData.registrationId = this.basic.id
            formData.createdBy = cook.UserId
            formData.treatments = JSON.stringify(this.treatments)
            this.$http.post('treatment/treatment/add_treatment', formData)
            .then(response => {
                let res = response.body;
                if (res.status) {
                    this.treatmentData.flag=2
                    if(show_response){
                        swal({
                            type: "success",
                            title: res.message
                        });
                        window.location.reload(true)
                    }
                    else{
                        this.$refs.wizard.changeTab(2,3)
                    }
                // this.tabName = 'Upload Documents'
                } else {
                    swal({
                        type: "error",
                        title: res.message
                    });
                }
            })
        },
        uploadRegDocuments(show_response){
            if(show_response){
                this.handleResponse('success','Uploaded')
            }
        },
        handleResponse(type, message){
            swal({
                type: type,
                title: message
            })
            if(type == 'success'){
                this.$refs.wizard.reset()
            }
        },
        handleValidation: function(isValid, tabIndex){
            let count = 0
            let show_response = false
            for (var p in this.tabs) {
                if(this.tabs[p]){
                    count++
                }
            }
            // console.log(this.$refs.wizard.activeTabIndex)
            if(isValid && tabIndex == 0){
                if(count == 1){
                    show_response = true
                }
                this.submitBasic(show_response)
            }
            // else if(isValid && tabIndex == 1){
            //     if(count == 2){
            //         show_response = true
            //     }
            //     this.uploadRegDocuments(show_response)
            // }
            else if(isValid && tabIndex == 1){
                if(count == 2){
                    show_response = true
                }
                this.submitAdmissionDetails(show_response)
            }
            else if(isValid && tabIndex == 2){
                if(count == 3){
                    show_response = true
                }
                this.submitTreatment(show_response)
            }
            else if(isValid && tabIndex == 3){
                if(count == 4){
                    show_response = true
                }
                this.uploadRegDocuments(show_response)
            }
            else if(isValid && tabIndex == 4){
                if(count == 5){
                    show_response = true
                }
                this.uploadRegDocuments(show_response)
            }

            // if(isValid && tabIndex == count - 1){
            //     swal({
            //         type: 'success',
            //         title: 'submitted'
            //     })
            //     this.$refs.wizard.reset()
            // }
        //    console.log('Tab: '+tabIndex+ ' valid: '+isValid)
        },
        validateTab(step) {
            return new Promise((resolve, reject) => {
                if(step == 1){
                    this.$validator.validateAll('scope1').then(isValid => {
                        if(isValid){
                            resolve(true)
                            this.handleValidation(true,0)
                        }
                        else{
                            resolve(false)
                        }
                    })
                }
                else if(step == 2){
                    this.$validator.validateAll('scope3').then(isValid => {
                        if(isValid){
                            resolve(true)
                            this.handleValidation(true,1)
                        }
                        else{
                            resolve(false)
                        }
                    })
                }
                else if(step == 3){
                    this.$validator.validateAll('scope4').then(isValid => {
                        if(isValid){
                            resolve(true)
                            this.handleValidation(true,2)
                        }
                        else{
                            resolve(false)
                        }
                    })
                }
                else if(step == 4){
                    this.$validator.validateAll('scope4').then(isValid => {
                        if(isValid){
                            resolve(true)
                        }
                        else{
                            resolve(false)
                        }
                    })
                }
                else if(step == 5){
                    this.$validator.validateAll('scope5').then(isValid => {
                        if(isValid){
                            resolve(true)
                        }
                        else{
                            resolve(false)
                        }
                    })
                }
            })
        },
        getDetailsFromCard() {
            let cook = this.$cookies.get('kasp-pmjay')
            if(this.basic.cardId){
                this.$http.post("patient/patient/list_permanent_patient",
                {
                cardId: this.basic.cardId,
                hospitalId: cook.hospitalId
                })
                .then(response => {
                let res = response.body;
                let selectRes = [];
                if (res.status && res.hasrecords) {
                    this.patientExist = true
                    this.basic.name = res.records[0].name ? res.records[0].name : ''
                    this.basic.mobileNumber = res.records[0].mobileNumber ? res.records[0].mobileNumber : ''
                    this.basic.opNumber = res.records[0].opNumber ? res.records[0].opNumber : ''
                    this.basic.ipNumber = ''
                }
                else{
                    this.patientExist = false
                    this.basic.name = ''
                    this.basic.mobileNumber = ''
                    this.basic.opNumber = ''
                    this.basic.ipNumber = ''
                    this.$validator.reset()
                }
                });
            }
            else{
                this.patientExist = false
                this.basic.name = res.records[0].name
                this.basic.mobileNumber = res.records[0].mobileNumber
                this.basic.opNumber = ''
                this.basic.ipNumber = ''
                this.$validator.reset()
            }
        },
        getLabels(){
            if(this.basic.id){
                this.$http.post('patient/patient/list_document_patient',
                {
                id: this.basic.id,
                notIn: [1,3],
                requested: 'TRUE'
                })
                .then(response => {
                let res = response.body
                let selectRes = []
                if(res.status && res.hasrecords && res.records[0].document_relation.length > 0) {
                    for (let key in res.records[0].document_relation) {
                    let result = []
                    result['label'] = res.records[0].document_relation[key].label
                    result['labelId'] = res.records[0].document_relation[key].id
                    result['status'] = res.records[0].document_relation[key].status
                    result['cardId'] = res.records[0].cardId
                    result['patientId'] = res.records[0].id
                    result['departmentId'] = res.records[0].departmentId
                    result['loading'] = false
                    let images = []
                    if(res.records[0].document_relation[key].upload_relation.length > 0){
                        for(let key1 in res.records[0].document_relation[key].upload_relation){
                        let imageData = []
                        imageData['image'] = res.records[0].document_relation[key].upload_relation[key1].documentName
                        imageData['extension'] = res.records[0].document_relation[key].upload_relation[key1].ext
                        imageData['downloaded'] = res.records[0].document_relation[key].upload_relation[key1].downloaded
                        imageData['imageId'] = res.records[0].document_relation[key].upload_relation[key1].id
                        images.push(imageData)
                        }
                    }
                    result['images'] = images
                    selectRes.push(result)
                    }
                    this.labels = selectRes
                }
                else{
                    this.labels = []
                }
                })
            }
        },
        getRegLabels(){
            if(this.basic.id){
                this.$http.post('patient/patient/list_document_patient',
                {
                id: this.basic.id,
                sectionId: 1
                })
                .then(response => {
                let res = response.body
                let selectRes = []
                if(res.status && res.hasrecords && res.records[0].document_relation.length > 0) {
                    for (let key in res.records[0].document_relation) {
                    let result = []
                    result['label'] = res.records[0].document_relation[key].label
                    result['labelId'] = res.records[0].document_relation[key].id
                    result['status'] = res.records[0].document_relation[key].status
                    result['cardId'] = res.records[0].cardId
                    result['patientId'] = res.records[0].id
                    result['departmentId'] = res.records[0].departmentId
                    result['loading'] = false
                    let images = []
                    if(res.records[0].document_relation[key].upload_relation.length > 0){
                        for(let key1 in res.records[0].document_relation[key].upload_relation){
                        let imageData = []
                        imageData['image'] = res.records[0].document_relation[key].upload_relation[key1].documentName
                        imageData['extension'] = res.records[0].document_relation[key].upload_relation[key1].ext
                        imageData['downloaded'] = res.records[0].document_relation[key].upload_relation[key1].downloaded
                        imageData['imageId'] = res.records[0].document_relation[key].upload_relation[key1].id
                        images.push(imageData)
                        }
                    }
                    result['images'] = images
                    selectRes.push(result)
                    }
                    this.regDocs = selectRes
                }
                else{
                    this.regDocs = []
                }
                })
            }
        },
        getPerms(){
            let cook = this.$cookies.get('kasp-pmjay')
            // this.perms = ['first','second','third','fourth']
            this.perms = []
            if(cook.userType == 1 || cook.userType == 2){
                this.perms = ['first','second','third','fourth']
            }
            else if(cook.userType == 5){
                this.perms = ['first','second','third','fourth']
            }
            else if(cook.userType == 3){
                this.perms = ['first']
            }
            this.getTabs(this.perms,true)
        },
        getTabs(value, status){
            this.tabs = {
                first: false,
                second: false,
                third: false,
                fourth: false,
                fifth: false
            }
            for (var p in this.tabs) {
                if(value.includes(p)){
                    this.tabs[p] = status
                }
                else{
                    this.tabs[p] = !status
                }
            }
        },
        getDepartments() {
          let cook = this.$cookies.get('kasp-pmjay')
          this.$http.post('department/department/listDepartmentByUser',
          {
            'userId': cook.UserId,
            'userType': cook.userType
          })
          .then(response => {
            let res = response.body
            let selectRes = []
            if(res.status && res.hasrecords) {
              for (let key in res.records) {
                let result = []
                result['label'] = res.records[key].name
                result['value'] = res.records[key].id
                selectRes.push(result)
              }
              this.departments = selectRes
            }
          })
        },
        getRegisterDocs(){
            this.registerDocuments = [
                {
                    label: 'Photo',
                    labelId: 1,
                    image: ''
                },
                {
                    label: 'Aadhar',
                    labelId: 2,
                    image: ''
                }
            ]
        },
        getDoctors() {
            console.log('doc')
            let cook = this.$cookies.get('kasp-pmjay')
            if(cook.hospitalId){
                this.$http.post("doctor/doctor/list_doctor",
                {
                hospitalId: cook.hospitalId,
                sortOrder: 'DESC',
                deleteFlag: 1
                })
                .then(response => {
                let res = response.body;
                let selectRes = [];
                if (res.status && res.hasrecords) {
                    for (let key in res.records) {
                    let result = [];
                    result["value"] = res.records[key].id;
                    result["label"] = res.records[key].name;
                    selectRes.push(result);
                    }
                    this.doctors = selectRes;
                }
                });
            }
        },
        getWards() {
            let cook = this.$cookies.get('kasp-pmjay')
            if(cook.hospitalId){
            this.$http.post("ward/ward/list_ward",
            {
            hospitalId: cook.hospitalId,
            sortOrder: 'DESC'
            })
            .then(response => {
            let res = response.body;
            let selectRes = [];
            if (res.status && res.hasrecords) {
                for (let key in res.records) {
                let result = [];
                result["id"] = res.records[key].id;
                result["name"] = res.records[key].name;
                selectRes.push(result);
                }
                this.wards = selectRes;
            }
            else{
                this.wards = []
            }
            });
        }
        },
    },
    created(){        
        this.getPerms()
        this.getDepartments()
        this.getRegisterDocs()
        this.getDoctors()
        this.getWards()
    }
}
</script>

<style scoped>
.procedure-icon{
    font-size: 20px;
    position:absolute;
    right:10px;
    top:10px
}
.procedure-icon-container{
    position: relative;
}
.form-group input[type="file"]{
  opacity: 1;
  position: unset !important;
}
</style>