<template>
  <navbar navbarMenuClasses="red" type="primary" :transparent="false" v-model="showNavbar">
    <div class="navbar-wrapper">
      <div class="navbar-minimize">
        <button
          id="minimizeSidebar"
          class="btn btn-icon btn-round btn-rio"
          @click="minimizeSidebar"
        >
          <i class="nc-icon nc-minimal-right text-center visible-on-sidebar-mini"></i>
          <i class="nc-icon nc-minimal-left text-center visible-on-sidebar-regular"></i>
        </button>
      </div>
      <div class="navbar-toggle">
        <navbar-toggle-button @click.native="toggleSidebar">

        </navbar-toggle-button>
      </div>
      <router-link tag="a" class="navbar-brand" to>{{hospitalName ? hospitalName : ''}}</router-link>
    </div>
    <template slot="navbar-menu">
      <ul class="navbar-nav">
        <li class="nav-item">
          <!-- <a class="nav-link" href="">Hospital</a> -->
        </li>
        <li class="nav-item">
          <router-link tag="a" class="nav-link btn-magnify" :to="homeLink">
            <i class="fa fa-home" aria-hidden="true"></i>
          </router-link>
        </li>
        <el-badge :value="notificationCount" class="item notification-badge">
          <a @click.prevent="isActiveSlide = true,readNotification()" class="nav-link sp notification-icon" href="#">
            <i class="nc-icon nc-bell-55"></i>
          </a>
          <!-- <drop-down icon="nc-icon nc-bell-55" tag="li"
                    position="right"
                    direction="none"
                    class="nav-item btn-rotate dropdown notification-dropdown">
            <a slot="title"
              slot-scope="{isOpen}"
              class="nav-link dropdown-toggle notification-icon"
              data-toggle="dropdown"
              aria-haspopup="true"
              @click.prevent="readNotification"
              :aria-expanded="isOpen">
              <i class="nc-icon nc-bell-55"></i>
              <p>
                <span class="d-lg-none d-md-block">Some Actions</span>
              </p>
            </a>
          
            <button class="btn btn-info pull-right btn-sm" @click.prevent="$router.push('Notification')">View More</button>
          </drop-down>-->

          <div class="notification-side" :class="{slideActive : isActiveSlide}">
            <div class="not-header">
              <h5>Notification</h5>

              <a @click.prevent="isActiveSlide = false" href="#">
                <i class="fa fa-close"></i>
              </a>
            </div>
            <div class="notify-body">
              <div
                class="notify-item"
                v-for="notification in notifications"
                :key="notification.id"
                href="#"
              >
                <p>{{notification.label}}</p>
                <div class="noti-time">{{notification.time}} ({{notification.date ? notification.date : 'Date not available'}})</div>
              </div>
          
            </div>
             <div class="notify-footer">
      <button
                class="btn btn-info btn-sm"
                @click.prevent="viewMore()"
              >View More</button>
            </div>
          
          </div>
        </el-badge>
        <drop-down
          icon="nc-icon nc-bell-55"
          tag="li"
          position="right"
          direction="none"
          class="nav-item btn-rotate dropdown"
        >
          <a
            slot="title"
            slot-scope="{isOpen}"
            class="nav-link dropdown-toggle usr-top"
            data-toggle="dropdown"
            aria-haspopup="true"
            :aria-expanded="isOpen"
          >
            <div class="user-nav">
              <img src="/static/img/faces/face-2.jpg" alt="user avatar" />
            </div>
            <p>{{userName}}</p>
          </a>
          <!-- <a class="dropdown-item" href="#">Profile</a> -->
          <!-- <a class="dropdown-item" href="#">Change Password</a> -->
          <a @click.prevent="logout()" class="dropdown-item" href="#">Logout</a>
        </drop-down>
      </ul>
    </template>





  </navbar>
</template>
<script>
import { Navbar, NavbarToggleButton } from "src/components/UIComponents";
import VueSlideoutPanel from 'vue-slideout-panel';
import swal from "sweetalert2";
import moment from 'moment'
// import NotificationTemplate from './NotificationTemplate'
// const firebase = require('../../../../firebaseConfig.js');
export default {
  components: {
    Navbar,
    NavbarToggleButton,
      VueSlideoutPanel,
  },
  data() {
    return {
      isActiveSlide: false,
      homeLink: "/home",
      fcmToken: "",
      tokenToCheck: "",
      hospitalName: "",
      navPos: "static",
      activeNotifications: false,
      showNavbar: false,
      userName: "",
      notifications: [],
      notificationCount: 0,
    };
  },
  methods: {
    viewMore(){
      this.$router.push('Notification');
      this.isActiveSlide = false;
    },
    readNotification() {
      let cook = this.$cookies.get("kasp-pmjay");
      this.$http
        .post("notification/notification/make_read", {
          id: cook.UserId
        })
        .then(response => {
          let res = response.body;
          if (res.status) {
            this.notificationCount = 0;
          }
        });
    },
    getNotifications() {
      let cook = this.$cookies.get("kasp-pmjay");
      this.$http
        .post("notification/notification/list_notification", {
          // status: 1,
          userId: cook.UserId,
          sortOrder: "DESC",
          pagination: "TRUE",
          currentPage: 1,
          totalPerPage: 10
        })
        .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
            for (let key in res.records.data) {
              let result = [];
              result["label"] = res.records.data[key].notification_detail
                ? res.records.data[key].notification_detail.notification
                : "";
              result["time"] = res.records.data[key].created_at
                ? moment(res.records.data[key].created_at).fromNow()
                : "";
              result["date"] = res.records.data[key].created_at ? moment(res.records.data[key].created_at).format('DD-MM-YYYY') : ''
              result["id"] = res.records.data[key].id;
              if (res.records.data[key].status == 1) {
                this.notificationCount = this.notificationCount + 1;
              }
              selectRes.push(result);
            }
            this.notifications = selectRes;
          }
        });
    },
    logout() {
      let formData = {};
      let cook = this.$cookies.get("kasp-pmjay");
      formData.id = cook.UserId;
      formData.webFcmId = "";
      let url = "users/usermanagement/update_web_fcm";
      this.$http.post(url, formData).then(response => {
        let res = response.body;
        if (res.status) {
        } else {
        }
      });
      this.$cookies.remove("kasp-pmjay", "/");
      // this.$cookies.remove('kasp-fcm','/')
      this.$router.push("/login");
    },
    capitalizeFirstLetter(string) {
      return string.charAt(0).toUpperCase() + string.slice(1);
    },
    toggleNotificationDropDown() {
      this.activeNotifications = !this.activeNotifications;
    },
    closeDropDown() {
      this.activeNotifications = false;
    },
    minimizeSidebar() {
      this.$sidebar.toggleMinimize();
    },
    toggleSidebar() {
      this.$sidebar.displaySidebar(!this.$sidebar.showSidebar)
    },
    toggleNavbar() {
      this.showNavbar = !this.showNavbar;
    },
    getHospitalName() {
      let cook = this.$cookies.get("kasp-pmjay");
      if (cook.hospitalId) {
        this.$http
          .post("hospital/hospital/list_hospital", {
            id: cook.hospitalId
          })
          .then(response => {
            let res = response.body;
            let selectRes = [];
            if (res.status && res.hasrecords) {
              this.hospitalName = res.records[0].name;
            }
          });
      }
    },
    updateFcm() {
      let formData = {};
      let cook = this.$cookies.get("kasp-pmjay");
      formData.id = cook.UserId;
      formData.webFcmId = this.fcmToken;
      let url = "users/usermanagement/update_web_fcm";
      this.$http.post(url, formData).then(response => {
        let res = response.body;
        if (res.status) {
        } else {
        }
      });
    },
    updateFcmPeriodically() {
      let formData = {};
      let cook = this.$cookies.get("kasp-pmjay");
      formData.id = cook.UserId;
      formData.webFcmId = this.tokenToCheck;
      let url = "users/usermanagement/update_web_fcm";
      // console.log('cook'+fcm.fcmToken)
      if (cook.webFcm != this.tokenToCheck) {
        this.$http.post(url, formData).then(response => {
          let res = response.body;
          if (res.status) {
          } else {
          }
        });
      }
    },
    notifyVue(message) {
      this.$notifications.setOptions({
        type: "success",
        timeout: 2000,
        horizontalAlign: "right",
        verticalAlign: "bottom"
      });
      this.$notify({
        message: message
      });
    }
  },
  watch: {
    fcmToken: function(val) {
      this.updateFcm();
    }
  },
  created() {
    let th = this;
    let cook = this.$cookies.get("kasp-pmjay");
    if (cook.userType == 6) {
      this.homeLink = "/Hospitals";
    } else if (cook.userType == 3 || cook.userType == 4 || cook.userType == 5) {
      this.homeLink = "/HospitalLayout/NewRegistration";
    }
    this.userName = cook.name;
    this.getHospitalName();
    this.getNotifications();

    // firebase

    // firebase.messaging.requestPermission().then(() => {
    //     console.log('Notification permission granted.');
    //     firebase.messaging.getToken().then((token) => {
    //       this.tokenToCheck = token
    //       this.updateFcmPeriodically()
    //           console.log(token);
    //       })
    // }).catch((err) => {
    //     console.log('Unable to get permission to notify.', err);
    // });

    // firebase.messaging.onMessage(function(payload) {
    //   console.log("Message received. ", payload);
    //   th.$notifications.setOptions({
    //     type: 'primary',
    //     timeout: 10000,
    //     horizontalAlign: 'right',
    //     verticalAlign: 'bottom'
    //   })
    //   th.$notify(
    //     {
    //       message: payload.notification.body,
    //     })
    // });
    // firebase.messaging.onTokenRefresh(() => {
    //   firebase.messaging.getToken().then((refreshedToken) => {
    //     setTokenSentToServer(false);
    //     this.fcmToken = refreshedToken
    //     console.log(this.fcmToken)
    //   }).catch((err) => {
    //     console.log('Unable to retrieve refreshed token ', err);
    //     showToken('Unable to retrieve refreshed token ', err);
    //   });
    // });

    // firebase end
  }
};
</script>
<style>
.alert-primary {
  color: #fff !important;
}
.navbar .navbar-nav .usr-top {
  color: rgb(255, 255, 255);
  display: flex;
  align-items: center;
}

.usr-top p {
  color: rgb(255, 255, 255);
}
.user-nav {
  margin-right: 10px;
  width: 30px;
  height: 30px;
  overflow: hidden;
  border-radius: 50%;
  float: left;
}
.usr-top.dropdown-toggle:after {
  color: rgb(255, 255, 255);
  margin-left: 15px !important;
}
.btn-rio {
  background-color: transparent !important;
}
.btn-rio:hover {
  background-color: rgba(255, 255, 255, 0.349) !important;
}
</style>
