<template>
  <div>
    <main class="landing-Page" style="background-image: url('static/img/bg.jpg')">
      <TopNavbar></TopNavbar>
      <div class="landing-menu-sec">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <img class="img-fluid" :src="baseUrl+'static/img/img1.png'" alt />
            </div>

            <div class="col-md-6">
              <ul class="land-menu-ui">
                <li v-for="landLink in  landLinks" :key="landLink.Label">
                  <router-link :disabled="true" @click.prevent="linkClicked()" :to="landLink.Link">
                    <div>
                      <img :src="landLink.Icon" alt />
                      <p>{{landLink.Label}}</p>
                    </div>
                  </router-link>
                </li>
            
              </ul>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script>
import TopNavbar from "./TopNavbar.vue";
export default {
  components: {
    TopNavbar
  },
  data() {
    return{
      userSection: false,
      hospitalSection: false,
      baseUrl: process.env.BASE_URL,
      landLinks: []
    }
  },
  methods: {
    getLinks() {
      let cook= this.$cookies.get('kasp-pmjay')
      if(cook.userType == 1){
        this.landLinks = [
          {
            Label: "Departments",
            Link: "/Departments",
            Icon: "static/img/icons/masters.png"
          },
          {
            Label: "Hospitals",
            Link: "/Hospitals",
            Icon: "static/img/icons/hospital-con.png"
          },
          {
            Label: "Users",
            Link: "/Users/Users",
            Icon: "static/img/icons/tcf.png"
          }   
        ]
      }
      else if(cook.userType == 2){
        this.landLinks = this.landLinks
        // if(this.userSection && !this.hospitalSection){
        //   this.landLinks = [
        //     {
        //       Label: "Departments",
        //       Link: "/Departments",
        //       Icon: "static/img/icons/masters.png"
        //     },
        //     {
        //       Label: "Users",
        //       Link: "/Users/Users",
        //       Icon: "static/img/icons/tcf.png"
        //     }   
        //   ]
        // }
        // else if(!this.userSection && this.hospitalSection){
        //   this.landLinks = [
        //     {
        //       Label: "Departments",
        //       Link: "/Departments",
        //       Icon: "static/img/icons/masters.png"
        //     },
        //     {
        //       Label: "Hospitals",
        //       Link: "/Hospitals",
        //       Icon: "static/img/icons/hospital-con.png"
        //     },
            
        //   ]
        // }
        // else if(this.userSection && this.hospitalSection){
        //   this.landLinks = [
        //     {
        //       Label: "Departments",
        //       Link: "/Departments",
        //       Icon: "static/img/icons/masters.png"
        //     },
        //     {
        //       Label: "Hospitals",
        //       Link: "/Hospitals",
        //       Icon: "static/img/icons/hospital-con.png"
        //     },
        //     {
        //       Label: "Users",
        //       Link: "/Users/Users",
        //       Icon: "static/img/icons/tcf.png"
        //     }   
        //   ]
        // }
        // else{
        //   this.landLinks = []
        // }
      }
    },
    getPrevilages(){
      let cook = this.$cookies.get('kasp-pmjay')
      this.$http.post('privilege/privilege/user_privilege',{
        'id': cook.UserId,
        'menuType': 1
      })
      .then(response => {
        let res = response.body
        let selectRes = []
        if(res.status && res.hasrecords) {
          for (let key in res.records) {
            let result = []
            result['Label'] = res.records[key].label
            result['Link'] = res.records[key].path
            result['Icon'] = res.records[key].icon
            selectRes.push(result)         
          }
          this.landLinks = selectRes
        }
        this.getLinks()     
      })
    }
  },
  created(){
    this.getPrevilages()
    
  }
};
</script>

<style lang="scss">
.landing-Page {
  width: 100%;
  height: 100vh;
  background-size: cover;
  .landing-menu-sec {
    height: calc(100% - 130px);
    display: flex;
    align-items: center;
    .row {
      align-items: center;
      .land-menu-ui {
        list-style: none;
        li {
          margin: 15px;
          width: calc(33% - 30px);
          display: inline-block;
          text-align: center;
          a {
            transition: all 0.5s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 120px;
            width: 120px;
            border-radius: 20px;
            background-color: aliceblue;
            text-decoration: none;
            margin: auto;

            &:hover {
              transform: translateY(-15px);
            }

            p {
              font-size: 16px;
              font-weight: 600;
              margin: 0;
              color: rgb(17, 17, 17);
              margin-top: 10px;
            }
          }
        }
      }
    }
  }
}
</style>
