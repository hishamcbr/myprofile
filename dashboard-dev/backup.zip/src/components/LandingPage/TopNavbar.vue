<template>
  <navbar :position = 'navPos '  v-model="showNavbar">
    <div class="navbar-wrapper">
     
   
      <a class="navbar-brand" href="#pablo"><img class="land-logo"  src="static/img/7sigma2.png" alt=""></a>
    </div>

    <template slot="navbar-menu">
 
      <ul class="navbar-nav">
        <el-badge :value="notificationCount" class="item notification-badge">
          <drop-down icon="nc-icon nc-bell-55" tag="li"
                    position="right"
                    direction="none"
                    class="nav-item btn-rotate dropdown notification-dropdown">
            <a slot="title"
              slot-scope="{isOpen}"
              class="nav-link dropdown-toggle notification-icon"
              data-toggle="dropdown"
              aria-haspopup="true"
              @click.prevent="readNotification"
              :aria-expanded="isOpen">
              <i class="nc-icon nc-bell-55"></i>
              <p>
                <span class="d-lg-none d-md-block">Some Actions</span>
              </p>
            </a>
            <a v-for="notification in notifications" :key="notification.id" class="dropdown-item" href="#">{{notification.label}}</a>
            <button class="btn btn-info pull-right btn-sm" @click.prevent="$router.push('global-notification')">View More</button>
          </drop-down>
        </el-badge>
        <drop-down icon="nc-icon nc-bell-55" tag="li"
                   position="right"
                   direction="none"
                   class="nav-item btn-rotate dropdown">
          <a slot="title"
             slot-scope="{isOpen}"
             class="nav-link dropdown-toggle usr-top"
             data-toggle="dropdown"
             aria-haspopup="true"
             :aria-expanded="isOpen">
            <div class="user-nav"> <img src="static/img/faces/face-2.jpg" alt="user avatar"/></div>
            <p>{{userName}}</p>
          
          </a>
          <!-- <a class="dropdown-item" href="#">Profile</a>
          <a class="dropdown-item" href="#">Change Password</a> -->
          <a @click.prevent="logout()" class="dropdown-item" href="#">Logout</a>
        </drop-down>
    
      </ul>
    </template>
  </navbar>
</template>
<script>
  // const firebase = require('../../firebaseConfig.js');
  import { Navbar } from 'src/components/UIComponents'
  import swal from 'sweetalert2'
  export default {
    components: {
      Navbar
    },
    data() {
      return {
        activeNotifications: false,
        showNavbar: false,
        navPos: 'static',
        userName: '',
        notification: 'hello',
        fcmToken: '',
        tokenToCheck: '',
        notifications: [],
        notificationCount: 0
      }
    },
    methods: {
      readNotification(){
        let cook= this.$cookies.get('kasp-pmjay')
        this.$http.post('notification/notification/make_read', {
          id: cook.UserId
        }).then(response => {
          let res = response.body;
          if (res.status) {
            this.notificationCount = 0
          } 
        });
      },
      getNotifications(){
        let cook = this.$cookies.get('kasp-pmjay')
        this.$http.post('notification/notification/list_notification',
        {
          'userId': cook.UserId,
          'sortOrder': 'DESC',
          'pagination': 'TRUE',
          'currentPage': 1,
          'totalPerPage': 10
        })
        .then(response => {
          let res = response.body
          let selectRes = []
          if(res.status && res.hasrecords) {
            for (let key in res.records.data) {
              let result = []
              result['label'] = res.records.data[key].notification_detail ? res.records.data[key].notification_detail.notification : ''
              result['id'] = res.records.data[key].id
              if(res.records.data[key].status == 1){
                this.notificationCount = this.notificationCount + 1
              }              
              selectRes.push(result)
            }
            this.notifications = selectRes
          }
        })
      },
      logout(){
        let formData = {}
        let cook = this.$cookies.get('kasp-pmjay')
        formData.id = cook.UserId
        formData.webFcmId = ''
        let url = "users/usermanagement/update_web_fcm";
        this.$http.post(url, formData).then(response => {
          let res = response.body;
          if (res.status) {
            
          } else {
            
          }
        });
        this.$cookies.remove('kasp-pmjay', '/')
        // this.$cookies.remove('kasp-fcm','/')
        this.$router.push('/login')
      },
      capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1)
      },
      toggleNotificationDropDown() {
        this.activeNotifications = !this.activeNotifications
      },
      closeDropDown() {
        this.activeNotifications = false
      },
      toggleSidebar() {
        this.$sidebar.displaySidebar(!this.$sidebar.showSidebar)
      },
      hideSidebar() {
        this.$sidebar.displaySidebar(false)
      },
      minimizeSidebar() {
        this.$sidebar.toggleMinimize()
      },
      toggleNavbar() {
        this.showNavbar = !this.showNavbar;
      },
      updateFcm(){
        let formData = {}
        let cook = this.$cookies.get('kasp-pmjay')
        formData.id = cook.UserId
        formData.webFcmId = this.fcmToken
        let url = "users/usermanagement/update_web_fcm";
        this.$http.post(url, formData).then(response => {
          let res = response.body;
          if (res.status) {
            
          } else {
            
          }
        });
      },
      updateFcmPeriodically(){
        let formData = {}
        let cook = this.$cookies.get('kasp-pmjay')
        formData.id = cook.UserId
        formData.webFcmId = this.tokenToCheck
        let url = "users/usermanagement/update_web_fcm";
        // console.log('cook'+fcm.fcmToken)
        if(cook.webFcm != this.tokenToCheck){
          this.$http.post(url, formData).then(response => {
            let res = response.body;
            if (res.status) {
              
            } else {
              
            }
          });
        }
      },
      notifyVue(message) {
        this.$notifications.setOptions({
          type: 'success', 
          timeout: 2000,
          horizontalAlign: 'right',
          verticalAlign: 'bottom'
        })
        this.$notify(
          {
            message: message,
          })
      }
    },
    watch: {
      fcmToken: function (val) {
        this.updateFcm()
      }
    },
    created(){
      this.getNotifications()
      let th=this
      let cook= this.$cookies.get('kasp-pmjay')
      this.userName = cook.name

      // var config = {
      //     apiKey: "AIzaSyDxmA4nUt1AWZWZLaMJ943mPuLHCG4-JKk",
      //     authDomain: "vue-test-79a40.firebaseapp.com",
      //     databaseURL: "https://vue-test-79a40.firebaseio.com",
      //     projectId: "vue-test-79a40",
      //     storageBucket: "",
      //     messagingSenderId: "710174079953",
      //     appId: "1:710174079953:web:28db90f1b45981b0"
      // };
      // if (!firebase.apps.length) {
      //   firebase.initializeApp(config);
      // }
      
      
      // const messaging = firebase.messaging();
      // if (!firebase.apps.length) {
      //   messaging.usePublicVapidKey("BJ0zKXl5T201S-XBHhqFDNabYFAE_lbKLOq9lCrtxRhUOMWyreU4_uWTW-2WXNxQznKAB19o1Vh5Z6eWcf6KhlU");
      // }

      // firebase

      // firebase.messaging.requestPermission().then(() => {
      //     console.log('Notification permission granted.');
      //     firebase.messaging.getToken().then((token) => {           
      //       this.tokenToCheck = token
      //       this.updateFcmPeriodically()
            
      //           console.log(token);
      //     })
      // }).catch((err) => {
      //     console.log('Unable to get permission to notify.', err);
      // });
      
      // firebase.messaging.onMessage(function(payload) {
      //   console.log(this.notification)
      //   console.log("Message received. ", payload);
      //   th.$notifications.setOptions({
      //     type: 'primary', 
      //     timeout: 10000,
      //     horizontalAlign: 'right',
      //     verticalAlign: 'bottom'
      //   })
      //   th.$notify(
      //     {
      //       message: payload.notification.body,
      //     })
        
      // });
      // firebase.messaging.onTokenRefresh(() => {
      //   firebase.messaging.getToken().then((refreshedToken) => {
      //     console.log('Token refreshed.');
      //     setTokenSentToServer(false);
      //     console.log(refreshedToken)
      //     this.fcmToken = refreshedToken
      //   }).catch((err) => {
      //     console.log('Unable to retrieve refreshed token ', err);
      //     showToken('Unable to retrieve refreshed token ', err);
      //   });
      // });

      // firebase end
      

    }
  }

</script>


<style >
.alert-primary{
  color:#fff !important;
}
.usr-top{
  color: #fff;
  display: flex;
  align-items: center;
}

.usr-top p{
  color: #fff;
}
.user-nav {
  margin-right: 10px;
  width: 50px;
  height: 50px;
  overflow: hidden;
  border-radius: 50%;
  float: left;
}

.land-logo{
  width: 150px;
}
.usr-top.dropdown-toggle:after{
  color: #fff;
  margin-left: 15px !important;
}
</style>
