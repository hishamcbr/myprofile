<template>
  <div class="login-page">
    <app-navbar></app-navbar>
    <div class="wrapper wrapper-full-page">
      <div class="full-page login-page section-image">
        <!--   you can change the color of the filter page using: data-color="blue | azure | green | orange | red | purple" -->
        <div class="content">
          <div class="container">
            <div class="col-lg-4 col-md-6 ml-auto mr-auto">
              <form @submit="login">
                <card type="login">
                  <h3 slot="header" class="header text-center">Login</h3>

                  <fg-input v-validate="'required'" name="User Name" v-model="form.username" addon-left-icon="nc-icon nc-single-02"
                            placeholder="Email ID"></fg-input>
                            <small class="text-danger">
                              {{errors.first('User Name')}}
                            </small>

                  <fg-input style="margin-bottom:5px" v-validate="'required'" name="Password" v-model="form.password" addon-left-icon="nc-icon nc-key-25" placeholder="Password"
                            type="password"></fg-input>
                            <small class="text-danger">
                              {{errors.first('Password')}}
                            </small>
                  <!-- <br> -->

                  <!-- <p-checkbox>
                    Subscribe to newsletter
                  </p-checkbox> -->

                  <button @click.prevent="validate()" slot="footer" type="submit" round block class="mb-3 btn btn-success btn-sm">Get started</button>
                </card>
              </form>
            </div>
            <!-- <div class="col-md-4 ml-auto mr-auto">
              <center><button class="btn btn-primary btn-sm">Request For Login</button></center>
            </div> -->
          </div>
        </div>
        <el-dialog title="Request For Login" width="35%" :visible.sync="requestButton" style="">
          <div class="row">
            <div class="col-md-12">
              <p>{{errorMessage}}</p>
                <span slot="footer" class="dialog-footer">
                    <button class="btn btn-sm btn-fill btn-success" @click.prevent="requestLogin()">Request</button>
                    <button class="btn btn-sm btn-fill btn-primary" @click.prevent="requestButton=false">Cancel</button>
                </span>
            </div>
          </div>
        </el-dialog>
        <div class="clearfix"></div>
        <app-footer></app-footer>
        <div class="full-page-background" style="background-image: url(static/img/background/background-2.jpg) "></div>
      </div>
    </div>
  </div>
</template>
<script>
  import { Card, Checkbox, Button } from 'src/components/UIComponents';
  import AppNavbar from './Layout/AppNavbar'
  import AppFooter from './Layout/AppFooter'
  import swal from 'sweetalert2'

  export default {
    components: {
      Card,
      AppNavbar,
      AppFooter,
      [Button.name]: Button
    },
    data() {
      return {
        form: {
          username: '',
          password: ''
        },
        userId: '',
        requestButton: false,
        errorMessage: ''
      }
    },
    methods: {
      requestLogin(){
        if(this.userId){
          this.$http.post('users/usermanagement/login_request_web',
          {
            'id': this.userId
          })
          .then(response => {
            let res = response.body
            if(res.status){
              this.requestButton = false
              this.userId = ''
              this.form.username= ''
              this.form.password = ''
              this.$validator.reset()
              swal({
                type: 'success',
                title: res.message
              })
            }
            else{
              swal({
                  type: 'error',
                  title: res.message
              })
            }
          })
        }
        else{
          swal({
              type: 'error',
              title: 'Failed To get User'
          })
        }
        
      },
      validate(){
        this.$validator.validateAll().then(isValid => {
          if(isValid){
            console.log('valid')
            this.login()
          }
        })
      },
      login(){
        this.$http.post('users/usermanagement/login',
        {
          'userName': this.form.username,
          'password': this.form.password,
          'deviceId': ''
        })
        .then(response => {
        let res = response.body
        if(res.status){
          let user = {
            UserId: res.records.userId,
            userType: res.records.userType,
            hospitalId: res.records.hospitalId,
            name: res.records.name,
            token: res.records.token,
            webFcm: res.records.webFcmId
          }
          this.$cookies.set('kasp-pmjay', JSON.stringify(user), '2h', '/')
          if(res.records.userType == 1){
            this.$router.push('/home')
          }
          else if(res.records.userType == 3){
            this.$router.push('/HospitalLayout/NewRegistration')
          }
          else if(res.records.userType == 4){
            this.$router.push('/HospitalLayout/NewRegistration')      
          }
          else if(res.records.userType == 5){
            this.$router.push('/HospitalLayout/NewRegistration')      
          }
          else if(res.records.userType == 2){
            this.$router.push('/home')
          }
          else if(res.records.userType == 6){
            this.$router.push('/Hospitals')
          }
          else{
            this.$cookies.remove('kasp-pmjay', '/')
            let th = this
            swal({
              type: 'error',
              title: 'You have no access to dashboard'
            }).then(function(ok){
              th.$router.push('/login')
            })
          }
        }
        else if(res.RequestLogin){
          this.userId = res.UserId ? res.UserId : ''
          this.errorMessage = res.message
          this.requestButton = true
        }
        else{
           swal({
              type: 'error',
              title: res.message
            })
        }
        })
      },
      toggleNavbar() {
        document.body.classList.toggle('nav-open')
      },
      closeMenu() {
        document.body.classList.remove('nav-open')
        document.body.classList.remove('off-canvas-sidebar')
      }
    },
    beforeDestroy() {
      this.closeMenu()
    }
  }
</script>
<style>
</style>
