<template>
  <div>
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">
          {{ actionType == 'create' ? 'Add Hospital' : 'Edit Hospital' }}
          <a
            @click.prevent="$emit('changeComponent','listing')"
            href
          >
            <i style="margin-top:-20px" class="fa fa-times pull-right"></i>
          </a>
        </h4>
      </div>
      <div class="card-body">
        <vue-tabs class="card-content" v-model="tabName" @tab-change="handleTabChange">
          <v-tab title="Basic Details" style="width:100%">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for>Enter Hospital Name<span class="text-danger">*</span> :</label>
                  <input v-model="basicData.name" v-validate="'required'" data-vv-scope="basicScope" type="text" class="form-control" placeholder="Enter Hospital Name" name="Hospital Name"/>
                  <small class="text-danger">
                    {{errors.first('basicScope.Hospital Name')}}
                  </small>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for> Enter Hospital Location <span class="text-danger">*</span> :</label>
                  <input v-model="basicData.location" v-validate="'required'" data-vv-scope="basicScope" type="text" class="form-control"  placeholder="Enter Hospital Location" name="Location of hospital"/>
                  <small class="text-danger">
                    {{errors.first('basicScope.Location of hospital')}}
                  </small>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for>Enter Contact Number<span class="text-danger">*</span> :</label>
                  <input v-model="basicData.contactNumber" v-validate="'required'" data-vv-scope="basicScope" type="text" class="form-control" placeholder="Enter Contact Number" name="Contact Number"/>
                  <small class="text-danger">
                    {{errors.first('basicScope.Contact Number')}}
                  </small>
                </div>
              </div>
            </div>
            <button class="btn btn-primary" @click.prevent="tabName='Doctors Details'">Next</button>
          </v-tab>
          <v-tab title="Doctors Details">
            <div class="row">
              <div class="col-md-12">
                <a href="pmjay.sevensigma.in/api/v1/sample/doctor.xlsx" class="btn btn-sm btn-primary" download>Download Sample</a>
                <button @click.prevent="uploadExcel()" class="btn btn-sm btn-success">Import Doctors</button>
              </div>
              <div class="col-md-12">
                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Doctor Name</th>
                        <th>Registration No.</th>
                        <th>Qualification</th>
                        <th>Mobile No</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <input
                            type="text"
                            class="form-control lower-input"
                            placeholder="Enter Doctor Name"
                            name="Doctor Name"
                            v-model="doctorsData.name"
                            v-validate="'required'"
                            data-vv-scope="doctorsScope"
                          />
                          <small class="text-danger">
                            {{errors.first('doctorsScope.Doctor Name')}}
                          </small>
                        </td>
                        <td>
                          <input
                            type="text"
                            class="form-control lower-input"
                            placeholder="Enter Registration Number"
                            name="Registration Number"
                            v-model="doctorsData.registrationNo"
                            v-validate="'required'"
                            data-vv-scope="doctorsScope"
                          />
                          <small class="text-danger">
                            {{errors.first('doctorsScope.Registration Number')}}
                          </small>
                        </td>
                        <td>
                          <input
                            type="text"
                            class="form-control lower-input"
                            placeholder="Enter 'Doctor's qualification'"
                            name="Qualification"
                            v-model="doctorsData.qualification"
                            v-validate="'required'"
                            data-vv-scope="doctorsScope"
                          />
                          <small class="text-danger">
                            {{errors.first('doctorsScope.Qualification')}}
                          </small>
                        </td>
                        <td>
                          <input
                            type="text"
                            class="form-control lower-input"
                            placeholder="Enter Doctor's Mobile Number"
                            name="Mobile Number"
                            v-model="doctorsData.mobileNumber"
                            v-validate="'required'"
                            data-vv-scope="doctorsScope"
                          />
                          <small class="text-danger">
                            {{errors.first('doctorsScope.Mobile Number')}}
                          </small>
                        </td>
                        <td>
                          <button class="btn btn-outline-primary btn-sm" @click.prevent="validateDoctor">
                            <i class="fa fa-plus" aria-hidden="true"></i>
                          </button>
                          <button class="btn btn-outline-danger btn-sm" @click.prevent = "clearAddForm">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </button>
                        </td>
                      </tr>
                    </tbody>
                    <tbody v-if="doctors.length > 0">
                      <tr v-for="(doctor, index) in doctors" :key="index">
                        <!-- <td width="10">{{index+1}}</td> -->
                        <td>{{doctor.name}}</td>
                        <td>{{doctor.registrationNumber}}</td>
                        <td>{{doctor.qualification}}</td>
                        <td>{{doctor.mobileNumber}}</td>
                        <td>
                          <button class="btn btn-outline-success btn-sm" @click.prevent="handleEditDoctor(doctor)">
                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                          </button>
                          <button class="btn btn-outline-danger btn-sm" @click.prevent="handleDeleteDoctor(doctor)"> 
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </v-tab>
          <v-tab title="Ward Details">
            <div class="row">
              <div class="col-md-12">
                <a href="https://pmjay.sevensigma.in/api/v1/sample/ward.xlsx" class="btn btn-sm btn-primary" download>Download Sample</a>
                <button @click.prevent="uploadWardExcel()" class="btn btn-sm btn-success">Import Ward</button>
              </div>
              <div class="col-md-12">
                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Ward Name</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <input
                            type="text"
                            class="form-control lower-input"
                            placeholder="Enter Ward Name"
                            name="Ward Name"
                            v-model="wardData.name"
                            v-validate="'required'"
                            data-vv-scope="wardScope"
                            @keyup.enter="validateWard"
                          />
                          <small class="text-danger">
                            {{errors.first('wardScope.Ward Name')}}
                          </small>
                        </td>
                        <td>
                          <button class="btn btn-outline-primary btn-sm" @click.prevent="validateWard">
                            <i class="fa fa-plus" aria-hidden="true"></i>
                          </button>
                          <button class="btn btn-outline-danger btn-sm" @click.prevent = "clearWardForm">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </button>
                        </td>
                      </tr>
                    </tbody>
                    <tbody v-if="wards.length > 0">
                      <tr v-for="(ward, index) in wards" :key="index">
                        <!-- <td width="10">{{index+1}}</td> -->
                        <td>{{ward.name}}</td>
                        <td>
                          <button class="btn btn-outline-success btn-sm" @click.prevent="handleEditWard(ward)">
                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                          </button>
                          <button class="btn btn-outline-danger btn-sm" @click.prevent="handleDeleteWard(ward)"> 
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </v-tab>
          <v-tab title="PMJAY Details" style="width:100%">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for>PMJAY User Name<span class="text-danger">*</span> :</label>
                  <input  v-model="pmjayData.userName" v-validate="'required'" data-vv-scope="pmjayScope" type="text" class="form-control lower-input" placeholder="Enter PMJAY User Name" name="PMJAY User Name"/>
                  <small class="text-danger">
                    {{errors.first('pmjayScope.PMJAY User Name')}}
                  </small>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for> PMJAY Password<span class="text-danger">*</span> :</label>
                  <input v-model="pmjayData.passWord" v-validate="'required'" data-vv-scope="pmjayScope" type="text" class="form-control lower-input"  placeholder="Enter PMJAY Password" name="PMJAY Password"/>
                  <small class="text-danger">
                    {{errors.first('pmjayScope.PMJAY Password')}}
                  </small>
                </div>
              </div>
            </div>
            <button class="btn btn-primary" @click.prevent="validatePmjayDetails()">Save</button>
          </v-tab>
        </vue-tabs>
        <el-dialog  :show-close="false" :before-close="preventClose"  :title="'Edit Details of  '+editDoctor.name" width="90%" :visible.sync="editDoctorModal" style="">
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label>Doctor Name</label>
                <input v-model="editDoctor.name" type="text" class="form-control lower-input" placeholder="Doctor's Name" v-validate="'required'" data-vv-scope="editDoctorScope" name="Doctor's Name"> 
                <small class="text-danger">
                  {{errors.first("editDoctorScope.Doctor's Name")}}
                </small>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label>Registration No.</label>
                <input v-model="editDoctor.registrationNo" type="text" class="form-control lower-input" placeholder="Registration No." v-validate="'required'" data-vv-scope="editDoctorScope" name="Registration Number"> 
                <small class="text-danger">
                  {{errors.first("editDoctorScope.Registration Number")}}
                </small>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label>Qualification</label>
                <input v-model="editDoctor.qualification" type="text" class="form-control lower-input" placeholder="Doctor's Qualification" v-validate="'required'" data-vv-scope="editDoctorScope" name="Qualification"> 
                <small class="text-danger">
                  {{errors.first("editDoctorScope.Qualification")}}
                </small>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label>Mobile Number</label>
                <input v-model="editDoctor.mobileNumber" type="text" class="form-control lower-input" placeholder="Mobile Number" v-validate="'required'" data-vv-scope="editDoctorScope" name="Mobile Number"> 
                <small class="text-danger">
                  {{errors.first("editDoctorScope.Mobile Number")}}
                </small>
              </div>
            </div>
            <input type="hidden" v-model="editDoctor.id">
            <div class="col-md-12">
                <span slot="footer" class="dialog-footer">
                    <button class="btn btn-sm btn-fill btn-success" @click.prevent="validateDoctorEdit()">Update</button>
                    <button class="btn btn-sm btn-fill btn-danger" @click.prevent="editDoctorModal=false">Cancel</button>
                </span>
            </div>
          </div>
        </el-dialog>
        <el-dialog  :show-close="false" :before-close="preventClose"  :title="'Edit Details of  '+editWard.name" width="40%" :visible.sync="editWardModal" style="">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label>Ward Name</label>
                <input v-model="editWard.name" type="text" class="form-control lower-input" placeholder="Ward Name" v-validate="'required'" data-vv-scope="editWardScope" name="Ward Name"> 
                <small class="text-danger">
                  {{errors.first("editWardScope.Ward Name")}}
                </small>
              </div>
            </div>
            <input type="hidden" v-model="editWard.id">
            <div class="col-md-12">
                <span slot="footer" class="dialog-footer">
                    <button class="btn btn-sm btn-fill btn-success" @click.prevent="validateWardEdit()">Update</button>
                    <button class="btn btn-sm btn-fill btn-danger" @click.prevent="editWardModal=false">Cancel</button>
                </span>
            </div>
          </div>
        </el-dialog>
        <el-dialog :show-close="false" :before-close="preventClose"  title="Upload Excel" width="35%" :visible.sync="uploadModal" style="">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="">Select File</label>
                <input ref="document" @change="selectAttachment" name="File" type="file" class="form-control" data-vv-scope="uploadScope"  v-validate="'required'">
                <small class="text-danger">
                  {{ errors.first('uploadScope.File') }}  
                </small> 
              </div>
            </div>
            <div class="col-md-12">
                <span slot="footer" class="dialog-footer">
                    <button v-if="!loadingButton" class="btn btn-sm btn-fill btn-success" @click.prevent="validateUpload()">Upload</button>
                    <el-button class="btn-sm" v-if="loadingButton" type="primary" :loading="true">Uploading...</el-button>
                    <button :disabled="loadingButton" class="btn btn-sm btn-fill btn-danger" @click.prevent="uploadModal=false">Cancel</button>
                </span>
            </div>
          </div>
        </el-dialog>
        <el-dialog :show-close="false" :before-close="preventClose"  title="Upload Excel" width="35%" :visible.sync="uploadWardModal" style="">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="">Select File</label>
                <input ref="ward" @change="selectAttachment" name="File" type="file" class="form-control" data-vv-scope="uploadWardScope"  v-validate="'required'">
                <small class="text-danger">
                  {{ errors.first('uploadWardScope.File') }}  
                </small> 
              </div>
            </div>
            <div class="col-md-12">
                <span slot="footer" class="dialog-footer">
                    <button v-if="!loadingButton" class="btn btn-sm btn-fill btn-success" @click.prevent="validateWardUpload()">Upload</button>
                    <el-button class="btn-sm" v-if="loadingButton" type="primary" :loading="true">Uploading...</el-button>
                    <button :disabled="loadingButton" class="btn btn-sm btn-fill btn-danger" @click.prevent="uploadWardModal=false">Cancel</button>
                </span>
            </div>
          </div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>
<script>
import swal from "sweetalert2";
// import { Tabs, TabPane } from "src/components/UIComponents";
export default {
  components: {
    // Tabs,
    // TabPane
  },
  props: ["data"],
  data() {
    return {
      attachment: '',
      tabName: '',
      actionType: "create",
      basicData: {
        id: '',
        name: '',
        location: '',
        contactNumber: ''
      },
      doctorsData: {
        name: '',
        registrationNo: '',
        qualification: '',
        mobileNumber: ''
      },
      wardData: {
        name: ''
      },
      editWard: {
        id: '',
        name: ''
      },
      editDoctor: {
        id: '',
        name: '',
        registrationNo: '',
        qualification: '',
        mobileNumber: ''
      },
      pmjayData: {
        userName: '',
        passWord: ''
      },
      doctors: [],
      wards: [],
      editDoctorModal: false,
      editWardModal: false,
      loadingButton: false,
      uploadModal: false,
      uploadWardModal: false
    };
  },
  methods: {
    preventClose(){

    },
    validateWardUpload(){
      this.$validator.validateAll('uploadWardScope').then(isValid => {
        if(isValid){
          this.loadingButton = true
          this.uploadWardDocument()
        }
      })
    },
    uploadWardDocument(){
      let form_data = new FormData()
      // formData.patientType = this.uploadType
      // formData.patientcsv = this.attachment
      form_data.append('hospitalId',this.basicData.id)
      form_data.append('ward',this.attachment)
      // form_data.append('file',this.imageUrl)
      // form_data.append('labelId',this.uploadData.labelId)
      // form_data.append('registrationId',this.uploadData.registrationId)
      this.$http.post('ward/ward/import_ward_excel', form_data, {
        headers: {
						'Content-Type': 'multipart/form-data'
					}
        }).then(response => {
        let res = response.body;
        if (res.status) {
          this.$refs.ward.value = ''
          // document.getElementById('upload').value='';
          this.loadingButton = false
          swal({
            type: "success",
            title: res.message.message
          });
          this.getWards()
          this.uploadWardModal = false 
          // this.$router.push('/HospitalLayout/PatientPendingList')
        } else {
          // this.$refs.document.value = ''
          // document.getElementById('upload').value='';
          this.loadingButton = false
          swal({
            type: "error",
            title: res.message.message
          });
        }
      });
    },
    validateUpload(){
      this.$validator.validateAll('uploadScope').then(isValid => {
        if(isValid){
          this.loadingButton = true
          this.uploadDocument()
        }
      })
    },
    uploadDocument(){
      let form_data = new FormData()
      // formData.patientType = this.uploadType
      // formData.patientcsv = this.attachment
      form_data.append('hospitalId',this.basicData.id)
      form_data.append('doctorcsv',this.attachment)
      // form_data.append('file',this.imageUrl)
      // form_data.append('labelId',this.uploadData.labelId)
      // form_data.append('registrationId',this.uploadData.registrationId)
      this.$http.post('doctor/doctor/import_doctor', form_data, {
        headers: {
						'Content-Type': 'multipart/form-data'
					}
        }).then(response => {
        let res = response.body;
        if (res.status) {
          this.$refs.document.value = ''
          // document.getElementById('upload').value='';
          this.loadingButton = false
          swal({
            type: "success",
            title: res.message.message
          });
          this.getDoctors()
          this.uploadModal = false 
          // this.$router.push('/HospitalLayout/PatientPendingList')
        } else {
          // this.$refs.document.value = ''
          // document.getElementById('upload').value='';
          this.loadingButton = false
          swal({
            type: "error",
            title: res.message.message
          });
        }
      });
    },
    selectAttachment:function($event){
        this.attachment =$event.target.files[0]
        // const fr = new FileReader ()
        // fr.readAsDataURL($event.target.files[0])
				// fr.addEventListener('load', () => {
        //   this.imageSelected = true
        //   this.imageUrl = fr.result             
        // })
        // this.extension = this.attachment.name.split('.').pop()      
    },
    uploadExcel(val){
      this.loadingButton = false
      this.uploadModal = true 
      if(this.$refs.document){
        this.$refs.document.value = ''
      }
                
    },
    uploadWardExcel(val){
      this.loadingButton = false
      this.uploadWardModal = true 
      if(this.$refs.ward){
        this.$refs.ward.value = ''
      }                
    },
    validatePmjayDetails(){
      this.$validator.validateAll('pmjayScope').then(isValid => {
        if(isValid){
          this.addPmjayDetails()
        }
      })
    },
    addPmjayDetails() {
      let formData = this.pmjayData
      formData.id = this.basicData.id
      let url = "hospital/hospital/add_hospital_password";
      if (this.actionType == "update") {
        url = "hospital/hospital/edit_hospital_password";
      }
      this.$http.post(url, formData).then(response => {
        let res = response.body;
        if (res.status) {
          swal({
            type: "success",
            title: res.message
          });
          this.$emit('changeComponent','listing')
        } else {
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    handleDeleteDoctor(row){
      swal({
        type: 'question',
        title: '',
        text: 'Are you sure to delete doctor - '+row.name+ '?',
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
      })
      .then(result => {
        if (result) {
          this.$http.post('doctor/doctor/delete_doctor',{
            'id': row.id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getDoctors()
            }
          })
        }
      })
    },
    handleDeleteWard(row){
      swal({
        type: 'question',
        title: '',
        text: 'Are you sure to delete ward - '+row.name+ '?',
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
      })
      .then(result => {
        if (result) {
          this.$http.post('ward/ward/delete_ward',{
            'id': row.id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getWards()
            }
          })
        }
      })
    },
    clearAddForm(){
      this.doctorsData = {
        name: '',
        registrationNo: '',
        qualification: '',
        mobileNumber: ''
      }
      this.$validator.reset()
    },
    clearWardForm(){
      this.wardData = {
        name: ''
      }
      this.$validator.reset()
    },
    handleEditDoctor(row){
      this.editDoctor = {
        id: row.id,
        name: row.name,
        registrationNo: row.registrationNumber,
        qualification: row.qualification,
        mobileNumber: row.mobileNumber
      }
      this.editDoctorModal = true
    },
    validateDoctorEdit(){
      this.$validator.validateAll('editDoctorScope').then(isValid => {
        if(isValid){
          this.addDoctor('edit')
        }
      })
    },
    handleEditWard(row){
      this.editWard = {
        id: row.id,
        name: row.name
      }
      this.editWardModal = true
    },
    validateWardEdit(){
      this.$validator.validateAll('editWardScope').then(isValid => {
        if(isValid){
          this.addWard('edit')
        }
      })
    },
    handleTabChange(tabIndex, newTab, oldTab){      
      if(tabIndex == 1 && oldTab.title == 'Basic Details' || tabIndex == 2 && oldTab.title == 'Basic Details'){
        this.validateBasic(newTab.title)
      }
    },
    validateBasic(tab){
      this.$validator.validateAll('basicScope').then(isValid => {
        if(isValid){
          this.submitBasic(tab)
        }
        else{
          this.tabName = 'Basic Details'
        }
      })
    },
    submitBasic(tab) {
      let formData = this.basicData
      let url = "hospital/hospital/add_hospital";
      if (this.actionType == "update") {
        formData.id = this.basicData.id
        url = "hospital/hospital/edit_hospital";
      }
      this.$http.post(url, formData).then(response => {
        let res = response.body;
        if (res.status) {
          if(this.actionType == 'create'){
            this.basicData.id = res.records
          }
          this.actionType = 'update'
          this.tabName = tab
        } else {
          this.tabName = 'Basic Details'
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    validateDoctor(){
      this.$validator.validateAll('doctorsScope').then(isValid => {
        if(isValid){
          this.addDoctor('add')
        }
      })
    },
    validateWard(){
      this.$validator.validateAll('wardScope').then(isValid => {
        if(isValid){
          this.addWard('add')
        }
      })
    },
    addDoctor(type){
      let formData = this.doctorsData
      let url = "doctor/doctor/add_doctor";
      if(type == 'edit'){
        formData = this.editDoctor
        url = "doctor/doctor/edit_doctor";
      }
      formData.hospitalId = this.basicData.id
      this.$http.post(url, formData).then(response => {
        let res = response.body;
        if (res.status) {
          this.getDoctors();
          if(type == 'edit'){
            this.editDoctorModal = false
            this.editDoctor = {
              id: '',
              name: '',
              registrationNo: '',
              qualification: '',
              mobileNumber: ''
            }
          }else{
            this.doctorsData = {
              name: '',
              registrationNo: '',
              qualification: '',
              mobileNumber: ''
            }
          }
          this.$validator.reset()
          swal({
            type: "success",
            title: res.message
          });
        } else {
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    addWard(type){
      let formData = this.wardData
      let url = "ward/ward/add_ward";
      if(type == 'edit'){
        formData = this.editWard
        url = "ward/ward/edit_ward";
      }
      formData.hospitalId = this.basicData.id
      this.$http.post(url, formData).then(response => {
        let res = response.body;
        if (res.status) {
          this.getWards();
          if(type == 'edit'){
            this.editWardModal = false
            this.editWard = {
              id: '',
              name: ''
            }
          }else{
            this.wardData = {
              name: ''
            }
          }
          this.$validator.reset()
          swal({
            type: "success",
            title: res.message
          });
        } else {
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    getDoctors() {
      if(this.basicData.id){
        this.$http.post("doctor/doctor/list_doctor", 
        { 
          hospitalId: this.basicData.id,
          sortOrder: 'DESC',
          deleteFlag: 1 
        })
        .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
            for (let key in res.records) {
              let result = [];
              result["id"] = res.records[key].id;
              result["name"] = res.records[key].name;
              result["registrationNumber"] = res.records[key].registrationNo;
              result["qualification"] = res.records[key].qualification;
              result["mobileNumber"] = res.records[key].mobileNumber;
              selectRes.push(result);
            }
            this.doctors = selectRes;
          }
        });
      }
    },
    getWards() {
      if(this.basicData.id){
        this.$http.post("ward/ward/list_ward", 
        { 
          hospitalId: this.basicData.id,
          sortOrder: 'DESC'
        })
        .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
            for (let key in res.records) {
              let result = [];
              result["id"] = res.records[key].id;
              result["name"] = res.records[key].name;
              selectRes.push(result);
            }
            this.wards = selectRes;
          }
          else{
            this.wards = []
          }
        });
      }
    },
    getPmjayCreds(){
      if(this.basicData.id){
        this.$http.post("hospital/hospital/get_login_details", 
        { 
          hospitalId: this.basicData.id,
          key: '$Ae~5~ACF8'
        })
        .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
            this.pmjayData = {
              userName: res.records.username,
              passWord: res.records.password
            }
          }
        });
      }
    }
  },
  created() {
    if (JSON.stringify(this.data) != "{}") {
      let hospital = this.data
      this.actionType = 'update'
      this.basicData.id = hospital.id ? hospital.id : ''
      this.getDoctors();
      this.getWards();
      this.getPmjayCreds()
      this.basicData.name = hospital.name ? hospital.name : ''
      this.basicData.location = hospital.location ? hospital.location : ''
      this.basicData.contactNumber = hospital.contactNumber ? hospital.contactNumber : ''
    }    
  }
};
</script>
<style>

.nav-tabs-navigation {
  border-bottom: 0 !important;
}
.vue-tabs .tab-content,
.vue-tabs .nav-tabs-navigation {
  text-align: left;
}
.vue-tabs .nav-tabs > li > a {
  text-decoration: none;
  font-size: 16px;
  border: 1px solid rgba(0, 0, 0, 0.116);
}

.vue-tabs .nav-tabs > li.tab.active > a {
  background-color: #105a94 !important;
  color: rgb(255, 255, 255);
}

.vue-tabs .nav-tabs > li.tab.active > a::before {
  content: none;
}
.vue-tabs .nav-tabs-wrapper {
  margin: 0;
}
.vue-tabs .nav-tabs-navigation .nav > li > a {
  padding: 15px 30px;
}

.vue-tabs .nav-tabs > li.active a:before {
  content: none !important;
}
/* .el-dialog__wrapper{
  z-index: 1059 !important
} */
.swal2-container{
  z-index: 2050 !important;
}
</style>

<style scoped>
.form-group input[type="file"]{
  opacity: 1;
  position: unset !important;
}
.card.form-card {
  overflow: hidden;
  transition: all 0.5s ease;
  /* max-height: 0px; */
  width: 50%;
}
.form-card.slide {
  transition: all 0.5s ease;
  /* max-height:100vh; */
}
.rio-select input {
  background-color: rgb(255, 255, 255) !important;
  color: black !important;
}
.rio-select:hover input {
  color: black !important ;
}
.nav-tabs-navigation {
  text-align: left !important;
}
</style>
