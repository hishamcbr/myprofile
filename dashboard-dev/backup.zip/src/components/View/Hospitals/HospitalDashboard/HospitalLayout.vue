<template>
  <div class="wrapper">
    <side-bar
      backgroundColor="white"
      type="sidebar"
      :sidebar-links="HospitalMenus"
      active-color="primary">
      <!-- <user-menu></user-menu> -->
      <!-- <user-menu></user-menu> -->
    </side-bar>
    <div class="main-panel">
      <top-navbar></top-navbar>
      
      <dashboard-content @click.native="toggleSidebar">

      </dashboard-content>
      <content-footer></content-footer>
    </div>
  </div>
</template>

<script>
import TopNavbar from "./TopNavbar.vue";
import ContentFooter from "../../ContentFooter.vue";
import DashboardContent from "./Content.vue";
import UserMenu from 'src/components/UIComponents/SidebarPlugin/UserMenu.vue'
export default {
  components: {
    DashboardContent,
    ContentFooter,
    TopNavbar,
    UserMenu,
  },
  data() {
    return {
      
      userType: '',
      HospitalMenus: [],
      subAdminPrevilages: [],
    };
  },
  methods: {
    toggleSidebar () {
      if (this.$sidebar.showSidebar) {
        this.$sidebar.displaySidebar(false)
      }
    },
    getLinks(){
      const dashboard = {
        name: "Dashboard",
        icon: "fa fa-home",
        path: "/HospitalLayout/hospitalDashboard"
      }
      const patientRegistration = {
        name: "New Registration",
        icon: "fa fa-user-plus",
        path: "/HospitalLayout/NewRegistration"
      }
      const application = {
        name: "Admission List",
        icon: "fa fa-users",
        path: "/HospitalLayout/ApplicationList"
      }
      const coding = {
        name: "Coding List",
        icon: "fa fa-users",
        path: "/HospitalLayout/CodingList"
      }
      const patientList = {
        name: "Patient List",
        icon: "fa fa-user",
        children: [
          {
            name: "Pending",

            path: "/HospitalLayout/PatientPendingList"
          },
          {
            name: "Registered ",

            path: "/HospitalLayout/PatientRegisteredList"
          },
          {
            name: "Completed  ",

            path: "/HospitalLayout/PatientCompletedList"
          }
        ]
      }
      const masterPatientList = {
        name: "Master Patient List",
        icon: "fa fa-users",
        path: '/HospitalLayout/MasterPatientList'
      
        // children: [
        //   {
        //     name: "Add Patients",

        //     path: "/HospitalLayout/AddMasterPatient"
        //   },
        //   {
        //     name: "Completed List ",

        //     path: "/admin/overview"
        //   }
        // ]
      }
      const preAuthList = {
        name: "Pre Auth Initiation List",
        icon: "fa fa-users",
        children: [
          {
            name: "Pending",
            path: '/HospitalLayout/PreAuthListPending'
          },
          {
            name: "Approved",
            path: '/HospitalLayout/PreAuthListApproved'
          },
          {
            name: "Approval Required",
            path: '/HospitalLayout/PreAuthListApprovalRequired'
          },
          {
            name: "Rejected",
            path: '/HospitalLayout/PreAuthListRejected'
          }
        ]
        // path: '/HospitalLayout/PreAuthList'
      }
      const casesForDischarge = {
        name: "Cases for Discharge",
        icon: "fa fa-users",
        path: '/HospitalLayout/CasesForDischarge'
      }
      // const dailysis =  {
      //   name: "Dialysis",
      //   icon: "fa fa-plus",
      //   path: "/HospitalLayout/DialysisRegistration",
      //   children: [
      //     {
      //       name: "New Registration",

      //       path: "/HospitalLayout/DialysisRegistration"
      //     },
      //     {
      //       name: "Completed List ",

      //       path: "/HospitalLayout/DialysisCompletedList"
      //     },
      //         {
      //       name: "Master Patient List ",

      //       path: "/HospitalLayout/DialysisMasterPatientList"
      //     }
      //   ]
      // }
      // const settings = {
      //   name: "Settings",
      //   icon: "fa fa-cog",
      //   path: "/admin/overview"
      // }
      return [dashboard,patientRegistration,patientList,application,masterPatientList,coding,preAuthList,casesForDischarge]
    },
    getSideBar(){
      let previlage = []
      let links = this.getLinks()
      let cook = this.$cookies.get('kasp-pmjay')
      if(cook.userType == 3 || cook.userType == 4){
        previlage = [1,3]
        for(let key in previlage){
          this.HospitalMenus.push(links[previlage[key]])
        }
      }
      else if(cook.userType == 1){
        previlage = [0,1,3,4,6,7]
        for(let key in previlage){
          this.HospitalMenus.push(links[previlage[key]])
        }
        // this.HospitalMenus.push(dashboard,patientRegistration)  
      }
      else if(cook.userType == 2){
        
        previlage = this.subAdminPrevilages ? this.subAdminPrevilages.sort() : []
        // previlage = [0,2,1,3]
        console.log(previlage)
        for(let key in previlage){
          this.HospitalMenus.push(links[previlage[key]])
        }

      }
      else if(cook.userType == 5){
        previlage = [0,1,3,6,7]
        for(let key in previlage){
          this.HospitalMenus.push(links[previlage[key]])
        }
      }
      else if(cook.userType == 6){
        previlage = [5,6,7]
        for(let key in previlage){
          this.HospitalMenus.push(links[previlage[key]])
        }
      }
    },
    getPrevilages(){
      let cook = this.$cookies.get('kasp-pmjay')
      this.$http.post('privilege/privilege/user_privilege',{
        'id': cook.UserId
      })
      .then(response => {
        let res = response.body
        
        let selectRes = [0,3,6]
        if(res.status && res.hasrecords) {
          for (let key in res.records) {
            // let result = res.records[key].id
            let result = ''
            if(res.records[key].id == 3){
              result = 1
            }
            if(res.records[key].id == 4){
              result = 4
            }
            if(result){
              selectRes.push(result)
            }            
          }
          this.subAdminPrevilages = selectRes
          console.log(this.subAdminPrevilages)
        }
        this.getSideBar()      
      })
    }
  },
  created(){
    this.getPrevilages()
    
     
  }
};
</script>

<style>
.rio-layout .content {
  min-height: 100vh;
}
</style>
