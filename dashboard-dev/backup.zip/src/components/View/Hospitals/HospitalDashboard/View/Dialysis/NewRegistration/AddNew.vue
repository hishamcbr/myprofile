<template>
  <div>
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">
          {{ actionType == 'create' ? 'Add New' : 'Edit' }}
          <a
            @click.prevent="$emit('changeComponent','listing')"
            href
          >
            <i style="margin-top:-20px" class="fa fa-times pull-right"></i>
          </a>
        </h4>
      </div>
      <div class="card-body">
        <tabs value="Description">
          <tab-pane title="Basic Details" key="BasicDetails">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for>
                   Select Department
                    <span class="text-danger">*</span> :
                  </label>
                  <input
                    type="text"
                    class="form-control"
                    placeholder="Enter Hospital Name"
                    name="Hospital Name"
                  />
                  <!-- <small class="text-danger"></small> -->
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for>
                    Enter OP/MR No.
                    <span class="text-danger">*</span> :
                  </label>
                  <input
                    type="text"
                    class="form-control"
                    placeholder="Enter Hospital Name"
                    name="Hospital Name"
                  />
                  <!-- <small class="text-danger"></small> -->
                </div>
              </div>
              <div class="col-md-4">
               
              </div>
            </div>
            <button class="btn btn-primary">Next</button>
          </tab-pane>
          <tab-pane title="Doctors  Details">
            <div class="row">
              <div class="col-md-12">
                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Doctor Name</th>
                        <th>Registration No.</th>
                        <th>Qualification</th>
                        <th>Mobile No</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <input
                            type="text"
                            class="form-control"
                            placeholder="Enter Doctor Name"
                            name="Hospital Name"
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            class="form-control"
                            placeholder="Enter Doctor Name"
                            name="Hospital Name"
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            class="form-control"
                            placeholder="Enter Doctor Name"
                            name="Hospital Name"
                          />
                        </td>
                        <td>
                          <input
                            type="text"
                            class="form-control"
                            placeholder="Enter Doctor Name"
                            name="Hospital Name"
                          />
                        </td>
                        <td>
                          <button class="btn btn-outline-primary btn-sm">
                            <i class="fa fa-plus" aria-hidden="true"></i>
                          </button>
                          <button class="btn btn-outline-success btn-sm">
                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                          </button>
                             <button class="btn btn-outline-danger btn-sm">
                           <i class="fa fa-trash" aria-hidden="true"></i>
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
           
              </div>
            </div>
            
          </tab-pane>
        </tabs>
      </div>
    </div>
  </div>
</template>
<script>
import swal from "sweetalert2";
import { Tabs, TabPane } from "src/components/UIComponents";
export default {
  components: {
    Tabs,
    TabPane
  },
  props: ["data"],
  data() {
    return {
      actionType: "create",
      userName: "",
      mobileNumber: "",
      emailId: "",
      userType: "",
      password: "",
      previlage: [],
      userTypes: [
        { label: "Sub-admin", value: 2 },
        { label: "DEO", value: 3 },
        { label: "Hospital User", value: 4 }
      ],
      previlages: [],
      hospitals: [],
      Hospital: [],
      departments: [],
      departmentsSelected: []
    };
  },
  methods: {
    validate() {
      this.$validator.validateAll().then(isValid => {
        if (isValid) {
          if (this.userType == 4) {
            this.$validator.validateAll("departmentScope").then(isValid1 => {
              if (isValid1) {
                console.log("hii");
              }
            });
          } else {
            console.log("hii123");
          }
        }
      });
    },
    addDepartment() {
      let formData = {};
      formData.name = this.DepartmentName;
      formData.id = this.id;
      let documents = this.documents;
      var doc = new Array();
      let j = 0;
      documents.forEach(element => {
        doc[j] = {};
        if (element.label || element.fileType) {
          doc[j]["id"] = element.id ? element.id : "";
          doc[j]["label"] = element.label ? element.label : "";
          // doc[j]['fileType']=element.fileType ? element.fileType : ''
        }
        j++;
      });
      formData.Docs = JSON.stringify(doc);
      let url = "department/department/add_department";
      if (this.actionType == "update") {
        url = "department/department/edit_department";
      }
      this.$http.post(url, formData).then(response => {
        let res = response.body;
        if (res.status) {
          (this.DepartmentName = ""),
            (this.documents = [{ id: "", label: "" }]);
          this.$validator.reset();
          this.$emit("getData");
          swal({
            type: "success",
            title: res.message
          });
        } else {
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    selectUserType() {
      this.previlage = [];
      this.Hospital = "";
    },
    getPrevilages() {
      this.$http
        .post("privilege/privilege/list_privilege", {})
        .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
            for (let key in res.records) {
              let result = [];
              result["label"] = res.records[key].name;
              result["value"] = res.records[key].id;
              selectRes.push(result);
            }
            this.previlages = selectRes;
          }
        });
    },
    getHospitals() {
      this.$http.post("hospital/hospital/list_hospital", {}).then(response => {
        let res = response.body;

        let selectRes = [];
        if (res.status && res.hasrecords) {
          for (let key in res.records) {
            let result = [];
            result["label"] = res.records[key].name;
            result["value"] = res.records[key].id;
            selectRes.push(result);
          }
          this.hospitals = selectRes;
        }
      });
    },
    getDepartments() {
      this.$http
        .post("department/department/list_department", {})
        .then(response => {
          let res = response.body;

          let selectRes = [];
          if (res.status && res.hasrecords) {
            for (let key in res.records) {
              let result = [];
              result["label"] = res.records[key].name;
              result["value"] = res.records[key].id;
              selectRes.push(result);
            }
            this.departments = selectRes;
          }
        });
    }
  },
  created() {
    if (JSON.stringify(this.data) != "{}") {
    }
    this.getPrevilages();
    this.getHospitals();
    this.getDepartments();
  }
};
</script>
<style>

</style>

<style scoped>
* {
  transition: all 0.5s ease;
}
.card.form-card {
  overflow: hidden;
  transition: all 0.5s ease;
  /* max-height: 0px; */
  width: 50%;
}
.form-card.slide {
  transition: all 0.5s ease;
  /* max-height:100vh; */
}
.rio-select input {
  background-color: rgb(255, 255, 255) !important;
  color: black !important;
}
.rio-select:hover input {
  color: black !important ;
}
.nav-tabs-navigation {
  text-align: left !important;
}
</style>
