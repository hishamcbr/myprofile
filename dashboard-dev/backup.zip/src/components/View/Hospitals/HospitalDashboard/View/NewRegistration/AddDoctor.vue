<template>
    <div>
        <div class="row add-slide-header">
            <div class="col-md-12">
                <!-- <div class=""> -->
                    <b>Add Doctor</b>
                <!-- </div> -->
            </div>
        </div>
        <div class="row slide-content m0">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Doctor name</label>
                    <input v-model="doctor.name" v-validate="'required'" name="Doctor's Name" type="text" placeholder="Enter Doctor's Name" class="form-control">
                    <small class="text-danger">
                        {{errors.first("Doctor's Name")}}
                    </small>
                </div>
                <div class="form-group">
                    <label>Registration Number</label>
                    <input v-model="doctor.registrationNo" name="Registration Number" v-validate="'required'" type="text" placeholder="Enter Registration Number" class="form-control">
                    <small class="text-danger">
                        {{errors.first('Registration Number')}}
                    </small>
                </div>
                <div class="form-group">
                    <label>Mobile Number</label>
                    <input v-model="doctor.mobileNumber" name="Mobile Number" v-validate="'required'" type="text" placeholder="Enter Mobile Number" class="form-control">
                    <small class="text-danger">
                        {{errors.first('Mobile Number')}}
                    </small>
                </div>
                <div class="form-group">
                    <label>Qualification</label>
                    <input v-model="doctor.qualification" v-validate="'required'" name="Qualification" type="text" placeholder="Enter Qualification" class="form-control">
                    <small class="text-danger">
                        {{errors.first('Qualification')}}
                    </small>
                </div>
            </div>
            <div class="col-md-12">
                <button class="btn btn-fill btn-info pull-right btn-sm" @click.prevent="$emit('close')">Cancel</button>
                <button class="btn btn-success btn-fill pull-right btn-sm" @click.prevent="validateDoctor">Add</button>                    
            </div>
        </div>
        <!-- <div class="row add-slide-footer">
            <div class="col-md-12">                
                <button class="btn btn-success btn-fill btn-sm ss-button">Add</button>
                <button class="btn btn-fill btn-info btn-sm ss-button" @click.prevent="$emit('close')">Cancel</button>                                   
            </div>
        </div> -->
  </div>
</template>

<script>
import swal from 'sweetalert2'
export default {
    data(){
        return{
            doctor: {
                name: '',
                registrationNo: '',
                qualification: '',
                mobileNumber: ''
            }
        }
    },
    methods: {
        validateDoctor(){
            this.$validator.validateAll().then(isValid => {
                this.addDoctor()
            })
        },
        addDoctor(type){
        let cook= this.$cookies.get('kasp-pmjay')
        let formData = this.doctor
        let url = "doctor/doctor/add_doctor";
        formData.hospitalId = cook.hospitalId
        this.$http.post(url, formData).then(response => {
            let res = response.body;
            if (res.status) {
            this.doctor = {
                name: '',
                registrationNo: '',
                qualification: '',
                mobileNumber: ''
            }
            this.$validator.reset()
            swal({
                type: "success",
                title: res.message
            });
            this.$emit('close')
            } else {
            swal({
                type: "error",
                title: res.message
            });
            }
        });
        },
    }
    // props: ['pageData'],
}
</script>

<style>

</style>