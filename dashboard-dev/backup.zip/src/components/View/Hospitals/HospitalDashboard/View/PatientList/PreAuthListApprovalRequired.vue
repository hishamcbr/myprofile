<template>
  <div>
    <div v-show="sections.listing">
      <ttable @changeReset="changeReset" :reset="tableReset" @selected="selectedRows" v-loading="loading" :page="page" @updateData="getData($event)" id="out-table" :noDataText="'hii'">
        <template :slot="'titleTable'">
          <h5 class="card-title">{{this.$route.name}}</h5>
        </template>
        <div slot="extra">
          <button class="btn btn-success btn-sm pull-right" @click.prevent="showUploadModal">Upload</button>
          <button :disabled="page.total==0" class="btn btn-warning btn-sm pull-right" @click.prevent="downloadPending">Download</button>
        </div>
        <el-table-column class="table-select"
          slot="select"
          type="selection"
          width="55">
        </el-table-column>        
        <div slot="export" class="form-group">
          <label class="filter-label mb0">Export</label><br>
            <el-dropdown style="width:100%" placement="top-end" trigger="click" @command="exportToExcel">
                <el-button class="excel-button" type="primary" style="width:100%">
                    Excel<i class="el-icon-arrow-down el-icon--right"></i>
                </el-button>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item icon="el-icon-document-copy" :disabled="page.total <= 0" command="all">All</el-dropdown-item>
                    <el-dropdown-item icon="el-icon-document" :disabled="selected.length <= 0" command="selected">Selected</el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
        <div slot="date">
          <label class="filter-label mb0">Admission Date Filter</label>
          <el-date-picker style="width:100%"
                  v-model="dateFilter"
                  type="daterange"
                  range-separator="To"
                  start-placeholder="From"
                  end-placeholder="To" @change="dateChanged">
          </el-date-picker>
        </div>          
        <div slot="search" class="form-group search-container"> 
          <label class="filter-label mb0">Search</label><br>           
          <input @keyup.prevent="getData()" v-model="searchKey"  type="text" class="search-box form-control" placeholder="Search Here">
          <i class="search-icon fa fa-search text-primary"></i>
        </div>
        <div slot="more-filters">
          <div class="row" style="margin:0">
            <div class="col-md-3">
              <div class="form-group">
                <label class="filter-label mb0" for>Select Department</label>
                <el-select @change="getData()" style="width:100%" name="Departments" class="department-filter" clearable filterable placeholder="Select Department" v-model="departmentId">
                  <el-option
                  v-for="option in departments"
                  :value="option.value"
                  :label="option.label"
                  :key="option.label"
                  ></el-option>
                </el-select>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label class="filter-label mb0" for>Status</label>
                <el-select @change="getData()" style="width:100%" class="department-filter" clearable filterable placeholder="Select Status" v-model="departmentId">
                  <el-option
                  v-for="option in departments"
                  :value="option.value"
                  :label="option.label"
                  :key="option.label"
                  ></el-option>
                </el-select>
              </div>
            </div>
            <div class="col-md-6">
              <label class="filter-label mb0" for>Downloaded Filter</label><br>
              <button @click.prevent="downloaded = '',getData()" class="mt0 btn-input btn btn-outline-default btn-default " :class="downloaded == '' ? 'active' : ''">All</button>
              <button @click.prevent="downloaded = 1,getData()" class="mt0 btn-input btn btn-outline-warning btn-warning " :class="downloaded == 1 ? 'active' : ''">Not Downloaded</button>
              <button @click.prevent="downloaded = 2,getData()" class="mt0 btn-input btn btn-outline-danger btn-danger " :class="downloaded == 2 ? 'active' : ''">Downloaded</button>
              <button @click.prevent="downloaded = 3,getData()" class="mt0 btn-input btn btn-outline-info btn-info " :class="downloaded == 3 ? 'active' : ''">Re-Uploaded</button>
            </div>
          </div>          
        </div>       
        <el-table-column
          slot="actions"
          :min-width="240"
          fixed="right"
          label="Actions"
          id="action-column" >
          <template slot-scope="props">
            <!-- <button class="btn btn-danger btn-icon btn-sm" @click.prevent="handleDownload(props.$index, props.row)" title="Download Documents">  <i class="fa fa-download" aria-hidden="true"></i></button>
            <button class="btn btn-default btn-icon btn-sm" @click.prevent="handleEdit(props.$index, props.row)" title="Edit">  <i class="fa fa-pencil" aria-hidden="true"></i></button>
            <button class="btn btn-primary btn-icon btn-sm" @click.prevent="handleCaseId(props.$index, props.row)" title="Fill Case Id">  <i class="fa fa-file-text" aria-hidden="true"></i></button>
            <button class="btn btn-success btn-icon btn-sm" @click.prevent="handleView(props.$index, props.row)" title="View">  <i class="fa fa-eye" aria-hidden="true"></i></button>
            <button class="btn btn-warning btn-icon btn-sm" @click.prevent="handleUpload(props.$index, props.row)" title="Upload Documents">  <i class="fa fa-upload" aria-hidden="true"></i></button> -->
            <button class="btn btn-default btn-icon btn-sm" @click.prevent="handleQuery(props.$index, props.row)" title="Query">  <i class="fa fa-question" aria-hidden="true"></i></button>
            <button class="btn btn-success btn-icon btn-sm" @click.prevent="handleApprove(props.$index, props.row)" title="Approve">  <i class="fa fa-thumbs-up" aria-hidden="true"></i></button>
            <button class="btn btn-danger btn-icon btn-sm" @click.prevent="handleReject(props.$index, props.row)" title="Reject">  <i class="fa fa-thumbs-down" aria-hidden="true"></i></button>
            <button class="btn btn-info btn-icon btn-sm" @click.prevent="handleView(props.$index, props.row)" title="View">  <i class="fa fa-eye" aria-hidden="true"></i></button>
            <button v-if="isAdmin" class="btn btn-danger btn-icon btn-sm" @click.prevent="handleDelete(props.$index, props.row)" title="Delete Patient">  <i class="fa fa-trash" aria-hidden="true"></i></button>
          </template>
        </el-table-column>
      </ttable>
    </div>
    <upload-document v-if="sections.upload" @changeComponent= "changeComponent" :data="uploadData"></upload-document>
    <view-patient @uploadFromView="showUpload" :downloadButton="true" :uploadButton="true"  v-if="sections.view" @changeComponent= "changeComponent" :imageClose="true" :data="uploadData"></view-patient>
    <edit-patient  v-if="sections.edit" @changeComponent= "changeComponent" :data="editData"></edit-patient>
    <el-dialog :close-on-press-escape="true" :show-close="false" :before-close="preventClose" title="Fill Case ID" width="35%" :visible.sync="caseModal" style="">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label for="">Case ID</label>
            <input v-model="caseId" class="form-control" type="text" name="Case ID" data-vv-scope="caseIdScope" placeholder="Enter Case ID" v-validate="'required'">
            <small class="text-danger">
              {{ errors.first('caseIdScope.Case ID') }}  
            </small> 
          </div>
        </div>
        
        <input type="hidden" v-model="hiddenId">
        <div class="col-md-12">
            <span slot="footer" class="dialog-footer">
                <button class="btn btn-sm btn-fill btn-success" @click.prevent="validateCaseId()">Update</button>
                <button class="btn btn-sm btn-fill btn-primary" @click.prevent="caseModal=false">Cancel</button>
            </span>
        </div>
      </div>
    </el-dialog>
    <el-dialog :close-on-press-escape="true" :show-close="false" :before-close="preventClose" title="Edit Patient" width="75%" :visible.sync="editModal" style="">
      <div class="row">
        <div class="col-md-4">
          <div class="form-group">
            <label for>IP No:</label>
            <input v-model="patientData.ipNumber" data-vv-scope="patientScope" v-validate="'required'" placeholder="IP Number" name="IP Number" type="text" class="form-control" />
            <small class="text-danger">
              {{ errors.first('patientScope.IP Number') }}
            </small>
          </div>
        </div>        
        <div class="col-md-4" v-if="patientData.departmentId != 50">
          <!-- <div class="form-group"> -->
            <label for>Date of Admission:</label>
            <el-date-picker
              style="width:100%"
              v-model="patientData.doa"
              type="date"
              placeholder="Pick a day"
              format="dd-MM-yyyy"
              value-format="yyyy-MM-dd"
              name="Date of admission" v-validate="'required'" data-vv-scope="patientScope">
            </el-date-picker>
            <small class="text-danger">
              {{ errors.first('patientScope.Date of admission') }}
            </small>
          <!-- </div> -->
        </div>
        <div class="col-md-4" v-if="patientData.departmentId != 50">
          <!-- <div class="form-group"> -->
            <label for>Select Doctor:</label>
            <el-select style="width:100%" v-model="patientData.doctorId"  name="Select Doctor" v-validate="'required'" data-vv-scope="patientScope"  clearable filterable placeholder="Select Doctor">
              <el-option
              v-for="option in doctors"
              class="select-primary"
              :value="option.value"
              :label="option.label"
              :key="option.label"
              ></el-option>
            </el-select>
            <small class="text-danger">
              {{ errors.first('patientScope.Select Doctor') }}
            </small>
          <!-- </div> -->
        </div>
        <div class="col-md-12" v-if="patientData.departmentId != 50">
          <div class="form-group">
            <label for>Diagnosis:</label>
            <input v-model="patientData.diagnosis" placeholder="Diagnosis"  type="text" class="form-control" name="Diagnosis" v-validate="'required'" data-vv-scope="patientScope"/>
            <small class="text-danger">
              {{ errors.first('patientScope.Diagnosis') }}
            </small>
          </div>
        </div>
        <div class="col-md-4" v-if="patientData.departmentId == 50">
          <label for>Select Shift:</label>
            <el-select style="width:100%" v-model="patientData.shift"  name="Shift" v-validate="'required'" data-vv-scope="patientScope"  clearable filterable placeholder="Select Shift">
              <el-option
              v-for="option in shifts"
              class="select-primary"
              :value="option.value"
              :label="option.label"
              :key="option.label"
              ></el-option>
            </el-select>
            <small class="text-danger">
              {{ errors.first('patientScope.Shift') }}
            </small>
        </div> 
        <div class="col-md-12">
            <span slot="footer" class="dialog-footer">
                <button class="btn btn-sm btn-fill btn-success" @click.prevent="validatePatient()">Update</button>
                <button class="btn btn-sm btn-fill btn-primary" @click.prevent="editModal=false">Cancel</button>
            </span>
        </div>
      </div>
    </el-dialog>
    <el-dialog :show-close="false" :before-close="preventClose"  title="Upload Excel" width="35%" :visible.sync="uploadModal" style="">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label for="">Select File</label>
            <input ref="document" @change="selectAttachment" name="File" type="file" class="form-control" data-vv-scope="uploadScope"  v-validate="'required'">
            <small class="text-danger">
              {{ errors.first('uploadScope.File') }}  
            </small> 
          </div>
        </div>
        <div class="col-md-12">
            <span slot="footer" class="dialog-footer">
                <button v-if="!loadingButton" class="btn btn-sm btn-fill btn-success" @click.prevent="validateUpload()">Upload</button>
                <el-button class="btn-sm" v-if="loadingButton" type="primary" :loading="true">Uploading...</el-button>
                <button :disabled="loadingButton" class="btn btn-sm btn-fill btn-danger" @click.prevent="uploadModal=false">Cancel</button>
            </span>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import FileSaver from 'file-saver'
import XLSX from 'xlsx'
import UploadDocument from './UploadDocument.vue'
import ViewPatient from './ViewPatientNew.vue'
import EditPatient from 'src/components/View/Hospitals/HospitalDashboard/View/NewRegistration/EditRegistration.vue'
import ttable from "../../../../ServerTable1.vue";
import moment from 'moment'
import swal from 'sweetalert2'
export default {
  components: {
    ttable,
    UploadDocument,
    ViewPatient,
    EditPatient
  },
  data() {
    return {
      attachment: '',
      loadingButton: false,
      uploadModal: false,
      departmentId: '',
      departments: [],
      downloaded: '',
      tableReset: 'no',
      selected: [],
      isAdmin: false,
      editModal: false,
      patientData: {
        PatientMasterId: '',
        id: '',
        cardId: '',
        ipNumber: '',
        name: '',
        mobileNumber: '',
        gender: '',
        doa: '',
        departmentId: '',
        doctorId: '',
        diagnosis: '',
        patientType: 2,
        registerNumber: '',
        shift: ''
      },
      doctors: [],
      searchKey: '',
      fromDate: '',
      toDate: '',
      dateFilter: '',
      hiddenId: '',
      caseId: '',
      caseModal: false,
      loading: true,
      showAdd: false,
      departmentData: {},
      uploadData: {},
      editData: {},
      page: {
        TotalPerPage: 50,
        total: 0,
        tableColumns: [],
        tableData: [],
        propsToSearch: [],
        selection: false,
        entries: true
      },
      columns: [
        {
          prop: "name",
          label: "Patient Name",
          minWidth: 200,
          sortable: true
        },
        {
          prop: "opNumber",
          label: "OP No.",
          minWidth: 120,
          sortable: true
        },
        {
          prop: "ipNumber",
          label: "IP No",
          minWidth: 120,
          sortable: true
        },
        {
          prop: "cardId",
          label: "Card ID",
          minWidth: 150,
          sortable: true
        },
        {
          prop: "date",
          label: "DOA",
          minWidth: 120,
          sortable: true
        },
      ],
      shifts: [
        { label: '1', value: 1},
        { label: '2', value: 2},
        { label: '3', value: 3},
        { label: '4', value: 4}
      ],
      sections: {
        listing: true,
        upload: false,
        view: false,
        edit: false
      },
    };
  },
  methods: {
    showUploadModal(){
      this.loadingButton = false
      this.uploadModal = true 
      if(this.$refs.document){
        this.$refs.document.value = ''
      }
    },
    validateUpload(){
      this.$validator.validateAll('uploadScope').then(isValid => {
        if(isValid){
          this.loadingButton = true
          this.uploadDocument()
        }
      })
    },
    uploadDocument(){
      let form_data = new FormData()
      form_data.append('cases',this.attachment)
      this.$http.post('preauth/preauth/save_caseid_from_excel', form_data, {
        headers: {
						'Content-Type': 'multipart/form-data'
					}
        }).then(response => {
        let res = response.body;
        if (res.status) {
          this.$refs.document.value = ''
          // document.getElementById('upload').value='';
          this.loadingButton = false
          swal({
            type: "success",
            title: res.message
          });
          this.getData()
          this.uploadModal = false 
          // this.$router.push('/HospitalLayout/PatientPendingList')
        } else {
          // this.$refs.document.value = ''
          // document.getElementById('upload').value='';
          this.loadingButton = false
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    selectAttachment:function($event){
        this.attachment =$event.target.files[0]    
    },
    downloadPending(){
      let cook = this.$cookies.get('kasp-pmjay')
      this.$http.post("preauth/preauth/pending_list_excel", {
        hospitalId: cook.hospitalId
      })
      .then(response => {
        let res = response.body;
        this.loading = false
        if(res.status){
          window.location.href = res.records.link
        }
        else{
          swal({
            type: "error",
            title: res.message
          });
        }
        
      });
    },
    getDepartments() {
      this.$http.post('department/department/list_department',{})
      .then(response => {
        let res = response.body
        let selectRes = []
        if(res.status && res.hasrecords) {
          for (let key in res.records) {
            let result = []
            result['label'] = res.records[key].name
            result['value'] = res.records[key].id
            selectRes.push(result)
          }
          this.departments = selectRes
        }
      })
    },
    changeReset(){
      this.tableReset = 'no'
    },
    selectedRows(rows){
      this.selected = rows
    },
    exportToExcel(value){       
        let cook= this.$cookies.get('kasp-pmjay')
        this.loading = true
        let id=[]
        if(value == 'all'){
          id = []
        }
        else{
          id = []
          for(let key in this.selected){
            id.push(this.selected[key].id)
          }
        }
        this.$http.post("patient/patient/export_reg_patient_excel", {
            userId: cook.UserId,
            hospitalId: cook.hospitalId,
            id: id,
            status: 2,
            fromDate: this.fromDate,
            toDate: this.toDate,
            searchKey: this.searchKey
          })
          .then(response => {
            let res = response.body;
            this.loading = false
            if(res.status){
              this.tableReset = 'reset'
              window.location.href = res.records
            }
            else{
              swal({
                type: "error",
                title: res.message
              });
            }
            
          });
    },
    handleDelete(index,row){
      let id = []
      id.push(row.id)
      swal({
        type: 'question',
        title: '',
        text: 'Are you sure to delete patient?',
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
        })
      .then(result => {
        if (result) {
          this.$http.post('patient/patient/delete_patient',{
            'id': id
          })
          .then(response => {
            let res = response.body
            swal({
              type: res.status ? 'success' : 'error',
              title: res.message
            })
            if (res.status) {
              this.getData()
            }
          })
        }
      })
    },
    handleDownload(index, row){
      this.loading = true
      this.$http.post("patient/patient/zipping_patient", {
          id: row.id
        })
        .then(response => {
          let res = response.body;          
          this.loading = false
          if(res.status){
            window.location.href = res.records
            this.getData()
          }
          else{
            swal({
              type: "error",
              title: res.message
            });
          }          
        });
    },
    validatePatient(){
      this.$validator.validateAll('patientScope').then(isValid => {
        if(isValid){
          this.addPatient()
        }
      })
    },
    addPatient() {
      let formData = this.patientData
      let cook = this.$cookies.get('kasp-pmjay')
      formData.hospitalId = cook.hospitalId
      // if(this.patientData.departmentId == 50){
      //   formData.doctorId = 2
      // }
      let url = "patient/patient/edit_patient";
      // if (this.actionType == "update") {
      //   formData.id = this.patientData.id
      //   url = "hospital/hospital/edit_hospital";
      // }
      this.$http.post(url, formData).then(response => {
        let res = response.body;
        if (res.status) {
          
          this.editModal = false
          // this.patientData = {
          //   PatientMasterId: '',
          //   id: '',
          //   cardId: '',
          //   opNumber: '',
          //   ipNumber: '',
          //   name: '',
          //   mobileNumber: '',
          //   gender: '',
          //   doa: '',
          //   departmentId: '',
          //   doctorId: '',
          //   diagnosis: '',
          //   patientType: 2,
          //   registerNumber: '',
          //   shift: ''
          // }
          this.$validator.reset()
          swal({
            type: "success",
            title: res.message
          });
        } else {
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    handleEdit(index, row){
      this.editData = row
      this.showComponent('edit')
    },
    handleEditOld(index, row){
      this.patientData.id= row.id
      this.patientData.PatientMasterId = row.permanent_patient_relation.id
      this.patientData.ipNumber = row.ipNumber
      this.patientData.doa = row.doa ? moment(row.doa).format('YYYY-MM-DD') : ''
      this.patientData.departmentId = row.departmentId
      this.patientData.doctorId = row.doctorId ? row.doctorId : ''
      this.patientData.diagnosis = row.diagnosis ? row.diagnosis : ''
      this.patientData.patientType = row.patientType
      this.patientData.cardId = row.cardId
      this.patientData.opNumber = row.opNumber
      this.patientData.shift = row.shift
      this.$validator.reset()
      this.editModal = true
    },
    preventClose(){

    },
    handleExport() {
      let table = document.querySelector("#out-table").cloneNode(true)
      let selectheader = table.querySelector(".el-table-column--selection")
      selectheader.parentNode.removeChild(selectheader)
      let tbody = table.querySelector(".el-table__body")
      let select = tbody.querySelectorAll('.el-table-column--selection')

      let action = table.querySelector(".is-hidden")
      action.parentNode.removeChild(action)
      for (let i = 0; i < select.length; i++){
        select[i].parentNode.removeChild(select[i])
      }
      let fixed = table.querySelector(".el-table__fixed-right")
      fixed.parentNode.removeChild(fixed);
      var wb = XLSX.utils.table_to_book(table);
      var wbout = XLSX.write(wb, {
          bookType: "xlsx",
          bookSST: true,
          type: "array"
      });
      try {
          FileSaver.saveAs(
          new Blob([wbout], { type: "application/octet-stream" }),
          "pending-patient-list-"+moment().format('DD-MM-YYYY')+".xlsx"
          );
      } catch (e) {
          if (typeof console !== "undefined") console.log(e, wbout);
      }
      return wbout;
    },
    dateChanged(){
      this.fromDate = this.dateFilter ? moment(this.dateFilter[0]).format('YYYY-MM-DD') : ''
      this.toDate = this.dateFilter ? moment(this.dateFilter[1]).format('YYYY-MM-DD') : ''
      this.getData()
    },
    validateCaseId(){
      this.$validator.validateAll('caseIdScope').then(isValid => {
        if(isValid){
          this.submitCaseId()
        }
      })
    },
    submitCaseId(){
      let formData = {}
      formData.id = this.hiddenId
      formData.caseId = this.caseId
      // let cook= this.$cookies.get('kasp-pmjay')
      // formData.requestedBy = cook.UserId
      let url = 'preauth/preauth/update_case_id'
      this.$http.post(url, formData)
      .then(response => {
        let res = response.body
        if(res.status) {
          this.hiddenId = ''
          this.caseId = ''
          this.$validator.reset()
          this.caseModal = false
          
          swal({
            type: 'success',
            title: res.message
          })
          this.getData()
        }
        else{
          swal({
            type: 'error',
            title: res.message
          })
        }
      })
    },
    handleCaseId(index, row){
      this.hiddenId = row.id
      this.caseId = ''
      this.caseModal = true
    },
    handleUpload(index, row){
      this.uploadData = row
      this.showComponent('upload')
    },
    showUpload(row){
      this.uploadData = row
      this.showComponent('upload')
    },
    handleView(index, row){
      this.uploadData = row
      this.showComponent('view')
    },
    changeComponent(value){
      this.showComponent(value)
    },
    showComponent(value) {
      this.sections = {
        listing: false,
        upload: false,
        view: false,
        edit: false
      };
      for (var p in this.sections) {
        if (p == value) {
          this.sections[p] = true;
        }
      }
    },
    getDoctors() {
      let cook = this.$cookies.get('kasp-pmjay')
      if(cook.hospitalId){
        this.$http.post("doctor/doctor/list_doctor", 
        { 
          hospitalId: cook.hospitalId,
          sortOrder: 'DESC',
          deleteFlag: 1 
        })
        .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
            for (let key in res.records) {
              let result = [];
              result["value"] = res.records[key].id;
              result["label"] = res.records[key].name;
              selectRes.push(result);
            }
            this.doctors = selectRes;
          }
        });
      }
    },
    getData(event) {
      this.loading = true
      this.showAdd = false;
      let cook = this.$cookies.get('kasp-pmjay')
      this.$http.post("patient/patient/list_reg_patient", {
        downloaded: this.downloaded,
        departmentId: this.departmentId,
        status: [8,9],
        treatmentStatus: [2],
        FromDate: this.fromDate,
        ToDate: this.toDate,
        searchKey: this.searchKey,
        hospitalId: cook.hospitalId,
        pagination: "TRUE",
        currentPage: event ? event.CurrentPage : 1,
        totalPerPage: this.page.TotalPerPage,
        sortOrder: "DESC",
        MoreDetails: 'TRUE',
        PermenentDetails: 'TRUE',
        DiagnosisDetails: 'TRUE'
      })
      .then(response => {
        let res = response.body;
        this.page.tableColumns = this.columns;
        if (res.status && res.hasrecords) {
          for(let key in res.records.data){
            res.records.data[key].date = moment(res.records.data[key].doa).format('DD-MM-YYYY')
          }
          this.page.total = res.records.total;
          this.page.tableData = res.records.data;
        }
        else{
          this.page.total = 0;
          this.page.tableData = [];
        }
        this.loading = false
      });
    }
  },
  created(){
    this.getDepartments()
    this.getDoctors()
    let cook = this.$cookies.get('kasp-pmjay')
    if(cook.userType == 1){
      this.isAdmin = true
    }
  }
};
</script>

<style>
.el-range-separator{
  width: 10% !important;
}
</style>
<style scoped>
.form-group input[type="file"]{
  opacity: 1;
  position: unset !important;
}
</style>
