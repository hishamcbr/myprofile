<template>
  <div class="card p-3">
    <div class="card-header">
      <h4 class="card-title">New Registration <el-tag class="pull-right" :type="patientExist ? 'warning': 'success'">{{patientExist ? 'Existing Patient' : 'New Patient'}}</el-tag></h4>
    </div>
      <div class="card-body">
        <vue-tabs class="card-content" v-model="tabName" @tab-change="handleTabChange">
          <v-tab title="Patient Details">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for>OP/MR No:</label>
                  <input @focusout.prevent="getDetailsFromOp()" v-model="patientData.opNumber" data-vv-scope="patientScope" v-validate="'required'" placeholder="OP/MR Number" name="OP/MR Number" type="text" class="form-control" />
                  <small class="text-danger">
                    {{ errors.first('patientScope.OP/MR Number') }}
                  </small>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for>Card ID:</label>
                  <input :disabled="disabled.cardId" v-model="patientData.cardId" data-vv-scope="patientScope" v-validate="'required'" type="text" name="Card ID" placeholder="Card ID" class="form-control" />
                  <small class="text-danger">
                    {{ errors.first('patientScope.Card ID') }}
                  </small>
                </div>
              </div>              
              <div class="col-md-4">
                <div class="form-group">
                  <label for>IP No:</label>
                  <input v-model="patientData.ipNumber" data-vv-scope="patientScope" v-validate="'required'" placeholder="IP Number" name="IP Number" type="text" class="form-control" />
                  <small class="text-danger">
                    {{ errors.first('patientScope.IP Number') }}
                  </small>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for>Patient Name:</label>
                  <input :disabled="disabled.name" v-model="patientData.name" data-vv-scope="patientScope" v-validate="'required'" placeholder="Patient Name" name="Patient Name" type="text" class="form-control" />
                  <small class="text-danger">
                    {{ errors.first('patientScope.Patient Name') }}
                  </small>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for>Mobile Number:</label>
                  <input :disabled="disabled.mobile" v-model="patientData.mobileNumber" data-vv-scope="patientScope" v-validate="'required'" placeholder="Mobile Number" name="Mobile Number" type="text" class="form-control" />
                  <small class="text-danger">
                    {{ errors.first('patientScope.Mobile Number') }}
                  </small>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for>Gender:</label><br>
                  <el-radio-group :disabled="disabled.gender" style="width:100%" v-model="patientData.gender">
                    <el-radio label="Male">Male</el-radio>
                    <el-radio label="Female">Female</el-radio>
                  </el-radio-group>
                  <!-- <p-radio inline  v-model="patientData.gender" label="1">Male</p-radio>
                  <p-radio inline v-model="patientData.gender" label="2">Female</p-radio> -->
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for>Age:</label>
                  <input :disabled="disabled.age" v-validate="'numeric'" v-model="patientData.age" data-vv-scope="patientScope"  placeholder="Age" name="Age" type="text" class="form-control" />
                  <small class="text-danger">
                    {{ errors.first('patientScope.Age') }}
                  </small>
                </div>
              </div>              
              <div class="col-md-4">
                <!-- <div class="form-group"> -->
                  <label for>Department:</label>
                  <el-select style="width:100%" v-model="patientData.departmentId"  name="Department" v-validate="'required'" data-vv-scope="patientScope"  clearable filterable placeholder="Select Department">
                    <el-option
                    v-for="option in departments"
                    class="select-primary"
                    :value="option.value"
                    :label="option.label"
                    :key="option.label"
                    ></el-option>
                  </el-select>
                  <small class="text-danger">
                    {{ errors.first('patientScope.Department') }}
                  </small>
                <!-- </div> -->
              </div>
              <div class="col-md-4" v-if="patientData.departmentId != 50">
                <!-- <div class="form-group"> -->
                  <label for>Date of Admission:</label>
                  <el-date-picker
                    style="width:100%"
                    v-model="patientData.doa"
                    type="date"
                    placeholder="Pick a day"
                    format="dd-MM-yyyy"
                    value-format="yyyy-MM-dd"
                    name="Date of admission" v-validate="'required'" data-vv-scope="patientScope">
                  </el-date-picker>
                  <small class="text-danger">
                    {{ errors.first('patientScope.Date of admission') }}
                  </small>
                <!-- </div> -->
              </div>
              <div class="col-md-4" v-if="patientData.departmentId != 50">
                <!-- <div class="form-group"> -->
                  <label for>Select Doctor:</label>
                  <el-select style="width:100%" v-model="patientData.doctorId"  name="Select Doctor" v-validate="'required'" data-vv-scope="patientScope"  clearable filterable placeholder="Select Doctor">
                    <el-option
                    v-for="option in doctors"
                    class="select-primary"
                    :value="option.value"
                    :label="option.label"
                    :key="option.label"
                    ></el-option>
                  </el-select>
                  <small class="text-danger">
                    {{ errors.first('patientScope.Select Doctor') }}
                  </small>
                <!-- </div> -->
              </div>
              <div class="col-md-12" v-if="patientData.departmentId != 50">
                <div class="form-group">
                  <label for>Diagnosis:</label>
                  <input v-model="patientData.diagnosis" placeholder="Diagnosis"  type="text" class="form-control" name="Diagnosis" v-validate="'required'" data-vv-scope="patientScope"/>
                  <small class="text-danger">
                    {{ errors.first('patientScope.Diagnosis') }}
                  </small>
                </div>
              </div>
              <div class="col-md-4" v-if="patientData.departmentId == 50">
                <label for>Select Shift:</label>
                  <el-select style="width:100%" v-model="patientData.shift"  name="Shift" v-validate="'required'" data-vv-scope="patientScope"  clearable filterable placeholder="Select Shift">
                    <el-option
                    v-for="option in shifts"
                    class="select-primary"
                    :value="option.value"
                    :label="option.label"
                    :key="option.label"
                    ></el-option>
                  </el-select>
                  <small class="text-danger">
                    {{ errors.first('patientScope.Shift') }}
                  </small>
              </div>                
            </div>
            <!-- <button class="btn btn-primary">Request for Register No.</button> -->
            <button class="btn btn-primary" @click.prevent="tabName = 'Upload Documents'">Next</button>
          </v-tab>
          <v-tab title="Upload Documents" style="width:100%">
            <div v-if="!registerButton">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for>Upload Photo</label>
                    <input type="file" v-validate="'required'" data-vv-scope="uploadScope"  class="form-control" name="Pre Admission Photo" @change="selectAttachment">
                    <small class="text-danger">
                      {{ errors.first('uploadScope.Pre Admission Photo') }}
                    </small>
                  </div>
                </div>
                <div class="col-md-6"></div>
                <br><br>
                <div class="clearfix"></div>
                <div class="col-md-4">
                  <el-card style="margin-top:10px" :body-style="{ padding: '0px'}" v-if="imageSelected">
                    <img width="100%" :src="imageUrl" alt="">
                  </el-card>
                </div>              
              </div>
              <button v-if="!loadingButton" class="btn btn-primary" @click.prevent="validateRequest">Request for Register Number</button>
              <el-button v-else type="primary" :loading="true">Requesting</el-button>
            </div>
            <div v-else>
              <button  class="btn btn-primary" @click.prevent="submitRequest">Request for Register Number</button>
            </div>
          </v-tab>
        </vue-tabs>
    </div>
  </div>
</template>

<script>
import moment from 'moment'
import swal from 'sweetalert2'
export default {
  data(){
    return{
      actionType: 'create',
      extension: '',
      loadingButton: false,
      imageSelected: false,
      imageUrl: '',
      tabName: '',
      shifts: [
        { label: '1', value: 1},
        { label: '2', value: 2},
        { label: '3', value: 3},
        { label: '4', value: 4}
      ],
      patientData: {
        PatientMasterId: '',
        id: '',
        cardId: '',
        opNumber: '',
        ipNumber: '',
        name: '',
        mobileNumber: '',
        gender: '',
        age: '',
        doa: moment().format('YYYY-MM-DD'),
        departmentId: '',
        doctorId: '',
        diagnosis: '',
        patientType: 2,
        registerNumber: '',
        shift: ''
      },
      uploadData: {
        labelId: '',
        registrationId: ''
      },
      disabled: {
        name: false,
        mobile: false,
        cardId: false,
        gender: false,
        age: false
      },
      attachment: '',
      departments: [],
      doctors: [],
      registerButton: false,
      patientExist: false 
    }
  },
  methods: {
    submitRequest(){
      let formData = {}
      formData.id = this.patientData.id
      this.$http.post('patient/patient/request_for_registration', formData).then(response => {
        let res = response.body;
        if (res.status) {
          this.loadingButton = false
          // this.registerButton = false
          swal({
            type: "success",
            title: res.message
          });
          this.$router.push('/HospitalLayout/PatientPendingList')
        } else {
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    validateRequest(){
      this.$validator.validateAll('uploadScope').then(isValid => {
        if(isValid){
          this.loadingButton = true
          this.uploadImage()
        }
      })
    },
    uploadImage(){
      let formData = this.uploadData
      formData.cardId = this.patientData.cardId
      formData.departmentId = this.patientData.departmentId
      formData.file = this.imageUrl
      formData.ext = this.extension
      // form_data.append('cardId',this.patientData.cardId)
      // form_data.append('departmentId',this.patientData.departmentId)
      // form_data.append('file',this.imageUrl)
      // form_data.append('labelId',this.uploadData.labelId)
      // form_data.append('registrationId',this.uploadData.registrationId)
      this.$http.post('patient/patient/cloud_upload', formData).then(response => {
        let res = response.body;
        if (res.status) {          
          this.submitRequest()
          // this.registerButton = true
          // swal({
          //   type: "success",
          //   title: res.message
          // });
          // this.$router.push('/HospitalLayout/PatientPendingList')
        } else {
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    getDetailsFromOp() {
      let cook = this.$cookies.get('kasp-pmjay')
      if(this.patientData.opNumber){
        this.$http.post("patient/patient/list_permanent_patient", 
        { 
          opNumber: this.patientData.opNumber,
          hospitalId: cook.hospitalId
        })
        .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
            this.patientExist = true
            this.disabled.name = res.records[0].name ? true : false
            this.patientData.name = res.records[0].name
            this.disabled.mobile = res.records[0].mobileNumber ? true : false
            this.patientData.mobileNumber = res.records[0].mobileNumber
            this.disabled.gender = res.records[0].gender ? true : false
            this.patientData.gender = res.records[0].gender
            this.disabled.age = res.records[0].age ? true : false
            this.patientData.age = res.records[0].age
            this.disabled.cardId = res.records[0].cardId ? true : false
            this.patientData.cardId = res.records[0].cardId
          }
          else{
            this.patientExist = false
            this.disabled = {
              name: false,
              mobile: false,
              cardId: false,
              gender: false,
              age: false
            }
            this.patientData.name = ''
            this.patientData.mobileNumber = ''
            this.patientData.gender= ''
            this.patientData.age= ''
            this.patientData.cardId= ''
            this.$validator.reset() 
          }
        });  
      }
      else{
        this.patientExist = false
        this.disabled = {
              name: false,
              mobile: false,
              cardId: false,
              gender: false,
              age: false
            }
            this.patientData.name = ''
            this.patientData.mobileNumber = ''
            this.patientData.gender= ''
            this.patientData.age= ''
            this.patientData.cardId= ''
            this.$validator.reset() 
      }
    },
    selectAttachment:function($event){
        this.attachment =$event.target.files[0]
        const fr = new FileReader ()
        fr.readAsDataURL($event.target.files[0])
				fr.addEventListener('load', () => {
          this.imageSelected = true
          this.imageUrl = fr.result             
        })
        this.extension = this.attachment.name.split('.').pop()      
    },
    handleTabChange(tabIndex, newTab, oldTab){      
      if(tabIndex == 1 && oldTab.title == 'Patient Details'){
        this.validatePatient()
      }

    },
    validatePatient(){
      this.$validator.validateAll('patientScope').then(isValid => {
        if(isValid){
          this.addPatient()
        }
        else{
          this.tabName = 'Patient Details'
        }
      })
    },
    addPatient() {
      let formData = this.patientData
      let cook = this.$cookies.get('kasp-pmjay')
      formData.hospitalId = cook.hospitalId
      // if(this.patientData.departmentId == 50){
      //   formData.doctorId = 2
      // }
      let url = "patient/patient/add_patient";
      // if (this.actionType == "update") {
      //   formData.id = this.patientData.id
      //   url = "hospital/hospital/edit_hospital";
      // }
      this.$http.post(url, formData).then(response => {
        let res = response.body;
        if (res.status) {
          this.patientData.id = res.records.RegistrationId
          this.uploadData.labelId = res.records.labelId
          this.uploadData.registrationId = res.records.RegistrationId
          this.patientData.PatientMasterId = res.records.PatientMasterId
          this.actionType = 'update'
          this.tabName = 'Upload Documents'
        } else {
          this.tabName = 'Patient Details'
          swal({
            type: "error",
            title: res.message
          });
        }
      });
    },
    getDepartments() {
      let cook = this.$cookies.get('kasp-pmjay')
      this.$http.post('department/department/listDepartmentByUser',
      {
        'userId': cook.UserId,
        'userType': cook.userType
      })
      .then(response => {
        let res = response.body
        let selectRes = []
        if(res.status && res.hasrecords) {
          for (let key in res.records) {
            let result = []
            result['label'] = res.records[key].name
            result['value'] = res.records[key].id
            selectRes.push(result)
          }
          this.departments = selectRes
        }
      })
    },
    getDoctors() {
      let cook = this.$cookies.get('kasp-pmjay')
      if(cook.hospitalId){
        this.$http.post("doctor/doctor/list_doctor", 
        { 
          hospitalId: cook.hospitalId,
          sortOrder: 'DESC',
          deleteFlag: 1 
        })
        .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
            for (let key in res.records) {
              let result = [];
              result["value"] = res.records[key].id;
              result["label"] = res.records[key].name;
              selectRes.push(result);
            }
            this.doctors = selectRes;
          }
        });
      }
    },
  },
  created(){
    this.getDepartments()
    this.getDoctors()
  }
};
</script>

<style scoped>
.form-group input[type="file"]{
  opacity: 1;
  position: unset !important;
}
</style>
