<template>
  <div>
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">QR List <a @click.prevent="$emit('changeComponent','listing')" href=""><i style="margin-top:-20px" class="fa fa-times pull-right"></i></a></h4>
        <button @click.prevent="printList()" class="pull-right btn btn-sm btn-primary">Print</button>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="table-responsive" style="padding: 0 10px"> 
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th style="width:5%">#</th>
                  <th style="width:40%">Name</th>
                  <th style="width:30">OP/MR Number</th>
                  <th style="width:25%">QR Code</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(patient, index) in data" :key="patient.id">
                  <td style="text-align:center">{{index+1}}</td>
                  <td>{{patient.name}}</td>
                  <td>{{patient.opNumber}}</td>
                  <td style="text-align:center"><img width="40%" :src="'http://pmjay.sevensigma.in/api/v1/qr/'+patient.opNumber+'.png'"></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import swal from 'sweetalert2'
export default {
  props: ['data'],
  data() {
    return {
      
      
    };
  },
  methods: {
    printList(){
      window.print()
    },
    validate(){
      this.$validator.validateAll().then(isValid => {
        if(isValid){
          this.addPatient()
        }
      })
    },
    
  },
  created() {
    if(JSON.stringify(this.data) != '{}'){
      console.log(this.data) 
    }
  }
};
</script>
<style scoped>

*{
  transition: all .5s ease;
}
.card.form-card{
  overflow: hidden;
  transition: all .5s ease;
  /* max-height: 0px; */
  width:50%;
}
.form-card.slide{
  transition: all .5s ease;
  /* max-height:100vh; */

}
.rio-select input{
  background-color: rgb(255, 255, 255) !important;
  color: black !important;
}
.rio-select:hover input{
  color: black !important ;
}
</style>
