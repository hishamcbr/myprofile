<template>
  <div>
    <div class="row">
      <div class="col-md-12">
        <el-tag effect="dark" class="success pull-right">
          <digital-clock :blink="true" :displaySeconds="true" :twelveHour="true" />
        </el-tag>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <h3>Today's Registration</h3>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6">
        <stats-card type="warning"
                    icon="fa fa-users"
                    small-title="Total"
                    :title="today.count">
          <!-- <div class="stats" slot="footer">
            <a href="" style="text-decoration: none"><i class="nc-icon nc-refresh-69"></i>
            Refresh</a>
          </div> -->
        </stats-card>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6">
        <stats-card type="danger"
                    icon="fa fa-hourglass-start"
                    small-title="Pending"
                    :title="today.pending">
          <!-- <div class="stats" slot="footer">
            <a href="" style="text-decoration: none"><i class="nc-icon nc-refresh-69"></i>
            Refresh</a>
          </div> -->
        </stats-card>
      </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <stats-card type="waring"
                      icon="fa fa-registered"
                      small-title="Registered"
                      :title="today.registered">
            <!-- <div class="stats" slot="footer">
              <a href="" style="text-decoration: none"><i class="nc-icon nc-refresh-69"></i>
              Refresh</a>
            </div> -->
          </stats-card>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <stats-card type="success"
                      icon="fa fa-check-square-o"
                      small-title="Completed"
                      :title="today.completed">
            <!-- <div class="stats" slot="footer">
              <a href="" style="text-decoration: none"><i class="nc-icon nc-refresh-69"></i>
              Refresh</a>
            </div> -->
          </stats-card>
        </div>
      
    </div>

    <div class="row">
      <div class="col-md-12">
        <h3>Total Registration</h3>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6">
        <stats-card type="warning"
                    icon="fa fa-users"
                    small-title="Total"
                    :title="total.count">
          <!-- <div class="stats" slot="footer">
            <a href="" style="text-decoration: none"><i class="nc-icon nc-refresh-69"></i>
            Refresh</a>
          </div> -->
        </stats-card>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6">
        <stats-card type="danger"
                    icon="fa fa-hourglass-start"
                    small-title="Pending"
                    :title="total.pending">
          <!-- <div class="stats" slot="footer">
            <a href="" style="text-decoration: none"><i class="nc-icon nc-refresh-69"></i>
            Refresh</a>
          </div> -->
        </stats-card>
      </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <stats-card type="waring"
                      icon="fa fa-registered"
                      small-title="Registered"
                      :title="total.registered">
            <!-- <div class="stats" slot="footer">
              <a href="" style="text-decoration: none"><i class="nc-icon nc-refresh-69"></i>
              Refresh</a>
            </div> -->
          </stats-card>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <stats-card type="success"
                      icon="fa fa-check-square-o"
                      small-title="Completed"
                      :title="total.completed">
            <!-- <div class="stats" slot="footer">
              <a href="" style="text-decoration: none"><i class="nc-icon nc-refresh-69"></i>
              Refresh</a>
            </div> -->
          </stats-card>
        </div>
      
    </div>
      <!-- <div class="col-md-12">
        <h3>Today's Registration</h3>
        <div class="col-md-3" style="padding:0">
          <el-card>
            <div slot="header" class="clearfix">
              <span><b>Total</b></span>
            </div>

          </el-card>
        </div>
        
      </div> -->
      <!-- <div class="col-md-4">
        <el-card :body-style="{ padding: '15px 0' }">
          <center><img src="/static/img/icons/masters.png"></center>
            <p style="text-align: center">Total Registrations</p>
            <div class="bottom clearfix">
              
              <center><h4 style="margin: 10px 0"><b>Total : {{total.count}}</b></h4></center>
              <el-tag style="margin-left: 3px" effect="dark" type="warning">Pending Patients: <b>121</b></el-tag>
              <el-tag style="margin-left: 3px" effect="dark" type="primary">Registered Patients: <b>122</b></el-tag>
              <el-tag style="margin-left: 3px" effect="dark" type="success">Completed Patients: <b>250</b></el-tag>
            </div>
        </el-card>
      </div> -->
    <!-- </div> -->
    
  </div>
</template>

<script>
import moment from 'moment'
import DigitalClock from "vue-digital-clock";
import StatsCard from 'src/components/UIComponents/Cards/StatsCard';
export default {
  components: {
    DigitalClock,
    StatsCard
  },
  data() {
    return {
      dateTime: moment().format('DD-MM-YYYY HH:mm:ss'),
      today:{
        count: '',
        pending: '',
        registered: '',
        completed: ''
      },
      total: {
        count: '',
        pending: '',
        registered: '',
        completed: ''
      }
    }
  },
  methods: {
    getData(event) {
      let cook = this.$cookies.get('kasp-pmjay')
      this.$http.post("dashboard/dashboard/dashboard", {
          hospitalId: cook.hospitalId
        })
        .then(response => {
          let res = response.body;
          if (res.status && res.hasrecords) {
           this.today.count = res.records.totalRegisteredToday
           this.today.pending = res.records.totalPending
           this.today.registered = res.records.totalRegistered
           this.today.completed = res.records.totalCompleted

           this.total.count = res.records.grandTotal
           this.total.pending = res.records.grandPending
           this.total.registered = res.records.grandRegistered
           this.total.completed = res.records.grandCompleted
          }
        });
    }
  },
  created(){
    this.getData()
  }

};
</script>

<style>
.clock span {
  font-size: 20px;
}
.clock__ampm{
  padding-left: 5px;
  text-transform: uppercase;
}
</style>
