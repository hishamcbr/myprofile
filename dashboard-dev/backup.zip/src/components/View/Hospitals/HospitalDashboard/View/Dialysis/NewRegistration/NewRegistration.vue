<template>
  <div>
      <div v-if="sections.listing">
    <div class="row">
      <div class="col-md-12">
     
          <button @click="showComponent('add')" class="btn btn-primary">Add Hospital</button>
          <div class="add" :class="{slide : showAdd }">
            <!-- <addDepartment  v-if="showAdd" @getData="getData()" :data="departmentData"></addDepartment>   -->
          </div>
      
      </div>
    </div>
 <ttable :page="page" @updateData="getData($event)" id="out-table" :noDataText="'hii'">
      <el-table-column
        slot="actions"
        :min-width="200"
        fixed="right"
        label="Actions"
        id="action-column"
      >
        <template slot-scope="props">
          <a class="btn btn-icon btn-info " @click.prevent="handleEdit(props.$index, props.row)" href>  <i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
          <a href
            class="btn btn-icon btn-success  "
          >  <i class="fa fa-upload" aria-hidden="true"></i></a>
          <a href
            class="btn btn-icon btn-primary "
        
       
          
          ><i class="fa fa-download" aria-hidden="true"></i></a>
        </template>
      </el-table-column>
    </ttable>

      </div>
  <AddNew  v-else-if="sections.add" @changeComponent="changeComponent"></AddNew>



   
  </div>
</template>

<script>
import swal from "sweetalert2";
// import addDepartment from './AddDepartment'
import ttable from "../../../../../ServerTable.vue";
import AddNew from './AddNew.vue'
export default {
  components: {
    ttable,
    AddNew
    // addDepartment
  },
  data() {
    return {
      showAdd: false,
         sections: {
        add: false,
        listing: true,
        edit: false
      },
      departmentData: {},
      page: {
        TotalPerPage: 10,
        total: 0,
        tableColumns: [],
        tableData: [],
        propsToSearch: [],
        selection: false,
        entries: false
      },
      columns: [
        {
          prop: "name",
          label: "Registration Number",
          minWidth: 200,
          sortable: true
        },
        {
          prop: "location",
          label: "Patient Name",
          minWidth: 200,
          sortable: true
        },
        {
          prop: "contactNumber",
          label: "OP/MR No",
          minWidth: 200,
          sortable: true
        },
         {
          prop: "contactNumber",
          label: "Card ID Number",
          minWidth: 200,
          sortable: true
        }
      ]
    };
  },
  methods: {

  changeComponent(value){
      this.showComponent(value)
    },
   showComponent(value) {
      this.sections = {
        add: false,
        listing: false,
        edit: false
      };
      for (var p in this.sections) {
        if (p == value) {
          this.sections[p] = true;
        }
      }
    },




    handleEdit(index, row) {
      this.departmentData = row;
      this.showAdd = true;
    },
    handleDelete(index, row) {
      swal({
        type: "question",
        title: "",
        text: "Are you sure to delete Department - " + row.name + "?",
        showCancelButton: true,
        confirmButtonText: "Delete",
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6"
      }).then(result => {
        if (result) {
          this.$http
            .post("department/department/delete_department", {
              id: row.id
            })
            .then(response => {
              let res = response.body;
              swal({
                type: res.status ? "success" : "error",
                title: res.message
              });
              if (res.status) {
                this.getData();
              }
            });
        }
      });
    },
    getData(event) {
      this.$http
        .post("hospital/hospital/list_hospital", {
          pagination: "TRUE",
          currentPage: event ? event.CurrentPage : 1,
          totalPerPage: this.page.TotalPerPage,
          sortOrder: "DESC",
          searchKey: ""
        })
        .then(response => {
          let res = response.body;
          this.page.tableColumns = this.columns;
          if (res.status && res.hasrecords) {
            // upon response success set columns and table data
            this.page.total = res.records.total;
            this.page.tableData = res.records.data;
          }
        });
    }
  }
};
</script>

<style scoped>
.add {
  max-height: 0;
  overflow: hidden;
}
.add.slide {
  transition: all 0.5s ease;
  max-height: 100%;
}
</style>
