<template>
  <div class="card sp-card">
    <div class="card-header">
        <a class="close-btn close-1" @click.prevent="$emit('changeComponent','listing')" href>
          <i style="margin-top:-20px" class="fa fa-times text-danger pull-right"></i>
        </a>
        </div>
      <div class="card-body1">
      <div class="show-patient">
        <!-- <div class="row"> -->
          <small><p class="view-patient-tag bxtitle">Basic Details</p></small>
          <el-card class="patient-view-card" style="width:100%" :body-style="{ padding: '10px 15px' }">
              <div class="row view-patient">
                <div class="col-md-4">
                  <p class="view-patient-tag"><strong>Name </strong>{{ patientData.name }}</p>
                </div>
                <div class="col-md-4">
                  <p class="view-patient-tag"><strong>Card Id</strong>{{patientData.cardId}}</p>
                </div>
                <div class="col-md-3">
                  <p class="view-patient-tag"><strong>Reg No </strong>{{ patientData.registerNumber ? data.registerNumber : 'NA' }}</p>
                </div>
                <div class="col-md-1">
                  <button @click.prevent="showPatient = !showPatient " class="btn btn-sm btn-primary expand-a pull-right">
                    <i class="fa" :class="showPatient ? 'fa-angle-up' : 'fa-angle-down'" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
              <el-collapse-transition>
                <div v-if="showPatient">
                <div class="sh-patient" >
                  <div class="row" >
                    <div class="col-md-4">
                    <p class="view-patient-tag"><strong>Mob No </strong>{{ patientData.mobileNumber }}</p>
                    </div>
                    <div class="col-md-4">
                      <p class="view-patient-tag"><strong>Gender </strong>{{ patientData.gender }}</p>
                    </div>
                    <div class="col-md-4">
                      <p class="view-patient-tag"><strong>Age </strong>{{ patientData.age }}</p>
                    </div>
                  </div>
                  <div class="row" >
                    <div class="col-md-4">
                    <p class="view-patient-tag"><strong>OP Number </strong>{{ patientData.opNumber }}</p>
                    </div>
                    <div class="col-md-4">
                      <p class="view-patient-tag"><strong>IP Number </strong>{{ patientData.ipNumber }}</p>
                    </div>
                  </div>
                </div>
                </div>
              </el-collapse-transition>
          </el-card>
  
          <small class="m-top15"><p class="view-patient-tag bxtitle">Admission Details</p></small>
          <el-card class="patient-view-card" style="width:100%" :body-style="{ padding: '10px 15px' }">
              <div class="row view-patient">
                <div class="col-md-4">
                  <p class="view-patient-tag"><strong>Department </strong>{{patientData.department_relation ? patientData.department_relation.name : ''}}</p>
                </div>
                <div class="col-md-4">
                  <p class="view-patient-tag"><strong>DOA </strong>{{dates.doa}}</p>
                </div>
                <div class="col-md-3">
                  <p class="view-patient-tag"><strong>Admitted At </strong>{{patientData.admittedAt == 1 ? 'Ward' : 'ICU'}}</p>
                </div>
                <div class="col-md-1">
                  <button @click.prevent="showAdmission = !showAdmission " class="btn btn-sm btn-primary expand-a pull-right">
                    <i class="fa" :class="showAdmission ? 'fa-angle-up' : 'fa-angle-down'" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
              <el-collapse-transition>
                <div v-if="showAdmission">
                <div class="sh-patient" >
                  <div class="row" >
                    <div class="col-md-4">
                    <p class="view-patient-tag"><strong>Type of admission </strong>{{patientData.admissionType==1 ? 'Planned' : 'Emergency'}}</p>
                    </div>
                    <div class="col-md-4">
                      <p class="view-patient-tag"><strong>Ventilator </strong>{{ patientData.ventilator == 1 ? 'Yes' : 'No' }}</p>
                    </div>
                    <div class="col-md-4">
                      <p class="view-patient-tag"><strong>Connected </strong>{{dates.ventilatorConnected}}</p>
                    </div>
                  </div>
                  <div class="row" >
                    <div class="col-md-4">
                    <p class="view-patient-tag"><strong>Disconnected</strong>{{dates.ventilatorDisconnected}}</p>
                    </div>
                    <div class="col-md-4">
                      <p class="view-patient-tag"><strong>Shifted to </strong>{{ patientData.shiftedTo == 1 ? 'Ward' : (patientData.shiftedTo == 2 ? 'ICU' : 'No Shift') }}</p>
                    </div>
                    <div class="col-md-4">
                      <p class="view-patient-tag"><strong>Shifted at</strong>{{dates.shiftedDate}}</p>
                    </div>
                  </div>
                  <div class="row" >
                    <div class="col-md-4">
                    <p class="view-patient-tag"><strong>Ward </strong>{{ patientData.ward_relation ? patientData.ward_relation.name : '' }}</p>
                    </div>
                    <div class="col-md-4">
                      <p class="view-patient-tag"><strong>Room No/Bed No </strong>{{patientData.roomBedNo}}</p>
                    </div>
                  </div>
                </div>
                </div>
              </el-collapse-transition>
          </el-card>
          <small class="m-top15"><p class="view-patient-tag bxtitle">Doctor Details</p></small>
          <el-card class="patient-view-card" style="width:100%" :body-style="{ padding: '10px 15px' }">
              <div class="row view-patient">
                <div class="col-md-3">
                  <p class="view-patient-tag"><strong>Name </strong>{{patientData.doctor_relation ? patientData.doctor_relation.name : ''}}</p>
                </div>
                <div class="col-md-3">
                  <p class="view-patient-tag"><strong>Reg No </strong>{{patientData.doctor_relation ? patientData.doctor_relation.registrationNo : ''}}</p>
                </div>
                <div class="col-md-3">
                  <p class="view-patient-tag"><strong>Qualification </strong>{{patientData.doctor_relation ? patientData.doctor_relation.qualification : ''}}</p>
                </div>
                <div class="col-md-3">
                  <p class="view-patient-tag"><strong>Mob No </strong>{{patientData.doctor_relation ? patientData.doctor_relation.mobileNumber : ''}}</p>
                </div>
              </div>
          </el-card>
      </div>
    </div>
    <div class="patent-2 tab-sp">
      <div class="button-sec">
        <a v-show="userType == 6" @click.prevent="activetab=1" class="btn btn-sm btn-primary"  :class="[ activetab === '1' ? 'active' : '' ]" href>Coding</a>
        <a @click.prevent="activetab=2" class="btn btn-sm btn-primary" :class="[ activetab === '2' ? 'active' : '' ]" href>Documents</a>
        <a v-show="userType == 6" class="btn btn-sm btn-danger" @click.prevent="request=true" href="#">Request Documents</a>
        <a @click.prevent="activetab=3" class="btn btn-sm btn-primary" :class="[ activetab === '3' ? 'active' : '' ]" href>Status</a>
        <a @click.prevent="activetab=4" class="btn btn-sm btn-primary"  :class="[ activetab === '4' ? 'active' : '' ]" href>Upload</a>
      </div>

      <transition name="fade">
        <div v-if="activetab == 1 && userType == 6" class="tab-sp-content">
          <h3>Diagnosis  <button @click.prevent="openDiagnosisModal" class="btn btn-sm ad-diagnosis btn-success">Add Diagnosis</button></h3>

          <div v-if="diagnosis_section">
            <div class="tb-innr-part diag-cover" v-for="(option,index) in diagnosis" :key="index">
              <h5>
                <span class="d-btn" @click.prevent="toggleDiagnosis(option,index)" href="#">
                <div class="num">  {{index+1}}.</div><span :id="'diagnosis_'+''+index">{{option.diagnosis}} </span>
                  <a class="edit-row" @click.prevent="openEditModal(option,'diagnosis',index,'')" href=""><i style="position: unset;margin-left:5px" class="fa fa-pencil"></i></a>
<a class="expand-a">
                  <i class="fa"
                    :class="expand[index] ? 'fa-angle-up' : 'fa-angle-down'"
                    aria-hidden="true"></i></a>
                </span>
              </h5>
              <div class="expndIn">
              <el-collapse-transition>
                <div v-if="expand[index]">
                  <table class="table">
                    <tr>
                      <td>
                        <input v-model="treatments[index].code_array.categoryCode" placeholder="Category" class="form-control" type="text" />
                      </td>
                      <td>
                        <input v-model="treatments[index].code_array.code" placeholder="Code" class="form-control" type="text" />
                      </td>
                      <td>
                        <input v-model="treatments[index].code_array.packageName" placeholder="Pkg Name" class="form-control" type="text" />
                      </td>
                      <td>
                        <input v-model="treatments[index].code_array.packageDays" placeholder="Days" class="form-control" type="text" />
                      </td>
                      <td>
                        <input v-model="treatments[index].code_array.packageAmount" placeholder="Amount" class="form-control" type="text" />
                      </td>
                    </tr>
                  </table>
                </div>
              </el-collapse-transition>
              <div class="daigIn" v-if="option.procedure_rel.length > 0">
                <div class="prs-item" v-for="(procedure,key) in option.procedure_rel" :key="'proc'+key">
                  <label for><span :id="'procedure_'+key+''+index">{{procedure.procedures}} </span>
                    <a @click.prevent="openEditModal(procedure,'procedure',index,key)" href=""><i style="position: unset;margin-left:5px" class="fa fa-pencil"></i></a>
                  </label>
                  <el-collapse-transition>
                    <div v-if="expand[index]">
                      <table class="table">
                        <tr>
                          <td>
                            <input v-model="treatments[index].procedures[key].code_array.categoryCode" placeholder="Category" class="form-control" type="text" />
                          </td>
                          <td>
                            <input v-model="treatments[index].procedures[key].code_array.code" placeholder="Code" class="form-control" type="text" />
                          </td>
                          <td>
                            <input v-model="treatments[index].procedures[key].code_array.packageName" placeholder="Pkg Name" class="form-control" type="text" />
                          </td>
                          <td>
                            <input v-model="treatments[index].procedures[key].code_array.packageDays" placeholder="Days" class="form-control" type="text" />
                          </td>
                          <td>
                            <input v-model="treatments[index].procedures[key].code_array.packageAmount" placeholder="Amount" class="form-control" type="text" />
                          </td>
                        </tr>
                      </table>
                    </div>
                  </el-collapse-transition>
                </div>
              </div>

            </div>
            </div>
            <button class="btn btn-success" @click.prevent="submitCode()">Save</button>
            <button class="btn btn-info" @click.prevent="openMarkCompletedModal()">Mark Completed</button>
          </div>
        </div>
      </transition>
      <transition>
        <div v-if="activetab == 2" class="tab-sp-content">
          <div class="row">
            <div class="col-md-12">
              <el-card style="width:100%">
                <div slot="header" class="clearfix">
                  <span>
                    <h6 style="margin-bottom: 10px">
                      Uploaded Documents
                    </h6>
                    <div class="row">
                      <div class="col-md-12">
                        <button :disabled="!docExist || loading" class="btn btn-sm btn-info" @click.prevent="showAll" style="margin:0 5px 0 0; padding:5px">Show All</button>
                        <button v-if="downloadButton" :disabled="!docExist || loading" style="margin:0 5px 0 0; padding:5px" class="btn btn-sm btn-success" @click.prevent="handleDownload">
                          {{ loading ? 'Downloading' : 'Download'}} <i v-if="loading" class="el-icon-loading"></i>
                        </button>
                        <!-- <button v-if="uploadButton" style="margin:0; padding:5px" class="btn btn-sm btn-warning" @click.prevent="$emit('uploadFromView',data)">
                          Upload
                        </button> -->
                      </div>
                    </div>
                  </span>
                </div>
                <div class="col-md-12">
                  <div  v-for="(option, index) in labels" :key="index">
                    <el-card>
                      <label>{{option.label}}</label><br>
                      <div v-viewer>
                        <div class="rio-img-thumb"  v-for="image in option.images" :key="image.image">
                          <span v-if="image.extension == 'png' || image.extension == 'jpg' || image.extension == 'jpeg'">
                            <div v-if="image.image" class="in-thumb" >
                                <img :src="image.image">
                              <div class="new-tag" v-show="image.downloaded == 1 || image.downloaded == 3">New</div>
                                <a v-if="imageClose" @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" ><i class="fa fa-times"></i></span></a>
                            </div>
                          </span>
                        </div>
                      </div>
                      <span v-for="image in option.images" :key="image.image">
                        <span v-if="image.extension == 'pdf'">
                          <span v-if="image.image" style="position:relative; margin-right: 10px">
                            <a @click.prevent="openDocument(image.image)" href><img style="display: inline-block;" @click.prevent="" width="15%" src=/static/img/pdf-icon.png></a>
                            <a v-if="imageClose" @click.prevent="deleteDocument(image.imageId)" href=""><span class="text-danger" style="position: absolute;top: -15px;right:-5px"><i class="fa fa-times"></i></span></a>
                          </span>
                        </span>
                      </span>
                    </el-card>
                  </div>
                </div>
              </el-card>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="all-doc" v-viewer="{movable: false}">
                <img style="display:none" v-for="src in images" :src="src" :key="src">
              </div>
            </div>
          </div>
        </div>
      </transition>
      <transition>
        <div v-if="activetab == 3 && userType == 6" class="tab-sp-content">
          <el-card>
            <el-timeline>
              <el-timeline-item
                v-for="(activity, index) in status"
                :key="index"
                :type="activity.type"
                :size="activity.size"
                :timestamp="activity.timestamp">
                {{activity.content}} {{activity.created_by ? ' by '+ activity.created_by : ''}}
              </el-timeline-item>
            </el-timeline>
          </el-card>
        </div>
      </transition>
      <transition>
        <div v-if="activetab == 4" class="tab-sp-content">
          <upload-document :data="data"></upload-document>
        </div>
      </transition>
    </div>
    <el-dialog :close-on-press-escape="true" :show-close="false" :before-close="preventClose" title="Request Documents" width="35%" :visible.sync="request" style="">
      <div class="row" v-for="(doc,index) in requestDocuments" :key="index">
        <div class="col-md-10">
          <div class="form-group">
            <label for="">Document Name</label>
            <input v-model="requestDocuments[index].label" data-vv-as="Document Name" class="form-control" type="text" :name="'Document Name'+index" data-vv-scope="documentScope" placeholder="Document Name" v-validate="'required'">
            <small class="text-danger">
              {{ errors.first('documentScope.Document Name'+index) }}
            </small>
          </div>
        </div>
        <div class="col-md-2" v-if="index==0">
          <label for="" style="visibility:hidden">test</label>
          <button style="margin:0" @click.prevent="validateDoc" class="btn btn-fill btn-info"><i class="fa fa-plus"></i></button>
        </div>
        <div class="col-md-2" v-else>
          <label for="" style="visibility:hidden">test</label>
          <button style="margin:0" @click.prevent="removeMore(index)" class="btn btn-fill btn-danger"><i class="fa fa-minus"></i></button>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <span slot="footer" class="dialog-footer">
              <button class="btn btn-sm btn-fill btn-success" @click.prevent="validateRequest()">Request</button>
              <button class="btn btn-sm btn-fill btn-primary" @click.prevent="request=false">Cancel</button>
          </span>
        </div>
      </div>
    </el-dialog>
    <el-dialog :close-on-press-escape="true" :show-close="false" :before-close="preventClose" :title="editTreatment.title" width="35%" :visible.sync="showEditModal" style="">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label for="">{{editTreatment.labelName}}</label>
            <input v-model="editTreatment.changedValue" data-vv-as="Name" class="form-control" type="text" name="Name" data-vv-scope="editScope" placeholder="Edit Name" v-validate="'required'">
            <small class="text-danger">
              {{ errors.first('editScope.Name') }}
            </small>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <span slot="footer" class="dialog-footer">
              <button class="btn btn-sm btn-fill btn-success" @click.prevent="validateEditTreatment()">Update</button>
              <button class="btn btn-sm btn-fill btn-primary" @click.prevent="showEditModal=false">Cancel</button>
          </span>
        </div>
      </div>
    </el-dialog>
    <el-dialog :close-on-press-escape="true" :show-close="false" :before-close="preventClose" :title="'Mark Completed'" width="35%" :visible.sync="showmarkModal" style="">
      <div class="row">
        <div class="col-md-12">
            <button class="btn btn-sm btn-fill btn-success" @click.prevent="markCompleted(1)">Auto Approval</button>
            <button class="btn btn-sm btn-fill btn-info" @click.prevent="markCompleted(2)">Approval Required</button>
            <button class="btn btn-sm btn-fill btn-primary" @click.prevent="showmarkModal=false">Cancel</button>
        </div>
      </div>
    </el-dialog>
    <el-dialog :close-on-press-escape="true" :show-close="false" :before-close="preventClose" :title="'Add Diagnosis'" width="50%" :visible.sync="diagnosisModal" style="">
      <add-diagnosis v-if="diagnosisModal" :data="addDiagnosisData" @close="closeDiagnosisModal"></add-diagnosis>
    </el-dialog>
    <el-dialog :close-on-press-escape="true" :show-close="false" :before-close="preventClose" title="Fill Case ID" width="35%" :visible.sync="caseModal" style="">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label for="">Case ID</label>
            <input v-model="caseId" class="form-control" type="text" name="Case ID" data-vv-scope="caseIdScope" placeholder="Enter Case ID" v-validate="'required'">
            <small class="text-danger">
              {{ errors.first('caseIdScope.Case ID') }}  
            </small> 
          </div>
        </div>
        <div class="col-md-12">
            <span slot="footer" class="dialog-footer">
                <button class="btn btn-sm btn-fill btn-success" @click.prevent="validateCaseId()">Update</button>
                <button class="btn btn-sm btn-fill btn-primary" @click.prevent="caseModal=false,$emit('refreshData')">Cancel</button>
            </span>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import "viewerjs/dist/viewer.css";
import Viewer from "v-viewer";
import Vue from "vue";
Vue.use(Viewer);
import PatientProfile from "./PatientProfile.vue";
import AddDiagnosis from './AddDiagnosis.vue'
import UploadDocument from './UploadDocumentNew.vue'
import swal from "sweetalert2";
import moment from "moment";
export default {
  props: ["data", "imageClose", "uploadButton", "downloadButton","activeButton"],
  components: {
    PatientProfile,
    AddDiagnosis,
    UploadDocument
  },
  data() {
    return {
      caseId: '',
      caseModal: false,
      status: [],
      diagnosis_section: true,
      addDiagnosisData: {},
      diagnosisModal: false,
      showmarkModal: false,
      userType: '',
      showEditModal: false,
      request: false,
      patientData: {},
      treatments: [],
      diagnosis: [],
      showPatient: true,
      showAdmission: true,
      docExist: false,
      showDetails: true,
      labels: [],
      loading: false,
      showFiled: true,
      activetab: '',
      images: [],
      expand: [],
      dates: {
        doa: '',
        ventilatorConnected: '',
        ventilatorDisconnected: '',
        shiftedDate: ''
      },
      requestDocuments: [
        {
          id: '',
          registrationId: '',
          label: ''
        }
      ],
      editTreatment: {

      }
    };
  },
  methods: {
    validateCaseId(){
      this.$validator.validateAll('caseIdScope').then(isValid => {
        if(isValid){
          this.submitCaseId()
        }
      })
    },
    submitCaseId(){
      let formData = {}
      formData.id = this.data.id
      formData.caseId = this.caseId
      // let cook= this.$cookies.get('kasp-pmjay')
      // formData.requestedBy = cook.UserId
      let url = 'preauth/preauth/update_case_id'
      this.$http.post(url, formData)
      .then(response => {
        let res = response.body
        if(res.status) {
          this.caseId = ''
          this.$validator.reset()
          this.caseModal = false
          
          swal({
            type: 'success',
            title: res.message
          })
          this.$emit('refreshData')
        }
        else{
          swal({
            type: 'error',
            title: res.message
          })
        }
      })
    },
    closeDiagnosisModal(){
      this.diagnosis_section = true
      this.getData()
      this.diagnosisModal = false
      this.$forceUpdate();
    },
    openDiagnosisModal(){
      this.diagnosis_section = false
      this.addDiagnosisData.patientId = this.data.id
      this.diagnosisModal = true
    },
    validateEditTreatment(){
      this.$validator.validateAll('editScope').then(isValid => {
        if(isValid){
          if(this.editTreatment.type == 'diagnosis'){
            this.editDiagnosis()
          }
          else{
            this.editProcedure()
          }
        }
      })
    },
    editDiagnosis(){
      if(this.editTreatment.changedValue){
        let formData = {}
        formData.diagnosis = this.editTreatment.changedValue
        formData.id = this.editTreatment.id
        this.$http.post('treatment/treatment/edit_diagnosis_single', formData)
        .then(response => {
            let res = response.body;
            if (res.status) {
                document.querySelector('#diagnosis_'+this.editTreatment.index).textContent = this.editTreatment.changedValue
                swal({
                    type: "success",
                    title: res.message
                });
                this.editTreatment = {}
                this.$validator.reset()
                this.showEditModal = false
                this.getData()
            } else {
                swal({
                    type: "error",
                    title: res.message
                });
            }
        })
      }
    },
    editProcedure(){
      console.log(this.editTreatment.key+1+this.editTreatment.index+1)
      if(this.editTreatment.changedValue){
        let formData = {}
        formData.procedures = this.editTreatment.changedValue
        formData.id = this.editTreatment.id
        this.$http.post('treatment/treatment/edit_procedure_single', formData)
        .then(response => {
            let res = response.body;
            if (res.status) {
              document.querySelector('#procedure_'+this.editTreatment.key+''+this.editTreatment.index).textContent = this.editTreatment.changedValue
                swal({
                    type: "success",
                    title: res.message
                });
                this.editTreatment = {}
                this.$validator.reset()
                this.showEditModal = false
                this.getData()
            } else {
                swal({
                    type: "error",
                    title: res.message
                });
            }
        })
      }
    },
    openEditModal(option,value,index,key){
      // this.$set(this.expand, index, this.expand[index])
      if(value == 'diagnosis'){
        this.editTreatment.title = "Edit Diagnosis"
        this.editTreatment.labelName = 'Diagnosis'
        // this.editTreatment.changedValue = option.diagnosis
        this.editTreatment.changedValue = document.querySelector('#diagnosis_'+index).textContent
        this.editTreatment.type = value
        this.editTreatment.id = option.id
        this.editTreatment.index = index
        this.editTreatment.key = ''
      }
      else{
        this.editTreatment.title = 'Edit Procedure'
        this.editTreatment.labelName = 'Procedure'
        // this.editTreatment.changedValue = option.procedures
        this.editTreatment.changedValue = document.querySelector('#procedure_'+key+''+index).textContent
        this.editTreatment.type = value
        this.editTreatment.id = option.id
        this.editTreatment.index = index
        this.editTreatment.key = key
      }
      this.showEditModal = true

    },
    validateRequest(){
      this.$validator.validateAll('documentScope').then(isValid => {
        if(isValid){
          this.submitRequest()
        }
      })
    },
    submitRequest(){
      // let cook= this.$cookies.get('kasp-pmjay')
      if(this.data.id){
        let formData = {}
        for(let key in this.requestDocuments){
          this.requestDocuments[key].registrationId = this.data.id
        }
        formData.requested = JSON.stringify(this.requestDocuments)
        this.$http.post('coder/coder/add_request_document', formData)
        .then(response => {
            let res = response.body;
            if (res.status) {
                swal({
                    type: "success",
                    title: res.message
                });
                this.requestDocuments = [
                  {
                    id: '',
                    registrationId: '',
                    label: ''
                  }
                ]
                this.$validator.reset()
                this.request = false
                this.getData()
            } else {
                swal({
                    type: "error",
                    title: res.message
                });
            }
        })
      }
    },
    validateDoc(){
      this.$validator.validateAll('documentScope').then(isValid => {
        if(isValid){
          this.addMore()
        }
      })
    },
    addMore(){
      let document = {
          id: '',
          registrationId: '',
          label: ''
      }
      this.requestDocuments.push(document)
    },
    removeMore(index){
      this.requestDocuments.splice(index,1)
    },
    preventClose(){

    },
    openMarkCompletedModal(){
      this.showmarkModal = true
    },
    markCompleted(value){
      let text = ''
      if(value == 1){
        text = 'Auto Approval'
      }
      else if(value == 2){
        text = 'Approval required'
      }
      if(this.data.id){
        swal({
        type: "question",
        title: "",
        text: "Are you sure to proceed with "+text+" ?",
        showCancelButton: true,
        confirmButtonText: "Yes",
        confirmButtonColor: "#1d7936",
        cancelButtonColor: "#3085d6"
        }).then(result => {
            if (result) {
            this.$http.post("coder/coder/mark_code_completed", {
                id: this.data.id,
                treatmentStatus: value
                })
                .then(response => {
                let res = response.body;
                swal({
                    type: res.status ? "success" : "error",
                    title: res.message
                });
                if (res.status) {
                  if(value == 1){
                    this.caseId = ''
                    this.caseModal = true
                  }
                  else{
                    this.$emit('refreshData')
                  }                  
                }
                });
            }
        });
      }
      else{
        swal({
            type: "error",
            title: "Failed to proceed"
        });
      }

    },
    submitCode(){
      // let cook= this.$cookies.get('kasp-pmjay')
      let formData = {}
      formData.treatments = JSON.stringify(this.treatments)
      this.$http.post('coder/coder/add_coding', formData)
      .then(response => {
          let res = response.body;
          if (res.status) {
              swal({
                  type: "success",
                  title: res.message
              });
          } else {
              swal({
                  type: "error",
                  title: res.message
              });
          }
      })
    },
    toggleDiagnosis(option,index){
      this.$set(this.expand, index, !this.expand[index])
    },
    showAll() {
      const viewer = this.$el.querySelector(".all-doc").$viewer;
      viewer.show();
    },
    handleDownload() {
      if (this.data.id) {
        this.loading = true;
        this.$http
          .post("patient/patient/zipping_patient", {
            id: this.data.id
          })
          .then(response => {
            let res = response.body;
            this.loading = false;
            if (res.status) {
              window.location.href = res.records;
              this.getData();
            } else {
              swal({
                type: "error",
                title: res.message
              });
            }
          });
      } else {
        swal({
          type: "error",
          title: "Unable to download documents"
        });
      }
    },
    openDocument(document) {
      window.open(document, "_blank");
      // console.log(document)
    },
    showDoc() {
      console.log("hii");
    },
    handleDischarge() {
      swal({
        type: "question",
        title: "",
        text: "Are you sure to request for discharge?",
        showCancelButton: true,
        confirmButtonText: "Request",
        confirmButtonColor: "#1576c2",
        cancelButtonColor: "#fbc658"
      }).then(result => {
        if (result) {
          this.$http
            .post("patient/patient/request_for_discharge", {
              id: this.data.id
            })
            .then(response => {
              let res = response.body;
              swal({
                type: res.status ? "success" : "error",
                title: res.message
              });
              if (res.status) {
                this.$emit("changeComponent", "listing");
              }
            });
        }
      });
    },
    deleteDocument(id) {
      swal({
        type: "question",
        title: "",
        text: "Are you sure to delete document ?",
        showCancelButton: true,
        confirmButtonText: "Delete",
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6"
      }).then(result => {
        if (result) {
          this.$http
            .post("patient/patient/delete_uploaded_document", {
              id: id
            })
            .then(response => {
              let res = response.body;
              swal({
                type: res.status ? "success" : "error",
                title: res.message
              });
              if (res.status) {
                this.getLabels();
              }
            });
        }
      });
    },
    getLabels() {
      if (this.data.departmentId) {
        this.$http
          .post("patient/patient/list_document_patient", {
            id: this.data.id
          })
          .then(response => {
            let res = response.body;
            let selectRes = [];
            if (
              res.status &&
              res.hasrecords &&
              res.records[0].document_relation.length > 0
            ) {
              for (let key in res.records[0].document_relation) {
                let result = [];
                result["label"] = res.records[0].document_relation[key].label;
                result["labelId"] = res.records[0].document_relation[key].id;
                result["cardId"] = res.records[0].cardId;
                result["patientId"] = res.records[0].id;
                result["departmentId"] = res.records[0].departmentId;
                result["loading"] = false;
                let images = [];
                if (
                  res.records[0].document_relation[key].upload_relation.length >
                  0
                ) {
                  for (let key1 in res.records[0].document_relation[key]
                    .upload_relation) {
                    this.docExist = true;
                    let imageData = [];
                    imageData["image"] =
                      res.records[0].document_relation[key].upload_relation[
                        key1
                      ].documentName;
                    imageData["extension"] =
                      res.records[0].document_relation[key].upload_relation[
                        key1
                      ].ext;
                    imageData["downloaded"] =
                      res.records[0].document_relation[key].upload_relation[
                        key1
                      ].downloaded;
                    //store image for show all
                    if (
                      imageData["extension"] == "jpg" ||
                      imageData["extension"] == "jpeg" ||
                      imageData["extension"] == "png"
                    ) {
                      this.images.push(imageData["image"]);
                    }
                    imageData["imageId"] =
                      res.records[0].document_relation[key].upload_relation[
                        key1
                      ].id;
                    images.push(imageData);
                  }
                }
                result["images"] = images;
                selectRes.push(result);
              }
              this.labels = selectRes;
            } else {
              this.labels = [];
            }
          });
      }
    },
    getData(){
      if(this.data.id){
        this.$http.post("patient/patient/list_reg_patient", {
          id: this.data.id,
          MoreDetails: 'TRUE',
          PermenentDetails: 'TRUE',
          DiagnosisDetails: 'TRUE'
        })
        .then(response => {
          let res = response.body;
          if (res.status && res.hasrecords) {
            this.getPatientData(res.records[0])
          }
          else{
            this.patientData = {}
          }

        });
      }

    },
    getPatientData(data){
      // this.diagnosis = []
      // if (JSON.stringify(this.data) != "{}") {
        // this.$set(this.patientData, 0, data)
        // console.log(data.id)
        this.patientData = this.$set(this.data,0,this.data)
        this.dates.doa = data.doa ? moment(data.doa).format('DD-MM-YYYY') : ''
        this.dates.ventilatorConnected = data.ventilatorOn ? moment(data.ventilatorOn).format('DD-MM-YYYY hh:mm:ss A') : 'NA'
        this.dates.ventilatorDisconnected = data.ventilatorOff ? moment(data.ventilatorOff).format('DD-MM-YYYY hh:mm:ss A') : 'NA'
        this.dates.shiftedDate = data.shiftedDate ? moment(data.shiftedDate).format('DD-MM-YYYY hh:mm:ss A') : 'NA'
        // console.log(data.diagnosis_relation[24])
        if(data.diagnosis_relation.length > 0){
          let diagnosis= []
          let treatments = []
          for(let key in data.diagnosis_relation){
            // console.log(key)
            let treatment = {
              id: data.diagnosis_relation[key].id ? data.diagnosis_relation[key].id : '',
              flag: 1,
              code_array: {
                categoryCode: '',
                code: '',
                packageName: '',
                packageDays: '',
                packageAmount: ''
              },
              procedures: []
            }
            if(data.diagnosis_relation[key].diagnosis_filled_rel.length > 0){
              treatment.code_array = {
                categoryCode: data.diagnosis_relation[key].diagnosis_filled_rel[0].categoryCode ? data.diagnosis_relation[key].diagnosis_filled_rel[0].categoryCode : '',
                code: data.diagnosis_relation[key].diagnosis_filled_rel[0].code ? data.diagnosis_relation[key].diagnosis_filled_rel[0].code : '',
                packageName: data.diagnosis_relation[key].diagnosis_filled_rel[0].packageName ? data.diagnosis_relation[key].diagnosis_filled_rel[0].packageName : '',
                packageDays: data.diagnosis_relation[key].diagnosis_filled_rel[0].packageDays ? data.diagnosis_relation[key].diagnosis_filled_rel[0].packageDays : '',
                packageAmount: data.diagnosis_relation[key].diagnosis_filled_rel[0].packageAmount ? data.diagnosis_relation[key].diagnosis_filled_rel[0].packageAmount : '',
              }
            }
            if(data.diagnosis_relation[key].procedure_rel.length > 0){
              for(let key1 in data.diagnosis_relation[key].procedure_rel){
                let procedure = {
                  id: data.diagnosis_relation[key].procedure_rel[key1].id ? data.diagnosis_relation[key].procedure_rel[key1].id : '',
                  flag: 2,
                  code_array: {
                    categoryCode: '',
                    code: '',
                    packageName: '',
                    packageDays: '',
                    packageAmount: ''
                  }
                }
                if(data.diagnosis_relation[key].procedure_rel[key1].procedure_filled_rel.length > 0){
                  let procedure_array = data.diagnosis_relation[key].procedure_rel[key1].procedure_filled_rel[0]
                  procedure.code_array = {
                    categoryCode: procedure_array.categoryCode ? procedure_array.categoryCode : '',
                    code: procedure_array.code ? procedure_array.code : '',
                    packageName: procedure_array.packageName ? procedure_array.packageName : '',
                    packageDays: procedure_array.packageDays ? procedure_array.packageDays : '',
                    packageAmount: procedure_array.packageAmount ? procedure_array.packageAmount : ''
                  }
                }
                treatment.procedures.push(procedure)
              }
            }
            treatments.push(treatment)
            let f = true
            this.expand.push(f)
            // this.diagnosis.$set(key,this.data.diagnosis_relation[key])
            // this.$set(this.diagnosis,key,this.data.diagnosis_relation[key])
            diagnosis.push(data.diagnosis_relation[key])
          }
          this.treatments = treatments
          // for(let key in diagnosis){
          //   this.$set(this.diagnosis,key,diagnosis[key])
          // }
          // this.$forceUpdate();
          // this.$set(this.diagnosis,'',diagnosis)
          // console.log(diagnosis)
          this.diagnosis = diagnosis
          // console.log(this.diagnosis)
        }
        // console.log(this.treatments)
      // }
    },
    getStatus(){
      if(this.data.id){
        this.$http.post("coder/coder/patient_movement_tracking",
          {
          registrationId: this.data.id,
          flag: '1',
          sortOrder: 'ASC'
          })
          .then(response => {
          let res = response.body;
          let selectRes = [];
          if (res.status && res.hasrecords) {
              for (let key in res.records) {
              let result = [];
              result["id"] = res.records[key].id;
              result["content"] = res.records[key].status;
              result["timestamp"] = res.records[key].created_at;
              result["created_by"] = res.records[key].user_relation ? res.records[key].user_relation.name : '';
              result["size"] = 'large';
              result["type"] = 'success';
              selectRes.push(result);
              }
              this.status = selectRes;
          }
          else{
              this.status = []
          }
        });
      }
    }
  },
  mounted(){
    // this.getData();
  },
  watch: {
      diagnosis: {
          handler: function(newValue) {
             console.log('modifies')
          },
          deep: true
      }
  },
  created() {
    // console.log(this.$route.path)
    let cook = this.$cookies.get('kasp-pmjay')
    if(cook.userType == 6){
      this.activetab =1
    }else{
      this.activetab = 2
    }
    if(this.activeButton){
      this.activetab = this.activeButton
    }
    // console.log(cook)
    this.userType = cook.userType
    this.getData();
    this.getStatus()
    this.getLabels();
  }
};
</script>
<style>
.view-patient-tag{
  margin-bottom: 5px !important;
}
.patient-view-card .el-card__header{
  padding: 10px 20px;
}
</style>
<style scoped>
.form-group input[type="file"] {
  opacity: 1;
  position: unset !important;
}
label {
  color: #6c6666 !important;
}
.show-patient {
  flex-wrap: wrap;
  display: flex;
}
.show-patient h5 {
  margin: 0;
  margin-right: 15px;
}
.show-patient button {
  margin: 0;
}
</style>
