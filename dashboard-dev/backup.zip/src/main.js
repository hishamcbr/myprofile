import Vue from 'vue'
import './pollyfills'
import VueRouter from 'vue-router'
import VueRouterPrefetch from 'vue-router-prefetch'
import VueNotify from 'vue-notifyjs'
import VeeValidate from 'vee-validate'
// import lang from 'element-ui/lib/locale/lang/en'
import locale from 'element-ui/lib/locale/lang/en'
import App from './App.vue'
import uiElement from 'element-ui'
import VueTabs from "vue-nav-tabs";
import VueFormWizard from 'vue-form-wizard'
import 'vue-form-wizard/dist/vue-form-wizard.min.css'

// Plugins
import GlobalComponents from './globalComponents'
import GlobalDirectives from './globalDirectives'
import SideBar from './components/UIComponents/SidebarPlugin'
// import initProgress from './progressbar';
import VueResource from 'vue-resource'
import VueCookies from 'vue-cookies'

// router setup
import router from './routes/routes'

// library imports

import './assets/sass/paper-dashboard.scss'
import './assets/sass/demo.scss'

import sidebarLinks from './sidebarLinks'
import './registerServiceWorker'

// import firebase from "firebase/app";
// import 'firebase/auth'; 
// import 'firebase/storage'; 
// import 'firebase/database'; 
// import 'firebase/firestore';
// import 'firebase/messaging'; 
// import 'firebase/functions';
// var config = {
//     apiKey: "AIzaSyDxmA4nUt1AWZWZLaMJ943mPuLHCG4-JKk",
//     authDomain: "vue-test-79a40.firebaseapp.com",
//     databaseURL: "https://vue-test-79a40.firebaseio.com",
//     projectId: "vue-test-79a40",
//     storageBucket: "",
//     messagingSenderId: "710174079953",
//     appId: "1:710174079953:web:28db90f1b45981b0"
// };

// firebase.initializeApp(config);
// Vue.prototype.$messaging = firebase.messaging()

// navigator.serviceWorker.register('/firebase-messaging-sw.js')
//     .then((registration) => {
//         Vue.prototype.$messaging.useServiceWorker(registration)
//     }).catch(err => {
//         console.log(err)
//     })

// plugin setup
Vue.use(VueRouter)
Vue.use(uiElement, { locale })
Vue.use(VueRouterPrefetch)
Vue.use(GlobalDirectives)
Vue.use(GlobalComponents)
Vue.use(VueNotify)
Vue.use(SideBar, { sidebarLinks: sidebarLinks })
Vue.use(VeeValidate)
    // locale.use(lang)
Vue.use(VueResource)
Vue.use(VueCookies)
Vue.use(VueTabs)
Vue.use(VueFormWizard)


const ADMIN = 1
const SUB_ADMIN = 2


router.beforeEach((to, from, next) => {
    let cook = ''
    try {
        cook = Vue.cookies.get('kasp-pmjay')
    } catch (err) {
        Vue.cookies.remove("kasp-pmjay", "/");
    }
    if (cook != null) {
        if (to.matched.some(record => record.meta.requiresAdmin)) {
            if (cook.userType == ADMIN || cook.userType == SUB_ADMIN) {
                next()
            } else {
                next('/login')
            }
        } else {
            next();
        }
    } else {
        if (to.path == '/') {
            next('/login');
            // let adres = JSON.parse(localStorage.getItem('adres'));
            // if (!adres) {
            //     next();
            // } else {
            //     next('/login');
            // }
        } else if (to.path == '/login') {
            next()
        } else {
            next('/login');
        }
    }
});

Vue.http.options.credentials = true
Vue.http.options.emulateJSON = true
if (window.location.hostname == 'localhost') {
    Vue.http.options.root = 'http://pmjaytest.sevensigma.in/api/v2/'
} else {
    Vue.http.options.root = 'http://pmjaytest.sevensigma.in/api/v2/'
}


Vue.http.interceptors.push((request, next) => {
    let cook = Vue.cookies.get('kasp-pmjay')
    let token = ""
    if (cook) {
        token = cook.token
    } else {
        token = ""
    }
    request.headers.set('Authorization', token)
    request.headers.set('Accept', 'application/json')
    return (response) => {
        if (response.status === 401) {
            router.push('/login')
        }
    }
})



// configure router
// const router = new VueRouter({
//   routes, // short for routes: routes
//   linkActiveClass: 'active',
//   scrollBehavior: (to) => {
//     if (to.hash) {
//       return {selector: to.hash}
//     } else {
//       return { x: 0, y: 0 }
//     }
//   },
//   mode: 'history'
// })

// initProgress(router);

/* eslint-disable no-new */
new Vue({
    el: '#app',
    render: h => h(App),
    router
})